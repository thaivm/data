package com.domino.controller;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class NfcControllerProviderTest {
    private NfcControllerProvider nfcControllerProvider;

    @Before
    public void setUp() throws Exception {
        nfcControllerProvider = new NfcControllerProvider();
    }

    @Test
    public void testKill() throws Exception {
        nfcControllerProvider.kill();
    }

    @Test
    public void testOn() throws Exception {
        nfcControllerProvider.on();
    }

    @Test
    public void testGetFailure() throws Exception {
        assertEquals(nfcControllerProvider.get().getResponse(),"::error::");
    }

    @Test
    public void testGetSuccess() throws Exception {
        assertEquals(nfcControllerProvider.get().getResponse(),"success");
    }
}
