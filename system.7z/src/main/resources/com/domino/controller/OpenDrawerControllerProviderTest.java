package com.domino.controller;

import org.junit.Before;
import org.junit.Test;

public class OpenDrawerControllerProviderTest {
    private OpenDrawerControllerProvider openDrawerControllerProvider;
    @Before
    public void setUp() throws Exception {
        openDrawerControllerProvider = new OpenDrawerControllerProvider();
    }

    @Test
    public void testConnect() throws Exception {
        openDrawerControllerProvider.connect("opendrawer");
    }
}
