package com.domino.controller;

import org.junit.Test;

public class BarCodeScannerControllerProviderTest {

    @Test
	public void connect_success() {
		BarCodeScannerControllerProvider barCodeScannerControllerProvider = new BarCodeScannerControllerProvider();
//		assertEquals(barCodeScannerControllerProvider.connect(), "success");
	}

    @Test
	public void connect_failure() {
		BarCodeScannerControllerProvider barCodeScannerControllerProvider = new BarCodeScannerControllerProvider();
//		assertEquals(barCodeScannerControllerProvider.connect(), "failure");
	}
}
