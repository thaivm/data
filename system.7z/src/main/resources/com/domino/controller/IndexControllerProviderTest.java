package com.domino.controller;

import org.junit.Before;
import org.junit.Test;
import org.springframework.ui.Model;

public class IndexControllerProviderTest {
    private Model model;
    private IndexControllerProvider indexControllerProvider;
    @Before
    public void setUp() throws Exception {
        indexControllerProvider = new IndexControllerProvider();
    }

    @Test
    public void testConnect() throws Exception {

    }
}
