package com.domino.controller;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class PrintControllerProviderTest {
    private PrintControllerProvider printControllerProvider;
    private JSONObject jsonObject;

    @Before
    public void setUp() throws Exception {
        printControllerProvider = new PrintControllerProvider();
        jsonObject = new JSONObject();
        JSONArray jsonArray = new JSONArray();
        JSONObject item = new JSONObject();
        item.put("n", "1");
        item.put("price", "3.99");
        item.put("name", "Delta Product");
        item.put("sku", "INV-D04");

        jsonArray.add(item);

        jsonObject.put("val", jsonArray);
        jsonObject.put("cash", "100");
        jsonObject.put("card", "100");
        jsonObject.put("nfc", "100");
        jsonObject.put("paypal", "100");
        jsonObject.put("cardType", "cardType");
        jsonObject.put("cardNumber", "cardNumber");
        jsonObject.put("custEmail", "custEmail");
    }

    @Test
    public void testConnectActNotPrint() throws Exception {
        jsonObject.put("act", "act");
        assertEquals(printControllerProvider.connect(jsonObject).getResponse(), "success");
    }

    @Test
    public void testConnectActIsPrint() throws Exception {
        jsonObject.put("act", "print");
        assertEquals(printControllerProvider.connect(jsonObject).getResponse(), "failure");
    }

    @Test
    public void testJust40CharMid() throws Exception {
        assertEquals(printControllerProvider.just40CharMid("aaaaaa"),"                 aaaaaa \n");
    }

    @Test
    public void testJust40CharMid001() throws Exception {
        assertEquals(printControllerProvider.just40CharMid("aaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaa ::break-here:: aaa"),
                " aaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaa \n");
    }

    @Test
    public void testWordwrap() throws Exception {
        assertEquals(printControllerProvider.wordwrap("aaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaa  aaa"),
                "aaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaa::break-here::");
    }

    @Test
    public void testProducListFormat() throws Exception {
        assertEquals(printControllerProvider.producListFormat("product 1", (
                double )100, (double )2 ,"P1"),
                "product 1                            200 \n" +
                        "   2.0 x 100 (P1) \n");
    }

    @Test
    public void testLeftAndRight() throws Exception {
        assertEquals(printControllerProvider.leftAndRight("thai dai ca dep chai",
                "thai dai ca dep chai"), "thai dai ca dep chaithai dai ca dep chai \n");
    }

    @Test
    public void testLeftAndRight001() throws Exception {
        assertEquals(printControllerProvider.leftAndRight("thai ",
                "dai ca dep chai"), "thai                     dai ca dep chai \n");
    }
}
