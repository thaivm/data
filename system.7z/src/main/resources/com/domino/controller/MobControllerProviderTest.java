package com.domino.controller;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class MobControllerProviderTest {
    private MobControllerProvider mobControllerProvider;
    @Before
    public void setUp() throws Exception {
        mobControllerProvider = new MobControllerProvider();
    }

    @Test
    public void testConnect() throws Exception {
        assertEquals(mobControllerProvider.connect(), "dominopos/index");
    }

    @Test
    public void testSettings() throws Exception {
        assertEquals(mobControllerProvider.settings(), "dominopos/settings");
    }
}
