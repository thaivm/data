package com.domino.controller;

import com.domino.model.TwoLineDisplay;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class DisplayControllerProviderTest {
    private TwoLineDisplay twoLineDisplay;
    private DisplayControllerProvider displayControllerProvider;

    @Before
    public void setUp() throws Exception {
        this.twoLineDisplay = new TwoLineDisplay("line1", "line2");
        this.displayControllerProvider = new DisplayControllerProvider();
    }

    @Test
    public void testConnect() throws Exception {
        displayControllerProvider.connect(this.twoLineDisplay);
    }

    @Test
    public void testGetLine_lengthSmaller20() throws Exception {
        assertEquals(displayControllerProvider.getLine("thaidaica"), "thaidaica           ");
    }

    @Test
    public void testGetLine_lengthLarger20() throws Exception {
        assertEquals(displayControllerProvider.getLine("thai dai ca dep chai vo doi"), "thai dai ca dep chai");
    }
}
