package com.domino.controller;

import com.domino.service.ItemService;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class FilterControllerTest {
    private FilterController filterController;
    private ItemService itemService;

    @Before
    public void setUp() throws Exception {
        filterController = new FilterController();
    }

    @Test
    public void testConnect() throws Exception {

    }

    @Test
    public void testPregMatchTrue() throws Exception {
        assertEquals(filterController.pregMatch("thai", "thaidaica"), true);
    }

    @Test
    public void testPregMatchFalse() throws Exception {
        assertEquals(filterController.pregMatch("thaidep", "thaidaica"), false);
    }
}
