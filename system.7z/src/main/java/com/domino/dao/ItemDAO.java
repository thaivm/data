package com.domino.dao;

import com.domino.model.Item;

import java.util.List;

/**
 *
 * interface ITEM DAO
 */
public interface ItemDAO {
	public void addItem(Item item);
    public List<Item> listItem();
    public void removeItem(Integer id);
}
