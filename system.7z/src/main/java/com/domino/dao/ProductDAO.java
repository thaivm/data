package com.domino.dao;
/**
 *
 * Interface Product DAO
 */
public interface ProductDAO {

}
