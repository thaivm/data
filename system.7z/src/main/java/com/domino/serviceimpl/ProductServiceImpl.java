package com.domino.serviceimpl;

import com.domino.dao.ProductDAO;

/**
 *
 * Class product service implements
 */
public class ProductServiceImpl implements ProductDAO{

}
