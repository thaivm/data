package com.domino.serviceimpl;

import com.domino.dao.ItemDAO;
import com.domino.model.Item;
import com.domino.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 *
 * Class item service implements
 */
@Service
public class ItemServiceImpl implements ItemService{
	@Autowired
    private ItemDAO itemDAO;
    /**
     * Service add item
     * */ 
    @Transactional
    public void addItem(Item item) {
        itemDAO.addItem(item);
    }
 
    /**
     * Service list item 
     * */
    @Transactional
    public List<Item> listItem() {
        return itemDAO.listItem();
    }
 
    /**
     * Service remove item
     * */
    @Transactional
    public void removeItem(Integer id) {
        itemDAO.removeItem(id);
    }
}
