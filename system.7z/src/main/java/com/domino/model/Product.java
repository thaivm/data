package com.domino.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.security.Timestamp;
/**
 *
 * Product model
 */
@Entity
@Table(name="PRODUCT")
public class Product {
	
	@Id
	@Column(name="ProductId")
	private String productId;
	
	@Column(name="ProductName")
	private String productName;
	
	@Column(name="Price")
	private long price;
	
	@Column(name="Created_At")
	private Timestamp createdAt;
	
	@Column(name="Updated_At")
	private Timestamp updatedAt;
	
	@Column(name="ShortDescription")
	private String shortDescription;
	
	@Column(name="LongDescription")
	private String longDescription;
	
	@Column(name="Image")
	private String image;
	
	@Column(name="Video")
	private String video;
	
	@Column(name="IsActive")
	private boolean isActive;
	
	@Column(name="ModuleId")
	private int moduleId;
	
	@Column(name="CategoryId")
	private String categoryId;
	
	@Column(name="Mid")
	private String mId;

	public Product() {
		super();
	}

	public Product(String productId, String productName, long price,
			Timestamp createdAt, Timestamp updatedAt,
			String shortDescription, String longDescription, String image,
			String video, boolean isActive, int moduleId, String categoryId,
			String mId) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.shortDescription = shortDescription;
		this.longDescription = longDescription;
		this.image = image;
		this.video = video;
		this.isActive = isActive;
		this.moduleId = moduleId;
		this.categoryId = categoryId;
		this.mId = mId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	public Timestamp getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	public Timestamp getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public String getLongDescription() {
		return longDescription;
	}

	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getVideo() {
		return video;
	}

	public void setVideo(String video) {
		this.video = video;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean active) {
		this.isActive = active;
	}

	public int getModuleId() {
		return moduleId;
	}

	public void setModuleId(int moduleId) {
		this.moduleId = moduleId;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getmId() {
		return mId;
	}

	public void setmId(String mId) {
		this.mId = mId;
	}
	
	
}
