package com.domino.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 *
 * ITEM Model
 */
@Entity
@Table(name="ITEM")
public class Item {
	@Id
    @Column(name="ID")
    @GeneratedValue 
    private Integer id;
     
    @Column(name="SKU")
    private String sku;

    @Column(name="FILE")
    private String file;

    @Column(name="NAME")
    private String name;
     
    @Column(name="PRICE")
    private String price;
    
    @Column(name="STOCK")
    private String stock;

	public Item() {
		super();
	}

    public Item(String sku, String file, String name, String price, String stock) {
        this.sku = sku;
        this.file = file;
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    public Item(Integer id, String sku, String file, String name,
                String price, String stock) {
		super();
		this.id = id;
		this.sku = sku;
		this.file = file;
		this.name = name;
		this.price = price;
		this.stock = stock;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getStock() {
		return stock;
	}

	public void setStock(String stock) {
		this.stock = stock;
	}
    
}
