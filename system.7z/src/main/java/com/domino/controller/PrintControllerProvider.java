package com.domino.controller;

import com.domino.model.Business;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.*;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
/**
 * This controller process event of printer
 */
@Controller
@RequestMapping("/pos_print")
public class PrintControllerProvider {
    private static final int SIZE_40 = 40;
    private static final int SIZE_38 = 38;
    private static final String CASH = "cash";
    private static final String CARD = "card";
    private static final String NFC = "nfc";
    private static final String PAYPAL = "paypal";
    private static final String ACT = "act";
    private static final String EMAIL = "email";
    private static final String PRINT = "print";
	@RequestMapping(method = RequestMethod.POST)
	@ResponseBody
	public StringOb connect(@RequestBody Map<String, Object> objectJson) throws Exception {
		Business businessData = new Business("Inventory Solutions, inc", "3 Iberis St.", "McGregor 4109");

		//begin the header of the recipt
		String head  = just40CharMid(businessData.getName());
		head = head + just40CharMid(businessData.getAddress1());
		head = head + just40CharMid(businessData.getAddress2());
		head = head + just40CharMid("www.DominoPos.com");
		head = head + "----------------------------------------" + " \n";
		
		Date date = new Date(System.currentTimeMillis());
		String subH  = "Date : " + date.toString() + " \n";
		subH = subH + "Bill No : " + " \n";
		subH = subH + " \n";
		subH = subH + "----------------------------------------" + " \n";

		//begin the article list of the recipt
		//decode the val variable from JSON to array format
		List<Map<String, Object>> vars = new ArrayList<Map<String, Object>>();
		vars = (List<Map<String, Object>>) objectJson.get("val");
		System.out.println(vars);
		double total = 0;
        String pList = "";
        int size = vars.size();
		for (int i = 0; i < size; i++) {
			String name = (String) vars.get(i).get("name");
            double price = Double.parseDouble((String) vars.get(i).get("price"));
            double qty = Double.parseDouble((String) vars.get(i).get("n"));
			String sku = (String) vars.get(i).get("sku");
			total = total + price*qty;
			pList = pList + producListFormat(name, price, qty, sku);
		}
		
		pList = pList + "----------------------------------------" + " \n";
		
		String right = Double.toString(Math.round(total*100)/100);
		
		//begin the total and the payment method
		String subL  = leftAndRight("TOTAL", right);

		double givenMoney = 0;
        String cash = (String)objectJson.get(CASH);
		if(!cash.equals("") && Double.parseDouble(cash) > 0){
			subL = subL + leftAndRight("CASH", Double.toString(Math.round(Double.parseDouble(cash)*100)/100));
			givenMoney = givenMoney + Double.parseDouble(cash);
		}
        String card = (String)objectJson.get(CARD);
		if(!card.equals("") && Double.parseDouble(card) > 0){
			subL = subL + leftAndRight("CARD", Double.toString(Math.round(Double.parseDouble(card)*100)/100));
			
			int nX = ((String)objectJson.get("cardNumber")).length() - (2+3); 
			String spc = "";
			
			for(int i=0; i < nX; i++){
                spc = spc + "x";
            }
			
			String front = ((String)objectJson.get("cardNumber")).substring(0, 2);
			String rear  = ((String)objectJson.get("cardNumber")).substring(3);
			subL = subL + "--paid by " + (String)objectJson.get("cardType") + ":" + front + spc + rear + " \n";
			givenMoney = (double) (givenMoney + Double.parseDouble(card));
		}
		String nfc = (String)objectJson.get(NFC);
		if(!nfc.equals("") && Double.parseDouble(nfc) > 0){
			//$subL .= leftAndRight('NFC', number_format($_POST['nfc'],2));
			//$subL .= '--paid by NFC '." \n";
			subL = subL + "Payment method: NFC " + "\n";
			subL = subL + leftAndRight("AMOUNT", Double.toString(Math.round(Double.parseDouble(nfc)*100)/100));
			
			givenMoney = (double ) (givenMoney + Double.parseDouble(nfc));
		}
        String paypal = (String)objectJson.get(PAYPAL);
		if(!paypal.equals("") && Double.parseDouble(paypal) > 0){
			subL = subL + "Payment method: Paypal " + " \n";
			subL = subL + leftAndRight("AMOUNT", Double.toString(Math.round(Double.parseDouble(paypal)*100)/100));
			
			givenMoney = (double ) (givenMoney + Double.parseDouble(paypal));
		}

		subL = subL + leftAndRight("CHANGE", Double.toString(Math.round((givenMoney - total)*100)/100));
		subL = subL + " \n";

		//begin the footer of the recipt
		String footer = " \n";
		footer = footer + just40CharMid("Thank You");
		footer = footer + just40CharMid("email : info@DominoPos.com");
		footer = footer + " \n";
		footer = footer + " \n";
		footer = footer + " \n";

		//begin generate the recipt file
		String allRecipt = head + subH + pList + subL + footer;
		String file = "recipt.txt";

		File fstream = new File(file);
        String pathFile = "";
		try {
			if (fstream.exists()) {
				fstream.createNewFile();
			}
			pathFile = fstream.getCanonicalPath();
			BufferedWriter writer = new BufferedWriter(new FileWriter(fstream));
			writer.write(allRecipt);
			writer.close();
			writer = null;
		} catch (IOException e) {
            System.out.println(e.toString());
		}
			
		//if send to email
		String act = (String)objectJson.get(ACT);
		if(act.equals(EMAIL)){
            System.out.println("send email");
		}

		//if print the recipt
		String path = this.getClass().getClassLoader().getResource("").getPath();
		if (path.contains("WEB-INF/classes/") || path.contains("classes/")){
			path = path.replace("WEB-INF/classes/", "resources/bin");
            path = path.replaceFirst("/","");
            System.out.println(path);
	    }
		
		if(act.equals(PRINT)){
			String dev  = "/dev/usb/lp0";
			try {
				Runtime.getRuntime().exec("sudo chmod 777 " + path + "/cut_paper");
				Runtime.getRuntime().exec("sudo chmod 777 " + pathFile);
				Runtime.getRuntime().exec("sudo chmod 777 " + dev);
				
				String[] arCmd = {"/bin/bash","-c","sudo cat " + pathFile + " > " + dev};
				Process p = Runtime.getRuntime().exec(arCmd);
				PrintWriter pw = new PrintWriter(p.getOutputStream());
				BufferedReader br = new BufferedReader(new InputStreamReader( p.getInputStream()));
				String line = null;
				while((line=br.readLine())!=null){
					System.out.println(line);
				}
				pw.flush();
				p.waitFor();
				String cmd = "sudo " + path + "/cut_paper";
				Runtime.getRuntime().exec(cmd);
			} catch (IOException e) {
				return new StringOb("failure");
			}
		}
		return new StringOb("success");
	}
	
	/*
	because the recipt only 40 char width we need to format the output string using some ofthe followin functions
	format the given string to display in center
	*/
	
	public String just40CharMid(String str) {
		int nnn = str.length();
		String tmp = "";
		if(nnn > SIZE_40){
			str = wordwrap(str);
			String[] all = str.split("::break-here::");
			
			for(int i = 0; i < all.length; i++) {
				int space = Math.round((SIZE_40 - all[i].length()) / 2);
				String spc = "";
				for(int j=0; j < space; j++){
                    spc = spc + " ";
                }
				tmp = tmp + spc + all[i] + " \n";
			}
		}else{
			int space = Math.round((SIZE_40 - str.length()) / 2);
			String spc = "";
			for(int i = 0; i < space; i++){
                spc = spc + " ";
            }
			tmp = spc + str + " \n";
		}
		return tmp;		
	}
	
	public String wordwrap(String str) {
		String tmp = "";
		int len = (int) Math.floor(str.length() / SIZE_38);
		for(int i = 0; i < len; i++) {
			tmp = tmp + str.substring(i*SIZE_38 + 1, (i + 1)*SIZE_38) + "::break-here::";
		}
		return tmp;
	}
	/*
	format the given string to display in the list of articles
		name 	: the article name
		price 	: the price
		qty 	: the amount of the current article
		sku	: the article code
	*/
	public String producListFormat(String name, Double price, Double qty, String sku){
		String all  = "";
		Double sbT = (double ) (Math.round(price*qty*100)/100);
		int space = SIZE_40 - name.length() - sbT.toString().length();
		String spc = "";
        for (int i = 0;i < space; i++) {
            spc = spc + " ";
        }

		all = all + name + spc + sbT.toString() + " \n";
		all = all + "   " + qty.toString() + " x " + (Math.round(price*100)/100) + " (" + sku + ")" + " \n";
		
		return all;
	}

	/*
	format two string to place on the leftmost and the rightmost of the recipt
		left 	: string you want to put on the left
		right	: string you want to put on the right
		
	just set one ofthe variable to '' (blank string) if you want to choose just left or just right
	*/

	public String leftAndRight(String left, String right){
		int space = SIZE_40 - left.length() - right.length();
        String spc = "";
		for(int i=0; i < space; i++){
            spc = spc + " ";
        }

        String all = left + spc + right + " \n";
		return all;
	}
	
	@XmlRootElement
	public class StringOb {
		@XmlElement
		private String response;

		public String getResponse() {
			return response;
		}

		public StringOb(String response) {
			super();
			this.response = response;
		}
	}
}
