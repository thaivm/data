package com.domino.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.IOException;


/**
 *
 * This controller define nfc method
 * 
 *
 */
@Controller 
@RequestMapping("/nfc")
public class NfcControllerProvider {
	/**
	 * Function kill nfc
	 * */
	@RequestMapping(value="/kill", method = RequestMethod.POST) 
	@ResponseBody 
	public void kill() {
		String cmd = "sudo killall -9 pcscd";
		try {
			Runtime.getRuntime().exec(cmd);
		} catch (IOException e) {
			System.out.println(e.toString());
		}
	}
	
	/**
	 * Function on nfc
	 * 
	 * */
	
	@RequestMapping(value="/on", method = RequestMethod.POST)
	@ResponseBody 
	public void on() {
		String cmd = "sudo /usr/sbin/pcscd --debug --foreground";
		try {
			Runtime.getRuntime().exec("sudo chmod 777 /usr/sbin/pcscd");
			Runtime.getRuntime().exec(cmd);
		} catch (IOException e) {
			System.out.println(e.toString());
		}
	}
	
	/**
	 * Function get nfc
	 * 
	 * */
	@RequestMapping(value="/get", method = RequestMethod.POST)
	@ResponseBody 
	public StringOb get() {
		String cmd = "sudo /usr/bin/pcsc_scan";
		try {
			Runtime.getRuntime().exec("sudo chmod 777 /usr/bin/pcsc_scan");
			Runtime.getRuntime().exec(cmd);
		} catch (IOException e) {
			return new StringOb("::error::");
		}
				
		return new StringOb("success");
	}
	
	@XmlRootElement
	public class StringOb {
		@XmlElement
		private String response;

		public String getResponse() {
			return response;
		}

		public StringOb(String response) {
			super();
			this.response = response;
		}	
		
	}
}
