package com.domino.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;

/**
 *
 * this controller process event open drawer when cash
 */
@Controller 
@RequestMapping("/opendrawer")
public class OpenDrawerControllerProvider {
	@RequestMapping(method = RequestMethod.POST, headers = "Accept=application/xml, application/json", produces = { "application/json", "application/xml" }, consumes = { "application/json", "application/xml" }) 
	@ResponseBody 
	public void connect(@RequestBody String open) {
        String path = this.getClass().getClassLoader().getResource("").getPath();
		if (path.contains("WEB-INF/classes/") || path.contains("classes/")){
			path = path.replace("WEB-INF/classes/", "resources/bin");
            path = path.replaceFirst("/","");
            System.out.println(path);
	    }
		String dir = path + "/bin";
		String cmd = "exec  " + dir + "/cash_drawer";
		if(open.equals("opendrawer")) {
	        try {
                Runtime.getRuntime().exec("sudo chmod 777 " + dir + "/cash_drawer");
				Runtime.getRuntime().exec(cmd);
			} catch (IOException e) {
                System.out.println(e.toString());
			}
		} 
	} 
}
