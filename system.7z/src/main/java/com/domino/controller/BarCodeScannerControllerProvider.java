package com.domino.controller;

import com.domino.model.Item;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
/**
 *
 * This controller to define Barcode scanner.
 *
 */
@Controller 
@RequestMapping("/barcode")
public class BarCodeScannerControllerProvider {
	@RequestMapping(method = RequestMethod.POST, headers = "Accept=application/xml, application/json", produces = { "application/json", "application/xml" }, consumes = { "application/json", "application/xml" }) 
	@ResponseBody
    public List<Item> connect(@RequestBody Map<String, Object> objectJson){
        List<Item> items = new ArrayList<Item>();
		Item item = new Item("INV-D04", "4.jpg", "Delta Product", "45.00", "15");
		Item item1 = new Item("INV-F06", "7.jpg", "Foxtrot Product", "45.35", "23");
		Item item2 = new Item("INV-G07", "7.jpg", "Golf Product", "124.05", "2");
		Item item3 = new Item("INV-H08", "8.jpg", "Hotel Product", "56.33", "45");
		Item item4 = new Item("INV-J10", "10.jpg", "Jackpot Product", "234.99", "1");
		Item item5 = new Item("INV-M13", "7.jpg", "Mary Product", "19.99", "85");
		Item item6 = new Item("INV-A01D", "22.jpg", "Bravo Chicago Product", "35.99", "85");
		Item item7 = new Item("INV-B02C", "20.jpg", "Alpha Denver Product", "14.25", "85");
		Item item8 = new Item("INV-A01E", "17.jpg", "Alpha Easy Product", "16.69", "85");
		Item item9 = new Item("INV-A01F", "18.jpg", "Alpha Frank Product", "35.99", "85");
		Item item13 = new Item("INV-H10", "8.jpg", "Hotel Vung Tau Product", "56.33", "45");
		Item item14 = new Item("INV-J11", "10.jpg", "Hot dog Product", "234.99", "1");
		Item item15 = new Item("INV-M14", "7.jpg", "Henry Product", "19.99", "85");
		Item item17 = new Item("INV-B02E", "20.jpg", "Gama Denver Product", "14.25", "85");
		Item item18 = new Item("INV-A01I", "17.jpg", "Gama Easy Product", "16.69", "85");
		Item item19 = new Item("INV-A01J", "18.jpg", "Gama Frank Product", "35.99", "85");
		Item item23 = new Item("INV-H09", "8.jpg", "Hotel cali Product", "56.33", "45");
		Item item24 = new Item("INV-J12", "10.jpg", "Card Product", "234.99", "1");
		Item item25 = new Item("INV-M15", "7.jpg", "Steven Product", "19.99", "85");
		Item item27 = new Item("INV-B02D", "20.jpg", "Beta Denver Product", "14.25", "85");
		Item item28 = new Item("INV-A01G", "17.jpg", "Beta Easy Product", "16.69", "85");
		Item item29 = new Item("INV-A01H", "18.jpg", "Beta Frank Product", "35.99", "85");

		items.add(item);
		items.add(item2);
		items.add(item3);
		items.add(item4);
		items.add(item5);
		items.add(item6);
		items.add(item7);
		items.add(item8);
		items.add(item9);
		items.add(item1);
		items.add(item13);
		items.add(item14);
		items.add(item15);
		items.add(item17);
		items.add(item18);
		items.add(item19);
		items.add(item23);
		items.add(item24);
		items.add(item25);
		items.add(item27);
		items.add(item28);
		items.add(item29);

        List<Item> itemList = new ArrayList<Item>();
        String sKey = (String) objectJson.get("sKey");
        int size = items.size();
        
        // search item with bar code key
        for (int i = 0; i < size; i++) {
            if(sKey.toLowerCase().toString().trim().equals(items.get(i).getSku().toLowerCase().toString().trim())){
            	itemList.add(items.get(i));
                break;
            }
        }

        return itemList;
    }
}
