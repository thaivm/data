package com.domino.controller;


import com.domino.model.TwoLineDisplay;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;
/**
 *
 * This controller process how to display in TWO LINE DISPLAY
 */
@Controller 
@RequestMapping("/display")
public class DisplayControllerProvider {

    private static final int SPACE = 20;
	@RequestMapping(method = RequestMethod.POST, headers = "Accept=application/xml, application/json", produces = { "application/json", "application/xml" }, consumes = { "application/json", "application/xml" }) 
	@ResponseBody 
	public void connect(@RequestBody TwoLineDisplay twoLineDisplay) {
		// get path of driver binary file
        String path = this.getClass().getClassLoader().getResource("").getPath();
		if (path.contains("WEB-INF/classes/") || path.contains("classes/")){
			path = path.replace("WEB-INF/classes/", "resources/bin");
            path = path.replaceFirst("/","");
            System.out.println(path);
	    }
		String dir = path + "/bin";
		String bin = dir + "/cdisplay ";
		
        String dev = "/dev/ttyUSB0";
        // get line 1
        String words1 = getLine(twoLineDisplay.getLine1());
        // get line 2
        String words2 = getLine(twoLineDisplay.getLine2());

        String words = words1 + words2;

        String args = " --device " + dev + " --words \"" + words + "\" ";
        String cmd  = "sudo " + bin + args;
        // exec command line in java
        try {
            Runtime.getRuntime().exec("sudo chmod 777 " + bin);
            Runtime.getRuntime().exec("sudo chmod 777 " + dev);
			Runtime.getRuntime().exec(cmd);
		} catch (IOException e) {
			System.out.println(e.toString());
		}
	} 

	/**
	 * Function getline : return a string after process it 
	 * Parameter line 
	 * */
	public String getLine(String line) {
        String tmp = line;
        int space = SPACE - tmp.length();
        String spc  = "";
        
        for (int i = 0; i < space; i++) {
        	spc = spc + " ";
		}
        String words = "";
        
        if(tmp.length() > SPACE) {
            words = tmp.substring(0,  SPACE);
        } else {
    	    words = tmp + spc;
        }
        return words;
	}
}
