package com.domino.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * This controller mouth to mobile UI and setting UI
 */
@Controller
public class MobControllerProvider {
	@RequestMapping("/mob")
	public String connect() {
		return "dominopos/index";
	}
	@RequestMapping("/settings")
	public String settings() {
		return "dominopos/settings";
	}
}
