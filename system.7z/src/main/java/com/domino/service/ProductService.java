package com.domino.service;

/**
 *
 * Interface Product service
 */
public interface ProductService {

}
