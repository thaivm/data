package com.domino.service;

import com.domino.model.Item;

import java.util.List;

/**
 *
 * Interface Item service
 */
public interface ItemService {
	public void addItem(Item item);
    public List<Item> listItem();
    public void removeItem(Integer id);
}
