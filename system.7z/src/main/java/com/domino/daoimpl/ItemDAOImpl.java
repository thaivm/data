package com.domino.daoimpl;

import com.domino.dao.ItemDAO;
import com.domino.model.Item;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
/**
 *
 * Class ITEM DAO implements
 */
@Repository
public class ItemDAOImpl implements ItemDAO {

    @Autowired
    private SessionFactory sessionFactory;
    /**
     * Function add item to database using hibernate
     * */
    public void addItem(Item item) {
        sessionFactory.getCurrentSession().save(item);
    }
 
    /**
     * Function get list item from database using hibernate
     * */
    public List<Item> listItem() {
        return sessionFactory.getCurrentSession().createQuery("from Item").list();
    }
 
    /**
     * 
     * Function delete item to database using hibernate
     * */
    public void removeItem(Integer id) {
        Item item = (Item) sessionFactory.getCurrentSession().load(
                Item.class, id);
        if (null != item) {
            sessionFactory.getCurrentSession().delete(item);
        }
    }
}
