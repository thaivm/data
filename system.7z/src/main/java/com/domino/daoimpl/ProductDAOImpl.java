package com.domino.daoimpl;

import com.domino.dao.ProductDAO;
/**
 *
 * Class product DAO implements
 */
public class ProductDAOImpl implements ProductDAO {

}
