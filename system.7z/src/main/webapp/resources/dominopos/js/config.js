require.config({

  deps: ["main"],

  paths: {
    
  },

  map: {
    
  },

  shim: {

  }

});