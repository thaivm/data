(function(d){"function"===typeof define&&define.amd?define(["jquery"],d):d(jQuery)})(function(d){function n(a){return a}function p(a){return decodeURIComponent(a.replace(k," "))}function l(a){0===a.indexOf('"')&&(a=a.slice(1,-1).replace(/\\"/g,'"').replace(/\\\\/g,"\\"));try{return e.json?JSON.parse(a):a}catch(c){}}var k=/\+/g,e=d.cookie=function(a,c,b){if(void 0!==c){b=d.extend({},e.defaults,b);if("number"===typeof b.expires){var g=b.expires,f=b.expires=new Date;f.setDate(f.getDate()+g)}c=e.json?
JSON.stringify(c):String(c);return document.cookie=[e.raw?a:encodeURIComponent(a),"=",e.raw?c:encodeURIComponent(c),b.expires?"; expires="+b.expires.toUTCString():"",b.path?"; path="+b.path:"",b.domain?"; domain="+b.domain:"",b.secure?"; secure":""].join("")}c=e.raw?n:p;b=document.cookie.split("; ");for(var g=a?void 0:{},f=0,k=b.length;f<k;f++){var h=b[f].split("="),m=c(h.shift()),h=c(h.join("="));if(a&&a===m){g=l(h);break}a||(g[m]=l(h))}return g};e.defaults={};d.removeCookie=function(a,c){return void 0!==
d.cookie(a)?(d.cookie(a,"",d.extend({},c,{expires:-1})),!0):!1}});

var interval = null;
/**
 * todo
 *
 * call ad
 * call product/coupon/promotion detail
 * generate detail page
 */

var createListItem = function(item, ul) {
    var li = $('<li/>').addClass('list-item linkTo').attr('data-linkto', item.linkTo).data('linkto', item.linkTo).appendTo(ul);

    if (item.thumb) {
        li.append('<span class="pull-left thumb"><img src="' + item.thumb + '"/></span>');
    }

    if (item.text) {
        li.append('<div class="pull-left text">' + item.text + '</div>');
    }

    if (item.price) {
        var currency = item.currency || '';
        li.prepend('<span class="pull-right price">' + item.currency + item.price + '</span>');
    }

    if (item.image) {
        li.css('backgroundImage','url(' + item.image + ')').css('color', 'white');
    }

    if (item.purchase) {
        var widgetItemId = 0;
        li.append('<a class="btn btn-success pull-right addtocart" data-item-id="' + widgetItemId + '"> Add to Cart <i class="icon-shopping-cart"></i></a>');
    }

    li.append('<div class="clearfix"></div>');
}

var scrollList = function() {
    var ul = $(this).find('ul:eq(0)');
    var scrollPos = $(this).scrollTop() + $(this).outerHeight();
    var data = $(this).data('widget');
    var page = $(this).data('page');

    if ((scrollPos - 90) >= (ul.height() - 90)) {
        $(this).off('scroll');
        var list = $(this);

        $.get(data.more, {page: page++}, function(response) {
            if (response.length > 0) {

                response.forEach(function(item) {
                    createListItem(item, ul);
                });

                list.data('page', page++);
                list.on('scroll', scrollList);
            }

        }, 'json');
    }
}

var linkTo = function(link) {

    var link = link.split(':');
    switch(link[0]) {
        case "page":
            $.get(link[1], {}, function(response) {
                response.forEach(function(page) {
                    // create the page and switch to it
                    Page(page, function() {
                        $.mobile.changePage('#' + page.id, {
                            transition: 'slide'
                        });   
                    });
                });

            }, 'json');
        break;
        default:
            if ($('#' + link[0]).length) {
                $.mobile.changePage('#' + link[0], {
                    transition: 'slide'
                });   
            }
        break;
    }

    return true;
}

var Page = function(page, cb) {
    var id = page.id || new Date().getTime();
    var body = $('<div/>').addClass('page').attr('id', id).data('role', 'page').attr('data-role', 'page').appendTo($.mobile.pageContainer);

    if (page.class) body.addClass(page.class);

    // call the components
    page.components && page.components.forEach(function(component) {
        if (component == 'static-toolbar') {
            var header = $('<header/>').addClass('toolbar').prependTo(body);
            var tools = [
                {
                    "id": "",
                    "href": "#main",
                    "linkTo": "",
                    "text": '<img src="' + intro.logo + '" alt="" style="width:34px;"/>',
                    "where": "pull-left"
                },
                {
                    "id": "Tlist",
                    "href": "",
                    "linkTo": "menu-screen",
                    "text": '<i class="icon-th"></i>',
                    "where": "pull-right"
                },
                {
                    "id": "Tcart",
                    "href": "/checkout",
                    "linkTo": "",
                    "text": '<i class="icon-shopping-cart"></i> <span class="label">0</span>',
                    "where": "pull-right"
                },
                {
                    "id": "tools",
                    "href": "",
                    "linkTo": "",
                    "text": '<i class="icon-reorder"></i>',
                    "where": "pull-right"
                }
            ]

            tools.forEach(function(tool) {
                header.append('<a id="' + tool.id + '" href="' + tool.href + '" class="linkTo ' + tool.where + '" data-linkto="' + tool.linkTo + '">' + tool.text + '</a>')
            });

            header.find('.linkTo').click(function() {
                linkTo($(this).data('linkto'));
            })
        }
    });

    if (page.enableAds) {
        $('<div/>').addClass('ad').appendTo(body);
        body.addClass('hasAds');
    }

    if (page.hasToolbar) {
        body.addClass('hasToolbar');
    }

    // set up the widgets
    if (page.type == 'detail') {
        var pad = $('<div/>').addClass('pad').appendTo(body);

        if (page.item.image) $('<img/>').attr('src', page.item.image).appendTo(pad);
        $('<h2/>').text(page.item.title).appendTo(pad);
        $('<div/>').addClass('description').text(page.item.description).appendTo(pad);
        
        if (page.item.purchase && !page.item.total) $('<button/>').addClass('btn btn-large addtocart').data('role', 'none').attr('data-role', 'none').text('Add ' + page.item.title + ' to Cart for ' + page.item.currency + page.item.price).appendTo(pad);

        if (page.item.purchase && page.item.total) $('<button/>').addClass('btn btn-large addtocart').text('Add ' + page.item.title + ' to Cart for ' + page.item.currency + page.item.total).appendTo(pad);
        if (page.item.discount) $('<p/>').text('Discounted at ' + page.item.discount + page.item.discountType).appendTo(pad);
    }

    var cards = $('<div/>').addClass('cards').appendTo(body);
    page.widgets && page.widgets.forEach(function(widget) {
        var id = widget.id || new Date().getTime();

        var widgetContent = new Widget(widget);
        widgetContent.appendTo(cards);
    });

    body.page();

    if (cb) {
        cb(body);
    }
}

var Widget = function(widget) {
    var elemRoot = $('<div/>').attr('id', widget.id).data('role', 'widget').addClass('widget card col-6 col-lg-6').addClass(widget.type).addClass(widget.class);
    var elem = $('<div/>').attr('class', 'cardInner').appendTo(elemRoot);

    if (widget.text) {
        $('<div/>').addClass('inner').html(widget.text).appendTo(elem);
    }

    if (widget.title) {
        $('<h2/>').addClass('title').text(widget.title).prependTo(elem);
    }

    if (widget.class) {
        if (widget.class.indexOf('full') >= -1) {
            elemRoot.addClass('col-12').removeClass('col-6');
        }
        if (widget.class.indexOf('catalog') >= -1) {
            elemRoot.addClass('col-lg-12').removeClass('col-lg-6');
        }
    }

    $(elem).click(function(ev) {
        if (widget.remote) {
            if (confirm('You are leaving this App and will go to another page. Are you sure?')) {
                window.location = widget.remote;
            }
            return false;
        }

        if (widget.loadpage) {
            $.mobile.loadPage(widget.loadpage);
        }

        if (widget.linkTo) {
            linkTo(widget.linkTo);
            ev.stopPropagation();
        }
    });

    if (widget.linkTo) {
        elemRoot.addClass('linkTo').attr('data-linkto', widget.linkTo).data('linkto', widget.linkTo)
    }

    if (elemRoot.hasClass('full')) {
        elemRoot.css('minHeight', $(window).height() - 20);
    }

    if (widget.type == 'list') {
        var list = $('<div/>').attr('id', new Date().getTime()).addClass('list coupons').appendTo(elem);

        var ul = $('<ul/>').appendTo(list);

        if (elemRoot.hasClass('full')) {
            list.css('minHeight', $(window).height() - 100);
        }

        var items = widget.items.splice(0, 10);

        items.forEach(function(item) {
            createListItem(item, ul);
        });

        if (widget.more) {
            list.data('widget', widget);
            list.data('page', 0);

            list.scroll(function() {
                scrollList.apply(this);
            });
        }
    } else if (widget.type == 'hero') {

        if (widget.text) elem.html(widget.text);
        if (widget.background) elem.css('backgroundImage', 'url(' + widget.background + ')');


    } else if (widget.type == 'slider') {
        var index = $('<div/>').addClass('index');
        var i = $('<i/>');

        /*if (!widget.more) {
            i.clone().addClass('icon-chevron-left').appendTo(index);
            var span = $('<span/>').appendTo(index);
            var key = 0;
            widget.items.forEach(function() {
                var o = i.clone().addClass('icon-circle');
                if (key == 0) o.removeClass('icon-circle').addClass('icon-circle-blank');
                o.appendTo(span);
                key++;
            });
            i.clone().addClass('icon-chevron-right').appendTo(index);
        }

        index.appendTo(elem);*/

        var slider = $('<div/>').addClass('slider').appendTo(elem);
        var key = 0;
        if (widget.items.length > 0) {
            widget.items.forEach(function(item) {
                var slide = $('<div/>').addClass('slide').appendTo(slider);
                if (key == 0) slide.addClass('active');

                if (item.text) slide.html(item.text);
                if (item.image) slide.css('backgroundImage', 'url(' + item.image + ')');
                if (item.linkTo) slide.addClass('linkTo').attr('data-linkto', item.linkTo).data('linkto', item.linkTo);
                key++;
            });

            $('<div/>').attr('class', 'btn-next pull-right').html('<i class="icon-repeat"></i>').prependTo(slider);

            var coupon = 0;
            var swipe = function() {
                var span = $(slider).parents('.widget').find('.index span');
                if (!widget.more) span.find('i').removeClass('icon-circle-blank').addClass('icon-circle');

                $(slider).find('.slide:eq(' + coupon + ')').removeClass('active');

                if (coupon >= $(slider).find('.slide').length - 1) {
                    if (widget.more) {
                        var page = elem.find('.slider .slide').length;                            
                        $.get(widget.more, {page: page}, function(response) {
                            if (response.length > 0) {
                                response.forEach(function(item) {
                                    var slide = $('<div/>').addClass('slide').appendTo(slider);
                                    if (item.text) slide.html(item.text);
                                    if (item.image) slide.css('backgroundImage', 'url(' + item.image + ')');
                                    if (item.linkTo) slide.addClass('linkTo').attr('data-linkto', item.linkTo).data('linkto', item.linkTo);
                                    coupon++;
                                });
                                $(slider).find('.slide:eq(' + coupon + ')').addClass('active');
                            } else {
                                coupon = 0;
                                $(slider).find('.slide:eq(' + coupon + ')').addClass('active');
                            }
                        });
                    } else {
                        coupon = 0;
                        $(slider).find('.slide:eq(0)').addClass('active');
                    }
                } else {
                    coupon++;
                    $(slider).find('.slide:eq(' + coupon + ')').addClass('active');
                }
                
                if (!widget.more) span.find('i:eq(' + coupon + ')').removeClass('icon-circle').addClass('icon-circle-blank');
            }

            // if (widget.auto > 0) {
            //     interval = setInterval(swipe, widget.auto);
            // }

            // slider.find('.btn-next').click(function() {

                // if (widget.auto > 0) {
                //     clearInterval(interval);
                // }
                // if (widget.auto > 0) {
                //     setInterval(swipe, widget.auto);
                // }
            // });

            $(slider).swipe({
                tap: function(event, target) {
                    if ($(target).is('.btn-next, .icon-repeat')) {
                        swipe();
                        event.stopPropagation();
                        return false;
                    }

                    if ($(target).parents('.linkTo').length > 0) {
                        target = $(target).parents('.linkTo');
                    }

                    var id = $(target).data('linkto');
                    if (id) {
                        linkTo(id);
                    }
                    event.stopPropagation();
                },
                swipe: function(event, direction, distance, duration) {
                    // if (widget.auto > 0) {
                    //     clearInterval(interval);
                    // }

                    swipe();

                    // if (widget.auto > 0) {
                    //     setInterval(swipe, widget.auto);
                    // }
                },
                threshold: 50
            });
        }
    }

    return elemRoot;
}

jQuery(function($) {
    // set up the welcome page
    var welcome = $('#welcome-screen');
    welcome.find('h1').text(intro.name);
    welcome.find('img').attr('src', intro.logo);
    welcome.find('h1 + div > span').text('Welcome to ' + intro.name);
    if (intro.css) $('body').append('<style>' + intro.css + '</style>');
});

window.scrollTo(0,1); //android full screen
$(function() {

    var load = function() {
        $.get('data.json', {}, function(domino) {
            if (!domino) {
                alert('DOMINO is broken, please alert the merchant.');
                throw new Error();
            }

            // set up the pages
            domino.page.forEach(function(page) {
                Page(page);
            });

            $('.catalog').swipe({
                swipeLeft: function(event, target) {
                    var id = $(this).data('linkto');
                    if (id) {
                        linkTo(id);
                    }
                }
            });

            $.mobile.changePage('#main', {
                transition: 'slideup'
            });
        }, 'json');
    }

    $(document).on('click', '#tools', function() {
        $('#fog').fadeIn();
        $('#toolbox').addClass('visible');
    });

    $('#fog, #toolbox h3').click(function() {
        $('#fog').fadeOut();
        $('#toolbox').removeClass('visible');
    });

    var user = $.cookie('domino_user');
    if (user) {
        user = user.split('@');
        $('#taptostartname span').html(user[0]);
        $('#registertostart').hide();
        $('#taptostart, #taptostartname').show();

        $('#welcome-screen').click(function(ev){
            load();
        });
    } else {

        $('#registertostart .ui-btn-text').click(function() {
            var val = $('#userid').val();
            if (/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(val)) {
                $.cookie('domino_user', val);
                load();
            } else {
                alert('Please enter a Valid Email!');
            }
        });

    }

    $(document).on('click', '.addtocart', function(ev) {
        // add to cart functionality
        alert('added to cart!');
        // get product ID from data-item-id
    });

    $(document).on('click', '.list .linkTo', function(ev) {
        if ($(ev.target).hasClass('addtocart')) return;
        
        var id = $(this).data('linkto');
        if (id) {
            linkTo(id);
            // if ($('#' + id).length) {
            //     $.mobile.changePage('#' + id, {
            //         transition: 'slide'
            //     });   
            // }
        }
        ev.stopPropagation();
    });

    // $(document).on('click', '.linkTo', function(ev) {
    //     var target = this;
    //     if ($(target).parents('.slide').length > 0) return false;

    //     var id = $(target).data('linkto');
    //     if (id) {
    //         // if ($('#' + id).length) {
    //         //     $.mobile.changePage('#' + id, {
    //         //         transition: 'slide'
    //         //     });   
    //         // }
    //     }
    //     ev.stopPropagation();
    // })
});