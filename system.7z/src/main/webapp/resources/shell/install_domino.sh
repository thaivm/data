#!/bin/bash
#Install Tomcat server
sudo apt-get install tomcat7
#Install Tomcat administration webapps
sudo apt-get install tomcat7-admin
#add user tomcat7 has sudo
Tomcat7="tomcat7"
str="ALL=(ALL:ALL) ALL"
strNoPW="ALL=(ALL:ALL) NOPASSWD: ALL"
userTag="<tomcat-users>"
role="<role rolename=\"admin-gui\"\/>\n<role rolename=\"manager-gui\"\/>"
user="<user username=\"admin\" password=\"111172\" roles=\"admin-gui,manager-gui\"\/>"
sudo sed -i "s/$str/$str\n$Tomcat7  $strNoPW\n%$Tomcat7  $strNoPW/" /etc/sudoers
#add user admin for manager app in tomcat7
sudo sed -i "s/$userTag/$userTag\n$role\n$user/" /etc/tomcat7/tomcat-users.xml

#Deploy Domino apps to tomcat7
sudo /etc/init.d/tomcat7 stop
sudo rm -Rf /var/lib/tomcat7/webapps/DominoBox*
cd ../../../../../
sudo cp target/DominoBox.war /var/lib/tomcat7/webapps/DominoBox.war
sudo /etc/init.d/tomcat7 start
sudo chmod -R 777 /var/lib/tomcat7

echo -e "\033[35m Install Domino box success!!!"

