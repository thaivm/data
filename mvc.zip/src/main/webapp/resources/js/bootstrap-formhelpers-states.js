
 
 !function ($) {

  "use strict"; // jshint ;_;


 /* STATES CLASS DEFINITION
  * ====================== */

  var BFHStates = function (element, options) {
    this.options = $.extend({}, $.fn.bfhstates.defaults, options)
    this.$element = $(element)
    
    if (this.$element.is("select")) {
      this.addStates()
    }
    
    if (this.$element.is("span")) {
      this.displayState()
    }
    
    if (this.$element.hasClass("bfh-selectbox")) {
      this.addBootstrapStates()
    }
  }

  BFHStates.prototype = {

    constructor: BFHStates

    , addStates: function () {
      var country = this.options.country
      
      if (country != "") {
		var formObject = this.$element.closest('form')
		var countryObject = formObject.find('#' + country)
		
		if (countryObject.length != 0) {
		  country = countryObject.val()
		  countryObject.on('change.bfhcountries.data-api', {stateObject: this}, this.changeCountry)
		}
	  }
      
      this.loadStates(country)
    }
    
    , loadStates: function (country) {
      var value = this.options.state
      
      this.$element.html('')
      this.$element.append('<option value=""></option>')
      for (var state in BFHStatesList[country]) {
        this.$element.append('<option value="' + BFHStatesList[country][state]['code'] + '">' + BFHStatesList[country][state]['name'] + '</option>')
      }
      
      this.$element.val(value)
    }
    
    , changeCountry: function (e) {
        var $this = $(this)
        var stateObject = e.data.stateObject
        var country = $this.val()
        
        stateObject.loadStates(country)
    }
    
    , addBootstrapStates: function() {
      var country = this.options.country
      
      if (country != "") {
        var formObject = this.$element.closest('form')
        var countryObject = formObject.find('#' + country)
        
        if (countryObject.length != 0) {
          country = countryObject.find('input[type="hidden"]').val()
          countryObject.find('input[type="hidden"]').on('change.bfhcountries.data-api', {stateObject: this}, this.changeBootstrapCountry)
        }
      }
      
      this.loadBootstrapStates(country)
    }
    
    , loadBootstrapStates: function(country) {
      var $input
      , $toggle
      , $options
      
      var value = this.options.state
      
      $input = this.$element.find('input[type="hidden"]')
      $toggle = this.$element.find('.bfh-selectbox-option')
      $options = this.$element.find('[role=option]')
      
      $options.html('')
      $options.append('<li><a tabindex="-1" href="#" data-option=""></a></li>')
      for (var state in BFHStatesList[country]) {
        $options.append('<li><a tabindex="-1" href="#" data-option="' + BFHStatesList[country][state]['code'] + '">' + BFHStatesList[country][state]['name'] + '</a></li>')
      }
      
      $toggle.data('option', value)
      if (typeof BFHStatesList[country][value] == "undefined") {
        $toggle.html('')
      } else {
        $toggle.html(BFHStatesList[country][value])
      }
      
      $input.val(value)
    }
    
    , changeBootstrapCountry: function (e) {
        var $this = $(this)
        var stateObject = e.data.stateObject
        var country = $this.val()
        
        stateObject.loadBootstrapStates(country)
    }
    
    , displayState: function () {
      var country = this.options.country;
      var state_code = this.options.state;
      var state_name = "";
      for (var state_id in BFHStatesList[country]) {
        if (BFHStatesList[country][state_id]["code"] === state_code) {
          state_name = BFHStatesList[country][state_id]["name"];
          break;
        }
      }
      this.$element.html(state_name);
    }

  }


 /* STATES PLUGIN DEFINITION
  * ======================= */

  $.fn.bfhstates = function (option) {
    return this.each(function () {
      var $this = $(this)
        , data = $this.data('bfhstates')
        , options = typeof option == 'object' && option
        
      if (!data)
          $this.data('bfhstates', (data = new BFHStates(this, options)))
      if (typeof option == 'string')
          data[option]()
    })
  }

  $.fn.bfhstates.Constructor = BFHStates

  $.fn.bfhstates.defaults = {
    country: "",
    state: ""
  }
  

 /* STATES DATA-API
  * ============== */

  $(window).on('load', function () {
    $('form select.bfh-states, span.bfh-states, div.bfh-states').each(function () {
      var $states = $(this)

      $states.bfhstates($states.data())
    })
  })


}(window.jQuery);

