$(function(){
 
    // add multiple select / deselect functionality
    $("#selectall").click(function () {
          $('.case').attr('checked', this.checked);
    });
 
    // if all case are selected, check the selectall case
    // and viceversa
    $(".case").click(function(){
 
        if($(".case").length == $(".case:checked").length) {
            $("#selectall").attr("checked", "checked");
        } else {
            $("#selectall").removeAttr("checked");
        }
 
    });

    // add multiple select / deselect functionality
    $("#selectall1").click(function () {
          $('.case1').attr('checked', this.checked);
    });
 
    // if all case are selected, check the selectall case
    // and viceversa
    $(".case1").click(function(){
 
        if($(".case1").length == $(".case1:checked").length) {
            $("#selectall1").attr("checked", "checked");
        } else {
            $("#selectall1").removeAttr("checked");
        }
 
    });
    
    // add multiple select / deselect functionality
    $("#selectall1").click(function () {
          $('.case1').attr('checked', this.checked);
    });
 
    // if all case are selected, check the selectall case
    // and viceversa
    $(".case2").click(function(){
 
        if($(".case2").length == $(".case2:checked").length) {
            $("#selectall2").attr("checked", "checked");
        } else {
            $("#selectall2").removeAttr("checked");
        }
 
    });
});

jQuery.expr[':'].contains = function(a, i, m) {
  return jQuery(a).text().toUpperCase()
      .indexOf(m[3].toUpperCase()) >= 0;
};