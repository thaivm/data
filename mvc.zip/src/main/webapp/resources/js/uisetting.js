function createJSON(){
    var JSON = {
        "mid":"",
        "locale":"",
        "logo":"",
        "company":"",
        "forcePopup":"",
        "Page":{
            "WelcomePage":{
                "backgroudColor":{"visible":false,"value":""},
                "logo":{"visible":false,"value":""},
                "description":{"visible":false,"value":""}
            },
            "LandingPage":{
                "catalog":{
                    "visible":false,
                    "position":{
                        "top":523,
                        "left":251.03125,
                        "index":""
                    },
                    "type":{
                        "Checkout":false,
                        "Hero":false,
                        "Swifeforpage":false,
                        "Slider":false,
                        "List":false,
                        "Text":false
                    }
                },
                "newProducts":{
                    "visible":false,
                    "position":{
                        "top":572,
                        "left":251.03125,
                        "index":""
                    },
                    "type":{
                        "Checkout":false,
                        "Hero":false,
                        "Swifeforpage":false,
                        "Slider":false,
                        "List":false,
                        "Text":false
                    }
                },
                "coupons":{
                    "visible":false,
                    "position":{
                        "top":670,
                        "left":251.03125,
                        "index":""
                    },
                    "type":{
                        "Checkout":false,
                        "Hero":false,
                        "Swifeforpage":false,
                        "Slider":false,
                        "List":false,
                        "Text":false
                    }
                },
                "promotions":{
                    "visible":false,
                    "position":{
                        "top":621,
                        "left":251.03125,
                        "index":""
                    },
                    "type":{
                        "Checkout":false,
                        "Hero":false,
                        "Swifeforpage":false,
                        "Slider":false,
                        "List":false,
                        "Text":false
                    }
                }
            }
        }
    }
    return JSON;
}

function loadJSON(mid){
    var url = window.location.origin + "/AdminPortal/resources/json/" + mid + ".json";
    console.log(url);
    $.ajax({
        dataType: "json",
        url: url,
        success: function(res) {
            loadValueJSON(res);
        },
        failure: function(res) {
            var json = createJSON();
            json.mid = mid;
            loadValueJSON(json);
        },
        error: function(res) {
            var json = createJSON();
            json.mid = mid;
            loadValueJSON(json);
        }

    });
}

function loadValueJSON(json) {

    // load welcome page
    $('#selectMerchant').val(json.mid).trigger('liszt:updated');
    $("#backgroundColor").prop("checked" , json.Page.WelcomePage.backgroudColor.visible);
    changeCheckbox($("#backgroundColor")[0]);
    $("#logo").prop("checked", json.Page.WelcomePage.logo.visible);
    changeCheckbox($("#logo")[0]);
    $("#description").prop("checked", json.Page.WelcomePage.description.visible);
    changeCheckbox($("#description")[0]);
    $("#description-val").val(json.Page.WelcomePage.description.value);
    // load landing page
    // load widget catalog
    $("#Catalog").prop("checked", json.Page.LandingPage.catalog.visible);
    changeCheckbox($("#Catalog")[0]);
    checkBoxToggle($("#Catalog")[0], "Catalog");
    $("#catalog-checkout").prop("checked", json.Page.LandingPage.catalog.type.Checkout);
    changeCheckbox($("#catalog-checkout")[0]);
    $("#catalog-hero").prop("checked", json.Page.LandingPage.catalog.type.Hero);
    changeCheckbox($("#catalog-hero")[0]);
    $("#catalog-swifeforpage").prop("checked", json.Page.LandingPage.catalog.type.Swifeforpage);
    changeCheckbox($("#catalog-swifeforpage")[0]);
    $("#catalog-slider").prop("checked", json.Page.LandingPage.catalog.type.Slider);
    changeCheckbox($("#catalog-slider")[0]);
    $("#catalog-list").prop("checked", json.Page.LandingPage.catalog.type.List);
    changeCheckbox($("#catalog-list")[0]);
    $("#catalog-text").prop("checked", json.Page.LandingPage.catalog.type.Text);
    changeCheckbox($("#catalog-text")[0]);
    // load widget promotions
    $("#promotions").prop("checked", json.Page.LandingPage.promotions.visible);
    checkBoxToggle($("#promotions")[0], "promotions");
    changeCheckbox($("#promotions")[0]);
    $("#promotions-checkout").prop("checked", json.Page.LandingPage.promotions.type.Checkout);
    changeCheckbox($("#promotions-checkout")[0]);
    $("#promotions-hero").prop("checked", json.Page.LandingPage.promotions.type.Hero);
    changeCheckbox($("#promotions-hero")[0]);
    $("#promotions-swifeforpage").prop("checked", json.Page.LandingPage.promotions.type.Swifeforpage);
    changeCheckbox($("#promotions-swifeforpage")[0]);
    $("#promotions-slider").prop("checked", json.Page.LandingPage.promotions.type.Slider);
    changeCheckbox($("#promotions-slider")[0]);
    $("#promotions-list").prop("checked", json.Page.LandingPage.promotions.type.List);
    changeCheckbox($("#promotions-list")[0]);
    $("#promotions-text").prop("checked", json.Page.LandingPage.promotions.type.Text);
    changeCheckbox($("#promotions-text")[0]);
    // load widget coupons
    $("#coupons").prop("checked", json.Page.LandingPage.coupons.visible);
    checkBoxToggle($("#coupons")[0], "coupons");
    changeCheckbox($("#coupons")[0]);
    $("#coupons-checkout").prop("checked", json.Page.LandingPage.coupons.type.Checkout);
    changeCheckbox($("#coupons-checkout")[0]);
    $("#coupons-hero").prop("checked", json.Page.LandingPage.coupons.type.Hero);
    changeCheckbox($("#coupons-hero")[0]);
    $("#coupons-swifeforpage").prop("checked", json.Page.LandingPage.coupons.type.Swifeforpage);
    changeCheckbox($("#coupons-swifeforpage")[0]);
    $("#coupons-slider").prop("checked", json.Page.LandingPage.coupons.type.Slider);
    changeCheckbox($("#coupons-slider")[0]);
    $("#coupons-list").prop("checked", json.Page.LandingPage.coupons.type.List);
    changeCheckbox($("#coupons-list")[0]);
    $("#coupons-text").prop("checked", json.Page.LandingPage.coupons.type.Text);
    changeCheckbox($("#coupons-text")[0]);
    // load widget new-products
    $("#new-products").prop("checked", json.Page.LandingPage.newProducts.visible);
    checkBoxToggle($("#new-products")[0], "new-products");
    changeCheckbox($("#new-products")[0]);
    $("#new-products-checkout").prop("checked", json.Page.LandingPage.newProducts.type.Checkout);
    changeCheckbox($("#new-products-checkout")[0]);
    $("#new-products-hero").prop("checked", json.Page.LandingPage.newProducts.type.Hero);
    changeCheckbox($("#new-products-hero")[0]);
    $("#new-products-swifeforpage").prop("checked", json.Page.LandingPage.newProducts.type.Swifeforpage);
    changeCheckbox($("#new-products-swifeforpage")[0]);
    $("#new-products-slider").prop("checked", json.Page.LandingPage.newProducts.type.Slider);
    changeCheckbox($("#new-products-slider")[0]);
    $("#new-products-list").prop("checked", json.Page.LandingPage.newProducts.type.List);
    changeCheckbox($("#new-products-list")[0]);
    $("#new-products-text").prop("checked", json.Page.LandingPage.newProducts.type.Text);
    changeCheckbox($("#new-products-text")[0]);
    // load position of widget
    $("#pos-catalog").offset({
        top: parseInt(json.Page.LandingPage.catalog.position.top),
        left: parseInt(json.Page.LandingPage.catalog.position.left)
    });
    $("#pos-promotions").offset({
        top: parseInt(json.Page.LandingPage.promotions.position.top),
        left: parseInt(json.Page.LandingPage.promotions.position.left)
    });
    $("#pos-coupons").offset({
        top: parseInt(json.Page.LandingPage.coupons.position.top),
        left: parseInt(json.Page.LandingPage.coupons.position.left)
    });
    $("#pos-new-products").offset({
        top: parseInt(json.Page.LandingPage.newProducts.position.top),
        left: parseInt(json.Page.LandingPage.newProducts.position.left)
    });
    $("#pos-new-products").css("position","");
    $("#pos-catalog").css("position","");
    $("#pos-promotions").css("position","");
    $("#pos-coupons").css("position","");
}

function saveJSON(){
   var json = createJSON();
    // setup common
    json.mid = $("#selectMerchant").val();
    json.locale = "";
    json.forcePopup = "";
    json.company = "";
    json.logo = "";
    // setup welcome page
    json.Page.WelcomePage.backgroudColor.visible = $("#backgroundColor")[0].checked;
    json.Page.WelcomePage.backgroudColor.value = "";
    json.Page.WelcomePage.logo.visible = $("#logo")[0].checked;
    json.Page.WelcomePage.logo.value = "";
    json.Page.WelcomePage.description.visible = $("#description")[0].checked;
    json.Page.WelcomePage.description.value = $("#description-val").val();
    // setup landing page
    // setup widget catalog
    json.Page.LandingPage.catalog.visible = $("#Catalog")[0].checked;
    json.Page.LandingPage.catalog.type.Checkout = $("#catalog-checkout")[0].checked;
    json.Page.LandingPage.catalog.type.Hero = $("#catalog-hero")[0].checked;
    json.Page.LandingPage.catalog.type.Swifeforpage = $("#catalog-swifeforpage")[0].checked;
    json.Page.LandingPage.catalog.type.Slider = $("#catalog-slider")[0].checked;
    json.Page.LandingPage.catalog.type.List = $("#catalog-list")[0].checked;
    json.Page.LandingPage.catalog.type.Text = $("#catalog-text")[0].checked;
    // setup widget promotions
    json.Page.LandingPage.promotions.visible = $("#promotions")[0].checked;
    json.Page.LandingPage.promotions.type.Checkout = $("#promotions-checkout")[0].checked;
    json.Page.LandingPage.promotions.type.Hero = $("#promotions-hero")[0].checked;
    json.Page.LandingPage.promotions.type.Swifeforpage = $("#promotions-swifeforpage")[0].checked;
    json.Page.LandingPage.promotions.type.Slider = $("#promotions-slider")[0].checked;
    json.Page.LandingPage.promotions.type.List = $("#promotions-list")[0].checked;
    json.Page.LandingPage.promotions.type.Text = $("#promotions-text")[0].checked;
    // setup widget coupons
    json.Page.LandingPage.coupons.visible = $("#coupons")[0].checked;
    json.Page.LandingPage.coupons.type.Checkout = $("#coupons-checkout")[0].checked;
    json.Page.LandingPage.coupons.type.Hero = $("#coupons-hero")[0].checked;
    json.Page.LandingPage.coupons.type.Swifeforpage = $("#coupons-swifeforpage")[0].checked;
    json.Page.LandingPage.coupons.type.Slider = $("#coupons-slider")[0].checked;
    json.Page.LandingPage.coupons.type.List = $("#coupons-list")[0].checked;
    json.Page.LandingPage.coupons.type.Text = $("#coupons-text")[0].checked;
    // setup widget new-products
    json.Page.LandingPage.newProducts.visible = $("#new-products")[0].checked;
    json.Page.LandingPage.newProducts.type.Checkout = $("#new-products-checkout")[0].checked;
    json.Page.LandingPage.newProducts.type.Hero = $("#new-products-hero")[0].checked;
    json.Page.LandingPage.newProducts.type.Swifeforpage = $("#new-products-swifeforpage")[0].checked;
    json.Page.LandingPage.newProducts.type.Slider = $("#new-products-slider")[0].checked;
    json.Page.LandingPage.newProducts.type.List = $("#new-products-list")[0].checked;
    json.Page.LandingPage.newProducts.type.Text = $("#new-products-text")[0].checked;
    // setup position of widget
    json.Page.LandingPage.catalog.position.top = $("#pos-catalog").position().top;
    json.Page.LandingPage.catalog.position.left = $("#pos-catalog").position().left;
    json.Page.LandingPage.promotions.position.top = $("#pos-promotions").position().top;
    json.Page.LandingPage.promotions.position.left = $("#pos-promotions").position().left;
    json.Page.LandingPage.coupons.position.top = $("#pos-coupons").position().top;
    json.Page.LandingPage.coupons.position.left = $("#pos-coupons").position().left;
    json.Page.LandingPage.newProducts.position.top = $("#pos-new-products").position().top;
    json.Page.LandingPage.newProducts.position.left = $("#pos-new-products").position().left;

    $.ajax({
        type: "POST",
//        url: "/uisetupsave",
        url: "/AdminPortal/uisetupsave",
        dataType: 'json',
        accept: 'application/json',
        contentType: 'application/json',
        data: JSON.stringify({JSON:json}),
        success: function(res) {
            $("#saveDialog").click();
        },
        failure: function(res) {
            $("#saveDialog").click();
        },
        error: function(res) {
            $("#saveDialog").click();
        }
    });
}

function setIndexOfWidget() {
    var catalog = $("#pos-catalog").position().top();
    var promotions = $("#pos-promotions").position().top();
    var coupons = $("#pos-coupons").position().top();
    var newProducts = $("#pos-new-products").position().top();

    var arr = [catalog, promotions, coupons, newProducts];
    var max = arr[0];
    var min = arr[0];
    for(var i = 0; i < arr.length - 1; i++) {
        for(var j = i + 1; j < arr.length; j++) {
            if(arr[i] < arr[j]) {
                min = arr[i];
            }
            if(arr[i] > arr[j]) {
                max = arr[i];
            }
        }
    }

    JSON.Page.LandingPage.catalog.position = "";
    JSON.Page.LandingPage.promotions.position = "";
    JSON.Page.LandingPage.coupons.position = "";
    JSON.Page.LandingPage.newProducts.position = "";
}

$("#selectMerchant").change(function(){
    var mid = $("#selectMerchant").val();
    loadJSON(mid);
});

$("#uisetting").find(":checkbox").change(function(){
    if(this.checked) {
        $("#parent-" + this.id).find('span').addClass('checked');
    } else {
        $("#parent-" + this.id).find('span').removeClass('checked');
    }
});

function changeCheckbox(el){
    if(el.checked) {
        $("#parent-" + el.id).find('span').addClass('checked');
    } else {
        $("#parent-" + el.id).find('span').removeClass('checked');
    }
}

