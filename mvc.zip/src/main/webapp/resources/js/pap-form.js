function startdatepicker() {
	$("#startDateR").datepicker({
		dateFormat : 'dd-M-yy',
		numberOfMonths : 1,
		onSelect : function(selected) {
			$("#startDateR").datepicker("option", "startDateR", selected);
	}});
	$("#endDateR").datepicker({
		dateFormat : 'dd-M-yy',
		numberOfMonths : 1,
		onSelect : function(selected) {
			$("#endDateR").datepicker("option", "endDateR", selected);
	}});
	$("#startDateC").datepicker({
		dateFormat : 'dd-M-yy',
		numberOfMonths : 1,
		onSelect : function(selected) {
			$("#startDateR").datepicker("option", "startDateC", selected);
	}});
	$("#endDateC").datepicker({
		dateFormat : 'dd-M-yy',
		numberOfMonths : 1,
		onSelect : function(selected) {
			$("#endDateR").datepicker("option", "endDateC", selected);
	}});
	$("#startDateP").datepicker({
		dateFormat : 'dd-M-yy',
		numberOfMonths : 1,
		onSelect : function(selected) {
			$("#startDateP").datepicker("option", "startDateP", selected);
	}});
	$("#endDateP").datepicker({
		dateFormat : 'dd-M-yy',
		numberOfMonths : 1,
		onSelect : function(selected) {
			$("#startDateP").datepicker("option", "startDateP", selected);
	}});
}

function admin_portal_validate(){
    var midTag = $("#admin-portal-mid-merchant");
    if(typeof midTag[0].children[1].children[1] == "undefined") {
        midTag.removeClass("error");
    } else {
        midTag.addClass("error");
    }
    var companyTag = $("#admin-portal-merchantCompany");
    if(typeof companyTag[0].children[1].children[1] == "undefined") {
        companyTag.removeClass("error");
    } else {
        companyTag.addClass("error");
    }
    var contactTag = $("#admin-portal-contactName");
    if(typeof contactTag[0].children[1].children[1] == "undefined") {
        contactTag.removeClass("error");
    } else {
        contactTag.addClass("error");
    }
    var addressTag = $("#admin-portal-address1-merchant");
    if(typeof addressTag[0].children[1].children[1] == "undefined") {
        addressTag.removeClass("error");
    } else {
        addressTag.addClass("error");
    }
    var emailTag = $("#admin-portal-email-merchant");
    if(typeof emailTag[0].children[1].children[1] == "undefined") {
        emailTag.removeClass("error");
    } else {
        emailTag.addClass("error");
    }
    var countryTag = $("#admin-portal-country");
    if(typeof countryTag[0].children[1].children[1] == "undefined") {
        countryTag.removeClass("error");
    } else {
        countryTag.addClass("error");
    }
    var cityTag = $("#admin-portal-city");
    if(typeof cityTag[0].children[1].children[1] == "undefined") {
        cityTag.removeClass("error");
    } else {
        cityTag.addClass("error");
    }
    var postalCodeTag = $("#admin-portal-postalcode");
    if(typeof postalCodeTag[0].children[1].children[1] == "undefined") {
        postalCodeTag.removeClass("error");
    } else {
        postalCodeTag.addClass("error");
    }
    var currencyCodeTag = $("#admin-portal-currency");
    if(typeof currencyCodeTag[0].children[1].children[1] == "undefined") {
        currencyCodeTag.removeClass("error");
    } else {
        currencyCodeTag.addClass("error");
    }
    var phoneNumberCodeTag = $("#admin-portal-phone-merchant");
    if(typeof phoneNumberCodeTag[0].children[1].children[1] == "undefined") {
        phoneNumberCodeTag.removeClass("error");
    } else {
        phoneNumberCodeTag.addClass("error");
    }
}

function confirmDialog(userId, userName, type, url) {
    $("#confirmDialog").click();
    $(".btn-ok").data("id", userId);
    $(".btn-ok").data("type", type);
    $(".btn-ok").data("url", url);
    if(type=="reset-user") {
        $("#confirm-question").text("Are you sure you want to reset password of user " + userName + "?");
    } else if(type == "delete-user"){
        $("#confirm-question").text("Are you sure you want to delete user " + userName + "?");
    } else if(type == "delete-role") {
        $("#confirm-question").text("Are you sure you want to delete profile " + userName + "?");
    }
}

$('.btn-ok').click(function(e){
    var userId = $(".btn-ok").data("id");
    var type = $(".btn-ok").data("type");
    var url = $(".btn-ok").data("url");
    if(type == "delete-user") {
        $.ajax({
            type : "GET",
            url : url + '/admin/deleteuser/' + userId,
            success : function(data) {
                window.location = url + "/admin/manageusers";
            },
            error : function(e) {
                alert(e.status);
            }
        });
    } else if(type == "reset-user") {
        $('#myConfirm').modal('hide');
        $("#ajaxLoading").click();
        $('#myLoading').removeClass("hide");
//        $(".modal-backdrop").css("opacity",0);
        $.ajax({
        type : "GET",
        url : url + '/admin/reseteuser/' + userId,
        success : function(data) {
//            alert("Change password successfull.");
            $('#myLoading').modal('hide');
            alert("Change password successfull.");
            window.location = url + "/admin/manageusers";
        },
        error : function(e) {
            alert(e.status);
        }
		});
    } else if(type == "delete-role") {
        $.ajax({
			type : "POST",
			url : url + '/admin/deleteroles',
			data : {
				accessprofileId : userId
			},
			success : function(data) {
                if(data != "/admin/manageroles") {
                    alert(data);
                } else {
                    window.location = url + "/admin/manageroles";
                }
			},
			error : function(e) {
				alert(e.status);
			}
		});
    }
});

function checkBoxToggle(el, elementName) {
    var tag = $("#" + elementName + "-content");
    if(el.checked == true) {
        tag.removeClass("hide");
    } else {
        tag.addClass("hide");
    }
}

function toggleLandingPage(elementName) {
    var tag = $("#" + elementName + "-content");
    var tagIcon = $("#" + elementName + "-IconToggle");
    if(tagIcon.attr('class') == "icon-chevron-up") {
        tagIcon.removeClass("icon-chevron-up");
        tagIcon.addClass("icon-chevron-down");
        tag.addClass("hide");
    } else {
        tagIcon.removeClass("icon-chevron-down");
        tagIcon.addClass("icon-chevron-up");
        tag.removeClass("hide");
    }
}

function setWidthOfSelectBox() {
    $("#DataTables_Table_0_length").children().children().width(60);
    $(".dataTables_filter").css("float","right");
}

function menuActive(el) {
    $("#" + el + "-menu-left").addClass("active");
}

function loadAccessProfile(roleId, url) {

}

function InitFormUserDetail() {
	var profileType = $("#selectBoxCorpNames option:selected").val();
}

function initLang(lang) {
    /*
    jQuery.getScript('http://www.geoplugin.net/javascript.gp', function()
    {
        if(geoplugin_countryCode().toLocaleLowerCase()!=lang){
            if(confirm('Do you want to change language to' + geoplugin_countryName() + '?')){
                window.location = "?lang=" + geoplugin_countryCode().toLocaleLowerCase()
            }
        }
    });
    */
}

jQuery.expr[':'].contains = function(a, i, m) {
  return jQuery(a).text().toUpperCase()
      .indexOf(m[3].toUpperCase()) >= 0;
};