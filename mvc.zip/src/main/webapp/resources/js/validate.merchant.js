jQuery(function(){
    // validate mid
    jQuery("#mid-merchant").validate({
        expression: "if (VAL) return true; else return false;",
        message: "Please enter the Required field"
    });
    jQuery("#mid-merchant").validate({
        expression: "if (VAL.length < 13) return true; else return false;",
        message: "Maximum length of MID is 12 character!"
    });
    // validate company name
    jQuery("#merchantCompany").validate({
        expression: "if (VAL) return true; else return false;",
        message: "Please enter the Required field"
    });
    jQuery("#merchantCompany").validate({
        expression: "if (VAL.length < 41) return true; else return false;",
        message: "Maximum length of Company name is 40 character!"
    });
    // validate contact name
    jQuery("#contactName").validate({
        expression: "if (VAL) return true; else return false;",
        message: "Please enter the Required field"
    });
    jQuery("#contactName").validate({
        expression: "if (VAL.length < 41) return true; else return false;",
        message: "Maximum length of Contact name is 40 character!"
    });
    // validate address1
    jQuery("#address1-merchant").validate({
        expression: "if (VAL) return true; else return false;",
        message: "Please enter the Required field"
    });
    jQuery("#address1-merchant").validate({
        expression: "if (VAL.length < 26) return true; else return false;",
        message: "Maximum length of address1 is 25 character!"
    });
    // validate address2
    jQuery("#address2").validate({
        expression: "if (VAL.length < 26) return true; else return false;",
        message: "Maximum length of address2 is 25 character!"
    });
    // validate address3
    jQuery("#address3").validate({
        expression: "if (VAL.length < 26) return true; else return false;",
        message: "Maximum length of address3 is 25 character!"
    });
    // validate postalcode
    jQuery("#postalcode").validate({
        expression: "if (VAL) return true; else return false;",
        message: "Please enter the Required field"
    });
    jQuery("#postalcode").validate({
        expression: "if (VAL.length < 11) return true; else return false;",
        message: "Maximum length of postal code is 10 character!"
    });
    // validate phone
    jQuery("#phone-merchant").validate({
        expression: "if (VAL) return true; else return false;",
        message: "Please enter the Required field"
    });
    jQuery("#phone-merchant").validate({
        expression: "if (VAL.match(/^\\+?[0-9\\-\\(\\).\\s]{7,15}$/)) return true; else return false;",
        message: "Please enter a valid Phone number"
    });
    jQuery("#phone-merchant").validate({
        expression: "if (VAL.length < 16) return true; else return false;",
        message: "Maximum length of phone is 15 character!"
    });
    // validate fax-merchant
    jQuery("#fax-merchant").validate({
        expression: "if (VAL.match(/^\\+?[0-9\\-\\(\\).\\s]{7,15}$/)) return true; else {if (VAL) return false; else return true;}",
        message: "Please enter a valid Fax number"
    });
    jQuery("#fax-merchant").validate({
        expression: "if (VAL.length < 16) return true; else return false;",
        message: "Maximum length of fax is 15 character!"
    });
    // validate email
    jQuery("#email-merchant").validate({
        expression: "if (VAL.match(/^[^\\W][a-zA-Z0-9\\_\\-\\.]+([a-zA-Z0-9\\_\\-\\.]+)*\\@[a-zA-Z0-9_]+(\\.[a-zA-Z0-9_]+)*\\.[a-zA-Z]{2,4}$/)) return true; else return false;",
        message: "Please enter a valid Email ID"
    });
    jQuery("#description-merchant").validate({
        expression: "if (VAL.length < 256) return true; else return false;",
        message: "Maximum length of description is 255 character!"
    });
});