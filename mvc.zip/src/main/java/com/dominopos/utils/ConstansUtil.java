package com.dominopos.utils;
public class ConstansUtil {
	// DB Connection Constans
	public static final String SYSTEM_DB = "dominobox";
	// ROLE CONSTANS
    public static final String ADMINISTRATOR 								    = "ADMINISTRATOR";
	// EMPLOYEE SECTION
	public static final String URL_COMMON_INDEX 								= "/common/index";
    public static final String URL_COMMON_HOME 								    = "/common/home";
	public static final String URL_COMMON_LOGIN 								= "/common/login";
	public static final String URL_COMMON 		 								= "/common/";
	public static final String URL_COMMON_OTHER 		 						= "/common";
	public static final String URL_COMMON_LOGIN_FAILED 							= "/common/login?failed=true";
	public static final String URL_COMMON_LOGIN_FAILED_BLOCKED 					= "/common/login?blocked=true";
    public static final String URL_COMMON_ACCESS_DENIED 						= "/common/accessDenied";
    // REPORT URL
    public static final String URL_REPORT_HOME               					= "/report/home";
    // AUDIT URL
    public static final String URL_AUDIT_HOME               					= "/audit/home";
    // TRANSACTION URL
    public static final String URL_TRANSACTION_HOME                             = "/transaction/home";
    // MERCHANT MANAGEMENT URL
    public static final String URL_MERCHANT_MANAGEMENT_LIST 					= "merchant/listmerchant";
    public static final String URL_MERCHANT_LIST 					            = "listmerchant";
    public static final String URL_MERCHANT_MANAGEMENT_UPDATE 					= "merchant/updatemerchant";
    public static final String URL_MERCHANT_MANAGEMENT_NEW 					    = "merchant/newmerchant";
	// Mail Constans
	public static final String MAIL_REGISTER_SUBJECT 							= PropertiesUtil.getReSource("mail.register.subject");
	public static final String MAIL_ACTIVE_LINK_PATTERN 						= PropertiesUtil.getReSource("mail.activate.link.template");
    // UI SETUP URL
    public static final String URL_UI_SETUP_INDEX                               = "uisetup/index";
    public static final String URL_UI_SETUP_SAVE_JSON                           = "//uisetupsave";
    // ADMIN SECTION
    public static final String URL_ADMIN 										= "/admin";
    public static final String URL_ADMIN_INDEX 									= "/admin/index";
    public static final String URL_ADMIN_MANAGE_MERCHANTS 						= "/admin/managemerchants";
    public static final String URL_ADMIN_CREATE_MERCHANT 						= "/admin/createmerchant";
    public static final String URL_ADMIN_MAIL_FORM 								= "/admin/mailform";
    public static final String URL_ADMIN_SEND_MAIL 								= "/admin/sendmail";
    public static final String URL_ADMIN_MANAGE_GROUP_DETAIL					= "/admin/groupretailerdetails";
    public static final String URL_ADMIN_CREATE_RETAILER						= "/admin/createretailer";
    public static final String URL_ADMIN_GET_PROFILE_TYPE	 					= "/admin/getprofiletype";
    public static final String URL_ADMIN_CREATE_USER 							= "/admin/createuser";
    public static final String URL_ADMIN_DELETE_USER							= "/admin/deleteuser";
    public static final String URL_ADMIN_RESET_USER								= "/admin/reseteuser";
    public static final String URL_ADMIN_DO_CREATE_USER							= "/admin/docreateuser";
    public static final String URL_ADMIN_VIEW_USER_DETAIL 						= "/admin/userdetail";
    public static final String URL_ADMIN_DO_UPDATE_USER							= "/admin/updateuser";
    public static final String URL_ADMIN_MANAGE_USERS							= "/admin/manageusers";
    public static final String URL_ADMIN_VIEW_TRANSACTION_DETAIL				= "/admin/transactiondetail";
    public static final String URL_ADMIN_VIEW_MERCHANT_DETAIL					= "/admin/merchantdetail";
    public static final String URL_ADMIN_SEARCH_TRANX_RESULT					= "/admin/searchtranxresult";
    public static final String URL_ADMIN_LATEST_REQUESTS						= "/admin/latestrequests";
    public static final String URL_ADMIN_MANAGE_USER_ROLES						= "/admin/manageroles";
    public static final String URL_ADMIN_DELETE_USER_ROLES						= "/admin/deleteroles";
    public static final String URL_ADMIN_CREATE_NEW_ROLE						= "/admin/createrole";
    public static final String URL_ADMIN_VIEW_ROLE_DETAIL						= "/admin/roledetail";
    public static final String URL_ADMIN_GET_ROLE_DETAIL						= "/admin/getroledetail";
    public static final String URL_ADMIN_UPDATE_ROLE_DETAIL						= "/admin/updaterole";
    public static final String URL_ADMIN_ADD_ROLE						        = "/admin/addrole";
    public static final String URL_ADMIN_CREATE_ACCESS_PROFILE					= "/admin/createprofile";
    public static final String URL_ADMIN_SAVE_ACCESS_PROFILE					= "/admin/savecreateprofile";
    public static final String URL_ADMIN_LOGOUT                                 = "/admin/logout";
 	// FORM VALIDATION MESSAGES CONSTANT
    public static final String CURRENCY_FIELD_LENGTH						    = "Maximum length of Currency is 3 character!";
    public static final String MID_FIELD_LENGTH								    = "Maximum length of MID is 12 character!";
    public static final String INPUT_FIELD_REQUIRED								= "input is required!";
    public static final String PASSWORD_FIELD_SIZE_REQUIRED						= "Password between 6 to 12 character";
    public static final String CONFIRM_PASSWORD_FIELD_SIZE_REQUIRED				= "Confirm password between 6 to 12 character";
    public static final String LOGINNAME_FIELD_SIZE_REQUIRED					= "Username between 5 to 12 character";
    public static final String DISPLAY_NAME_FIELD_SIZE_REQUIRED					= "User Login between 5 to 12 character";
    public static final String EMAIL_FIELD_REQUIRED								= "Email is required";
    public static final String HANDPHONE_FIELD_REQUIRED							= "HandPhone is required";
    public static final String EMAIL_FIELD_INVALID								= "Please input valid Email address";
    public static final String EMAIL_TO_ADDRESS_FIELD_REQUIRED					= "To Address is required";
    public static final String EMAIL_SUBJECT_FIELD_REQUIRED						= "Subject is required";
    public static final String EMAIL_TEXT_MSG_REQUIRED							= "Message content is required";
	//LOGIN - LOGOUT
	public static final int MAXIMUM_LOGIN_FAILED_TIME							= 3;
	public static final int INTERVAL_MINUTES_FAILED_TIME						= 15;
    public static final int RANDOM_PASSWORD                                     = 6;
    // Mapper
    public static final String MAP_LIST_USERS_RESULT                                = "LIST_USERS_RESULT";
    public static final String MAP_ACCESS_PROFILE_NAMES                             = "ACCESS_PROFILE_NAMES";
    public static final String MAP_ALL_MERCHANT_NAMES                               = "ALL_MERCHANT_NAMES";
    public static final String MAP_ADD_ERROR                                        = "addError";
    public static final String MAP_NO_USER_MERCHANT_NAMES                           = "NO_USER_MERCHANT_NAMES";
    public static final String MAP_ROLES                                            = "roles";
    public static final String MAP_CHOOSED_MERCHANTNAME                             = "CHOOSED_MERCHANTNAME";
    public static final String MAP_ACCESS_PROFILE_ID                                = "ACCESS_PROFILE_ID";
    public static final String MAP_REFERER_URL                                      = "refererURL";
    public static final String MAP_MAIL_FORM                                        = "mailForm";
    public static final String MAP_IS_VALID_EMAIL                                   = "isValidMail";
    public static final String MAP_LIST_ALL_USERS                                   = "LIST_ALL_USERS";
    public static final String MAP_ALL_ACCESS_PROFILES                              = "ALL_ACCESS_PROFILES";
    public static final String MAP_ACCESS_PROFILES                                  = "AccessProfiles";
    public static final String MAP_PROFILE_FORM                                     = "profileform";
    public static final String MAP_ACCESS_PROFILE_DETAIL                            = "accessProfileDetail";
    public static final String MAP_ROLE_ID                                          = "ROLEID";
    public static final String MAP_LIST_MERCHANT                                    = "merchants";
    public static final String MAP_MERCHANT                                         = "merchant";
    // request param
    public static final String PARAM_PROFILE_NAME                                   = "profileName";
    public static final String PARAM_ACCESS_PROFILE_ID                              = "accessprofileId";
    // model attribute
    public static final String MODEL_ATT_USER_FORM                                  = "userform";
    // string value
    public static final String STR_REFER                                            = "referer";
    public static final String STR_REDIRECT                                         = "redirect:";
    public static final String STR_LOGIN_NAME                                       = "<<login_name>>";
    public static final String STR_ACTIVE_CODE                                      = "<<active_code>>";
    // error
    public static final String ERROR_CONSTRAINT_FOREIGN_KEY                         = "Cannot delete a parent row: a foreign key constraint fails";
    // attribute
    public static final String ATT_USER_CLASS                                       = "USER_CLASS";
    public static final String ATT_USER_PERMISSION                                  = "useraccessprofile-with-permission";

    //DATABASE
    public static final String TABLE_ACTION 									= "action";
    public static final String TABLE_ACTIVITY 									= "activity";
    public static final String TABLE_CATEGORY_PROPERTIES 						= "category_properties";
    public static final String TABLE_CONSUMER 									= "consumer";
    public static final String TABLE_CONSUMER_CHILDS 							= "consumer_childs";
    public static final String TABLE_COUPONS 									= "coupons";
    public static final String TABLE_COUPON_ACTIVES 							= "coupon_actives";
    public static final String TABLE_COUPONS_FILTERS 							= "coupons_filters";
    public static final String TABLE_CRM 										= "crm";
    public static final String TABLE_CRM_BIGGEST_AMOUNT 						= "crm_biggestAmount";
    public static final String TABLE_CRM_MOSTPURCHASED 							= "crm_mostpurchased";
    public static final String TABLE_EVENTS 									= "events";
    public static final String TABLE_MENU 										= "menu";
    public static final String TABLE_MERCHANT 									= "merchant";
    public static final String TABLE_MERCHANT_ACTIVITY 							= "merchant_activity";
    public static final String TABLE_MODULE 									= "module";
    public static final String TABLE_NEWPRODUCT_FILTER 							= "newproduct_filter";
    public static final String TABLE_PERMISSION 								= "permission";
    public static final String TABLE_PRODUCT 									= "product";
    public static final String TABLE_PRODUCT_PRICES 							= "product_prices";
    public static final String TABLE_PRODUCT_PROPERTIES 						= "product_properties";
    public static final String TABLE_PROMOTION 									= "promotion";
    public static final String TABLE_PROMOTION_FILTERS 							= "promotion_filters";
    public static final String TABLE_PROMOTION_TYPES 							= "promotion_types";
    public static final String TABLE_RETAILER 									= "retailer";
    public static final String TABLE_RETAILER_MODULE 							= "retailer_module";
    public static final String TABLE_SHOP_EVENT 								= "shop_event";
    public static final String TABLE_SHOP_EVENT_BONUS 							= "shop_event_bonus";
    public static final String TABLE_TICKET 									= "ticket";
    public static final String TABLE_TICKET_DETAIL 								= "ticket_detail";
    public static final String TABLE_TRANSACTION 								= "transaction";

    //MAP
    public static final String MAPPED_ACTION 									= "action";
    public static final String MAPPED_ACTIVITY 									= "activity";
    public static final String MAPPED_CATEGORY 									= "category";
    public static final String MAPPED_CONSUMER 									= "consumer";
    public static final String MAPPED_COUPON 									= "coupon";
    public static final String MAPPED_CRM 										= "crm";
    public static final String MAPPED_MERCHANT 									= "merchant";
    public static final String MAPPED_MODULE 									= "module";
    public static final String MAPPED_PRODUCT 									= "product";
    public static final String MAPPED_PROMOTION 								= "promotion";
    public static final String MAPPED_PROMOTION_TYPE 							= "promotionType";
    public static final String MAPPED_RETAILER 									= "retailer";
    public static final String MAPPED_SHOP_EVENT 								= "shopEvent";

    //JOIN COLUMN
    public static final String JOINCOLUMN_MID 									= "MID";
    public static final String JOINCOLUMN_CATEGORY_ID 							= "categoryID";
    public static final String JOINCOLUMN_RID 									= "RID";
    public static final String JOINCOLUMN_CID 									= "CID";
    public static final String JOINCOLUMN_PRODUCT_ID 							= "productID";
    public static final String JOINCOLUMN_TICKET_ID 							= "ticketID";
    public static final String JOINCOLUMN_COUPON_ID 							= "couponID";
    public static final String JOINCOLUMN_CRM_ID 								= "crm_ID";
    public static final String JOINCOLUMN_USER_ID 								= "userId";
    public static final String JOINCOLUMN_PROMOTION_TYPE_ID 					= "promTypeId";
    public static final String JOINCOLUMN_MODULE_ID 							= "moduleID";
    public static final String JOINCOLUMN_SHOP_EVENT_ID 						= "shop_event_Id";
    public static final String JOINCOLUMN_ACTION_ID 							= "actionID";
    public static final String JOINCOLUMN_PROMOTION_ID 							= "promotionID";
   	//FetchProfile
	public static final String FETCHPROFILE_MERCHANT_WITH_PRODUCTS 				= "merchant-with-products";
	public static final String MAP_COUPON = "coupon";
}
