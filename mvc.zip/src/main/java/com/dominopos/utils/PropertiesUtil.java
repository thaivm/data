package com.dominopos.utils;

import java.util.Properties;

public class PropertiesUtil{
	
	private static Properties properties;
	
	public PropertiesUtil(String resourcePath,Properties properties){
		this.properties=properties;
	}
	
	public PropertiesUtil() {
	}

	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties){
		this.properties = properties;
	}

	public static String getReSource(String key){
		return properties.getProperty("${" + key + "}");
	}
}
