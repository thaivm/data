package com.dominopos.utils;

import com.dominopos.form.UserForm;
import com.dominopos.model.AuditLog;
import com.dominopos.model.User;
import com.dominopos.model.UserAccessProfile;
import com.dominopos.service.AuditService;
import org.apache.commons.codec.binary.Base64;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

public class CommonUtil {

	protected static Properties properties;
	
	public static String createMessagePasswordContent(User userForm,String message) {
		if(message.contains(ConstansUtil.STR_LOGIN_NAME)){
			message = message.replace(ConstansUtil.STR_LOGIN_NAME, userForm.getUserName());
		}
		if(message.contains(ConstansUtil.STR_ACTIVE_CODE)){
			message = message.replace(ConstansUtil.STR_ACTIVE_CODE, generateActiveCode());
		}
		return message;
	}

	private static String generateActiveCode() {
		return String.valueOf(Long.toHexString(Double.doubleToLongBits(Math.random())));
	}
	
	//ENCRYPT PASSWORD 
	public static String encrypt(final String plaintext) {
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("SHA");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e.getMessage());
        }
        try {
            md.update(plaintext.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e.getMessage());
        }
        byte raw[] = md.digest();
        return (new Base64()).encode(raw).toString();
    }
	
	//Get current and previous month
	public static List<String> getCurrentMonth(){
		Calendar c = Calendar.getInstance();
		List<String> listmonth = new ArrayList<String>();
		int year, month;
		for (int m = 1; m < 4; m++) {
			year = c.get(Calendar.YEAR);
			month = c.get(Calendar.MONTH) + m;
			listmonth.add(" "  + month + " " + year);
		}
		return listmonth;
	}
	public static List<String> getDate(){
		List<String> listdate = new ArrayList<String>();
		for (int date = 1; date < 32; date++) {
			listdate.add(Integer.toString(date));
		}
		return listdate;
	}
	public static List<String> getHour(){
		List<String> listHour = new ArrayList<String>();
		for (int hour = 0; hour < 24; hour++) {
			listHour.add(Integer.toString(hour));
		}
		return listHour;
	}
	public static List<String> getMinute(){
		List<String> listMinute = new ArrayList<String>();
		for (int min = 0; min <= 60; min = min + 10) {
			listMinute.add(Integer.toString(min));
		}
		return listMinute;
	}

	//AUTO GENPASSWORD
	static final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	static Random rnd = new Random();

	public static String randomString( int len ) 
	{
	   StringBuilder sb = new StringBuilder( len );
	   for( int i = 0; i < len; i++ ) 
	      sb.append( AB.charAt( rnd.nextInt(AB.length()) ) );
	   return sb.toString();
	}
	
	 public static String sha256(String base) {
        try{
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(base.getBytes("UTF-8"));
            StringBuffer hexString = new StringBuffer();

            for (int i = 0; i < hash.length; i++) {
                String hex = Integer.toHexString(0xff & hash[i]);
                if(hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch(Exception ex){
           throw new RuntimeException(ex);
        }
    }

   	public static User mergeUser(User userOnForm, User existedUser) {
		existedUser.setUserName(userOnForm.getUserName());
		existedUser.setPassword(userOnForm.getPassword());
		existedUser.setEmailAddress(userOnForm.getEmailAddress());
		existedUser.setHandPhone(userOnForm.getHandPhone());
		existedUser.setUserLogin(userOnForm.getUserLogin());
		return existedUser;
	}

    public static User getUserAccount(UserForm userForm,boolean isNew) {
		User account = new User();
		account.setUserName(userForm.getUserName());
		account.setPassword(userForm.getPassword());
		account.setEmailAddress(userForm.getEmailAddress());
		account.setHandPhone(userForm.getHandPhone());
		account.setUserLogin(userForm.getUserLogin());
		UserAccessProfile accessProfile = new UserAccessProfile();
		accessProfile.setAccessProfileId(userForm.getProfileId());
		account.setAccessProfile(accessProfile);
		//if in case update user form
		if(!isNew){
			account.setUserId(userForm.getUserId());
		}
		account.setCreateDate(new Date());
		return account;
	}

    public static UserForm createUserForm(User userAcc) {
		UserForm userForm = new UserForm();
		userForm.setUserId(userAcc.getUserId());
		userForm.setUserName(userAcc.getUserName());
		userForm.setPassword(userAcc.getPassword());
		userForm.setEmailAddress(userAcc.getEmailAddress());
		userForm.setHandPhone(userAcc.getHandPhone());
		userForm.setUserLogin(userAcc.getUserLogin());
        userForm.setProfileId(userAcc.getAccessProfile().getAccessProfileId());
		return userForm;
	}

    public static String createMessageContent(UserForm userForm,String message) {
		if(message.contains(ConstansUtil.STR_LOGIN_NAME)){
			message = message.replace(ConstansUtil.STR_LOGIN_NAME, userForm.getUserName());
		}
		if(message.contains(ConstansUtil.STR_ACTIVE_CODE)){
			message = message.replace(ConstansUtil.STR_ACTIVE_CODE, generateActiveCode());
		}

		return message;
	}

    /**
	 * Logs an action of the current logged in user.
	 *
	 * @param log	The log message
	 */
	public static void logAudit(String log, AuditService auditService) {
		try {
			// gets current user
			Authentication authen = null;
			AuditLog auditLog = new AuditLog();
			User currentUser = null;
			if(SecurityContextHolder.getContext().getAuthentication() != null){
				authen = SecurityContextHolder.getContext().getAuthentication();
				currentUser = (User) authen.getPrincipal();
				auditLog.setUser(currentUser.getUsername());
			}
			auditLog.setTime(new Date());
			auditLog.setLogContent(log);
			auditService.importAuditLog(auditLog);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
