package com.dominopos.daoimpl;
import com.dominopos.dao.genericHibernateDAO;
import com.dominopos.dao.MenuDAO;
import com.dominopos.model.Menu;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository("MenuDAO")
public class MenuDAOImpl extends genericHibernateDAO<Menu, Long> implements MenuDAO {
	protected MenuDAOImpl() {
		super(Menu.class);
	}
	@Override
	@SuppressWarnings("unchecked")
	public List<Menu> getAllMenusByMenuType(int type) {
		return (List<Menu>) getHibernateTemplate().find("from " + Menu.class.getName() + " where menuType = '" + type + "' ");
	}
}
