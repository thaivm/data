package com.dominopos.daoimpl;
import com.dominopos.dao.genericHibernateDAO;
import com.dominopos.dao.PermissionDAO;
import com.dominopos.model.Permission;
import org.springframework.stereotype.Repository;
@Repository("permissionDao")
public class PermissionDAOImpl extends genericHibernateDAO<Permission, Long> implements PermissionDAO {
	protected PermissionDAOImpl() {
		super(Permission.class);
	}
}
