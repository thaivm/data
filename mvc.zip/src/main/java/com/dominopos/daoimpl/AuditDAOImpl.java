package com.dominopos.daoimpl;
import com.dominopos.dao.AuditDAO;
import com.dominopos.dao.genericHibernateDAO;
import com.dominopos.model.AuditLog;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import java.util.ArrayList;
import java.util.List;
@Repository("AuditDAO")
public class AuditDAOImpl extends genericHibernateDAO<AuditLog, String> implements AuditDAO {
	protected AuditDAOImpl(Session s) {
		super(AuditLog.class, s);
	}
	protected AuditDAOImpl() {
		super(AuditLog.class);
	}
	@SuppressWarnings("unchecked")
	@Transactional
	public List<AuditLog> getAllAuditLog() {
		List<AuditLog> listLog = new ArrayList<AuditLog>();
		listLog = getHibernateTemplate().find("from " + AuditLog.class.getName() +  " order by logId desc");
		return listLog;
	}
	@Transactional
	public boolean insertAuditlog(AuditLog auditlog){
		create(auditlog);
		return true;
	}
}
