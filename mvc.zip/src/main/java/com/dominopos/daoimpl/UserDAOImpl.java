package com.dominopos.daoimpl;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.dominopos.dao.genericHibernateDAO;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.dominopos.dao.UserDAO;
import com.dominopos.model.User;
import com.dominopos.security.UserGrantedAuthority;

@Repository("userDao")
public class UserDAOImpl extends genericHibernateDAO<User, Long> implements	UserDAO {
	protected UserDAOImpl() {
		super(User.class);
	}
	@Transactional
	public User findByLoginName(String loginName) {
		Query query = getSession().getNamedQuery("user.findByLoginName");
		query.setString("name", loginName);
		return (User) query.uniqueResult();
	}
    @Override
    public int deleteAll() {
        return 0;
    }
    @Override
    public void deleteUser(User user) {

    }
    @Override
    public List<User> findEmailUnverified() {
        return null;
    }
    @Override
    public List<User> findEmailUnverifiedWithDate(Date date) {
        return null;
    }
    @Transactional
	public User findByLoginNameAndPassword(String loginName, String password) {
		User user = new User();
		user.setUserName(loginName);
		Example example = Example.create(user);
		Criteria criteria = getSession().createCriteria(User.class);
		criteria.add(example);
		return(User) criteria.uniqueResult();
	}
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<User> findUsersWithEmailingEnding(String emailEnding) {
		User user = new User();
		user.setEmailAddress(emailEnding);
		Example example = Example.create(user);
		example.enableLike(MatchMode.END);
		DetachedCriteria criteria = DetachedCriteria.forClass(User.class);
		criteria.add(example);
		return getHibernateTemplate().findByCriteria(criteria);
	}
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<User> findMaxUsersFromStart(int startRow, int maxRows) {
		DetachedCriteria criteria = DetachedCriteria.forClass(User.class);
		return getHibernateTemplate().findByCriteria(criteria, startRow,
				maxRows);
	}
	@Transactional
	public void updateUser(User user) {
		try{
			getSession().update(user);
		}catch(Exception ex){
			logger.info(ex.getStackTrace());
		}
	}
	@Transactional
	public User getUserByUsername(String loginName) {
		User user = null;
        Criteria criteria = getSession().createCriteria(User.class);
        if(!loginName.equalsIgnoreCase(null)){
            criteria.add(Restrictions.ilike("userName", loginName, MatchMode.EXACT));
        }
        try{
           user = (User) criteria.uniqueResult();
        } catch (Exception ex){
            ex.printStackTrace();
        }
		if(user != null){
			ArrayList<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
			UserGrantedAuthority userAutho = new UserGrantedAuthority(user.getAccessProfile().getAccessProfileName());
			authorities.add(userAutho);
			user.setAuthorities(authorities);
		}
		return user;
	}
    @Override
    public List<User> getUsersExceptAdmin() {
        return null;
    }
}
