package com.dominopos.daoimpl;
import com.dominopos.dao.genericHibernateDAO;
import com.dominopos.dao.UserAccessProfileDAO;
import com.dominopos.model.Permission;
import com.dominopos.model.UserAccessProfile;
import com.dominopos.utils.ConstansUtil;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository("accessProfileDao")
public class UserAccessProfileDAOImpl extends genericHibernateDAO<UserAccessProfile, Long> implements UserAccessProfileDAO {
	
	public UserAccessProfileDAOImpl() {
		super(UserAccessProfile.class);
	}
	@LazyCollection(LazyCollectionOption.TRUE)
	@Fetch(FetchMode.SELECT)
	public List<Permission> getAllPermissionByProfileId(long id){
		return null;
	}
	@Transactional
	public UserAccessProfile createNewUserAccessProfile(UserAccessProfile accessProfile) {
		UserAccessProfile userProfile = new UserAccessProfile();
		try{
			 userProfile  = create(accessProfile);
			 if(userProfile.getPermissions() != null){
				for (Permission permission : userProfile.getPermissions() ){
					permission.setUserAccessProfile(userProfile.getAccessProfileId());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return userProfile;
	}
	@Transactional
	public void updateUserAccessProfile(UserAccessProfile role) {
		getHibernateTemplate().flush();
	 	getHibernateTemplate().update(role);
	}
	@Transactional
	public boolean deleteUserAccessProfile(UserAccessProfile role) {
		try{
			getSession().enableFetchProfile(ConstansUtil.ATT_USER_PERMISSION);
			getSession().delete(role);
		}catch(Exception ex){
			logger.info(ex.getStackTrace());
			return false;
		}
	 	return true;
	}
	@Transactional
	public UserAccessProfile getUserAccessProfileById(long id) {
		getSession().enableFetchProfile(ConstansUtil.ATT_USER_PERMISSION);
		UserAccessProfile role = (UserAccessProfile) getSession().get(UserAccessProfile.class, id);
		getSession().close();
		return role;
	}
	@Transactional
	public int getUserAccessProfileByName(String name) {
		UserAccessProfile role = (UserAccessProfile) getHibernateTemplate().find("from " +  UserAccessProfile.class.getName() + " where accessProfileMemo like " + "'"  + name + "'").get(0);
		int result = 0;
			result = role.getProfileType();
		return result;
	}
	@Override
	@Transactional
	public boolean deleteProfile(UserAccessProfile profile) {
		try{
			getSession().enableFetchProfile(ConstansUtil.ATT_USER_PERMISSION);
			getHibernateTemplate().delete(profile);
			return true;
		}catch(Exception ex){
			logger.info(ex.getStackTrace());
			return false;
		}
	}
}
