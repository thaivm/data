package com.dominopos.daoimpl;
import com.dominopos.dao.genericHibernateDAO;
import com.dominopos.dao.MerchantDAO;
import com.dominopos.model.Merchant;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Repository("merchantDAO")
public class MerchantDAOImpl extends genericHibernateDAO<Merchant, String> implements MerchantDAO{
    public MerchantDAOImpl() {
        super(Merchant.class);
    }
    @Transactional
    public List<Merchant> getListMerchant() {
        return getHibernateTemplate().loadAll(Merchant.class);
    }
    @Transactional
    public void addMerchant(Merchant merchant) {
        getHibernateTemplate().save(merchant);
    }
    @Transactional
    public void updateMerchant(Merchant merchant) {
        getHibernateTemplate().update(merchant);
    }
    @Transactional
    public Merchant searchForMid(String mid) {
        return (Merchant) getHibernateTemplate().get(Merchant.class, mid);
    }
    @Override
	public Map<String, String> getAllMerchantNames() {
		List<Merchant> allMerchants = findAll();
		Map<String,String> names = new HashMap<String, String>();
		for(Merchant merchant : allMerchants){
			names.put(merchant.getMid(),merchant.getMerchantCompany());
		}
		return names;
	}
    @Override
	public List<Merchant> getAllMerchantsHaveNoUser() {
		List<Merchant> merchants = null;
        merchants = findAll();
		return merchants;
	}
}
