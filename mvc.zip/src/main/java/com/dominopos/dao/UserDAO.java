package com.dominopos.dao;
import com.dominopos.model.User;

import java.util.Date;
import java.util.List;
public interface UserDAO extends genericDAO<User, Long> {
	public User findByLoginName(String loginName);
	public int deleteAll();
	public void deleteUser(User user);
	public List<User> findEmailUnverified();
	public List<User> findEmailUnverifiedWithDate(Date date);
	public List<User> findUsersWithEmailingEnding(String emailEnding);
	public List<User> findMaxUsersFromStart(int startRow, int maxRows);
	public void updateUser(User user);
	public User findByLoginNameAndPassword(String loginName,
			String password);
	public User getUserByUsername(String userName);
	public List<User> getUsersExceptAdmin();
}
