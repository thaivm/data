package com.dominopos.dao;
import com.dominopos.model.Permission;
public interface PermissionDAO extends genericDAO<Permission, Long> {
}
