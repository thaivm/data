package com.dominopos.dao;
import com.dominopos.model.Merchant;

import java.util.List;
import java.util.Map;
public interface MerchantDAO {
    public List<Merchant> getListMerchant();
    public void addMerchant(Merchant merchant);
    public void updateMerchant(Merchant merchant);
    public Merchant searchForMid(String mid);
    public Map<String, String> getAllMerchantNames();
    public List<Merchant> getAllMerchantsHaveNoUser();
}
