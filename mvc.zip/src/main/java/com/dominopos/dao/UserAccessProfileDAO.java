package com.dominopos.dao;
import com.dominopos.model.UserAccessProfile;
public interface UserAccessProfileDAO extends genericDAO<UserAccessProfile,Long> {
	public UserAccessProfile createNewUserAccessProfile(UserAccessProfile accessProfile);
	public void updateUserAccessProfile(UserAccessProfile role);
	public UserAccessProfile getUserAccessProfileById(long id);
	public boolean deleteUserAccessProfile(UserAccessProfile role);
	public boolean deleteProfile(UserAccessProfile profile);
	public int getUserAccessProfileByName(String name);
}
