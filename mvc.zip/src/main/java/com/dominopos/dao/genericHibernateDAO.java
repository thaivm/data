package com.dominopos.dao;
import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;
public abstract class genericHibernateDAO<T, ID extends Serializable> extends HibernateDaoSupport
		implements genericDAO<T, ID> {
	private Class<T> persistentClass;
	protected Session session;
	protected genericHibernateDAO(Class<T> persistentClass) {
        this.persistentClass = persistentClass;
    }
	protected genericHibernateDAO(Class<T> persistentClass, Session session) {
        this.persistentClass = persistentClass;
        this.session=session;
    }
	@SuppressWarnings("unchecked")
	@Transactional
	public T findById(ID id) {
		T entity=(T)getHibernateTemplate().get(persistentClass, id);
		
		return entity;
	}
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<T> findAll() {
		return (List<T>)  getHibernateTemplate().find("from "+ persistentClass.getName());
	}
	@Transactional
	public T create(T entity) {
		getHibernateTemplate().saveOrUpdate(entity);
		return entity;
	}
	@Transactional
	public void update(T entity) {
		getHibernateTemplate().flush();
		getHibernateTemplate().update(entity);
	}
	@Transactional
	public void delete(T entity) {
		getHibernateTemplate().delete(entity);
	}
	@Transactional
	public void delete(ID id) {
		T entity = findById(id);
		if(entity!=null){
			getHibernateTemplate().delete(entity);
		}
	}
}
