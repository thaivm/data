package com.dominopos.dao;
import java.io.Serializable;
import java.util.List;
public interface genericDAO<T, ID extends Serializable> {
	T findById(ID id);
	void update(T entity);
	List<T> findAll();
	T create(T entity);
	void delete(T entity);
	void delete(ID id);
	/**
	 * Affects every managed instance in the current persistence context!
	 */
}
