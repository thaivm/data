package com.dominopos.dao;
import com.dominopos.model.AuditLog;
import java.util.List;
public interface AuditDAO extends genericDAO<AuditLog, String> {
	public List<AuditLog> getAllAuditLog();
	public boolean insertAuditlog(AuditLog auditlog);
}
