package com.dominopos.dao;
import com.dominopos.model.Menu;

import java.util.List;
public interface MenuDAO extends genericDAO<Menu, Long> {
	public List<Menu> getAllMenusByMenuType(int type);
}
