package com.dominopos.form;
import com.dominopos.utils.ConstansUtil;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import java.util.List;
public class MailForm {
	@NotEmpty(message= ConstansUtil.EMAIL_TO_ADDRESS_FIELD_REQUIRED)
	private String toAddresses;
	@NotBlank(message=ConstansUtil.EMAIL_SUBJECT_FIELD_REQUIRED)
	private String subject;
	@NotBlank(message=ConstansUtil.EMAIL_TEXT_MSG_REQUIRED)
	private String textMsg;
	private List<CommonsMultipartFile> attachFiles;
	public MailForm() {
		super();
	}
	public MailForm(String toAddresses, String subject, String textMsg,
			List<CommonsMultipartFile> attachFiles) {
		super();
		this.toAddresses = toAddresses;
		this.subject = subject;
		this.textMsg = textMsg;
		this.attachFiles = attachFiles;
	}
	public String getToAddresses() {
		return toAddresses;
	}
	public void setToAddresses(String toAddresses) {
		this.toAddresses = toAddresses;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getTextMsg() {
		return textMsg;
	}
	public void setTextMsg(String textMsg) {
		this.textMsg = textMsg;
	}
	public List<CommonsMultipartFile> getAttachFiles() {
		return attachFiles;
	}
	public void setAttachFiles(List<CommonsMultipartFile> attachFiles) {
		this.attachFiles = attachFiles;
	}
}
