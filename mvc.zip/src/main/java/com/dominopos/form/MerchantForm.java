package com.dominopos.form;
import com.dominopos.utils.ConstansUtil;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;
public class MerchantForm {
    @Size(message= ConstansUtil.MID_FIELD_LENGTH, max=12)
    @NotEmpty(message = ConstansUtil.INPUT_FIELD_REQUIRED)
    private String mid;
    @NotEmpty(message = ConstansUtil.INPUT_FIELD_REQUIRED)
    private String merchantCompany;
    @NotEmpty(message = ConstansUtil.INPUT_FIELD_REQUIRED)
    private String contactName;
    @NotEmpty(message = ConstansUtil.INPUT_FIELD_REQUIRED)
    private String address1;
    private String address2;
    private String address3;
    @NotEmpty(message = ConstansUtil.INPUT_FIELD_REQUIRED)
    private String postalCode;
    @NotEmpty(message = ConstansUtil.INPUT_FIELD_REQUIRED)
    private String city;
    @NotEmpty(message = ConstansUtil.INPUT_FIELD_REQUIRED)
    private String country;
    @NotEmpty(message = ConstansUtil.INPUT_FIELD_REQUIRED)
    @Size(message= ConstansUtil.CURRENCY_FIELD_LENGTH, max=3)
    private String currency;
    @NotEmpty(message = ConstansUtil.INPUT_FIELD_REQUIRED)
    private String phoneNumber;
    private String faxNumber;
    @NotEmpty(message = ConstansUtil.INPUT_FIELD_REQUIRED)
    @Email(message=ConstansUtil.EMAIL_FIELD_INVALID)
    private String email;
    private String merchantDescription;
    private boolean active;
    public String getMid() {
        return mid;
    }
    public void setMid(String mid) {
        this.mid = mid;
    }
    public String getMerchantCompany() {
        return merchantCompany;
    }
    public void setMerchantCompany(String merchantCompany) {
        this.merchantCompany = merchantCompany;
    }
    public String getContactName() {
        return contactName;
    }
    public void setContactName(String contactName) {
        this.contactName = contactName;
    }
    public String getAddress1() {
        return address1;
    }
    public void setAddress1(String address1) {
        this.address1 = address1;
    }
    public String getAddress2() {
        return address2;
    }
    public void setAddress2(String address2) {
        this.address2 = address2;
    }
    public String getAddress3() {
        return address3;
    }
    public void setAddress3(String address3) {
        this.address3 = address3;
    }
    public String getPostalCode() {
        return postalCode;
    }
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public String getFaxNumber() {
        return faxNumber;
    }
    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getMerchantDescription() {
        return merchantDescription;
    }
    public void setMerchantDescription(String merchantDescription) {
        this.merchantDescription = merchantDescription;
    }
    public boolean isActive() {
        return active;
    }
    public void setActive(boolean active) {
        this.active = active;
    }
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }
}
