package com.dominopos.form;
import com.dominopos.model.UserAccessProfile;
import com.dominopos.utils.ConstansUtil;
import org.hibernate.validator.constraints.NotEmpty;
public class UserAccessProfileForm {
	private long accessProfileId;
	private String accessProfileName;
	@NotEmpty(message= ConstansUtil.INPUT_FIELD_REQUIRED)
	private String accessProfileMemo;
	private int profileType;
    private boolean enabled;
	public UserAccessProfileForm(String accessProfileName,
			String accessProfileMemo, int profileType) {
		this.accessProfileName = accessProfileName;
		this.accessProfileMemo = accessProfileMemo;
		this.profileType = profileType;
	}
	public UserAccessProfileForm() {}
	public String getAccessProfileName() {
		return accessProfileName;
	}
    public long getAccessProfileId() {
        return accessProfileId;
    }
    public void setAccessProfileId(long accessProfileId) {
        this.accessProfileId = accessProfileId;
    }
    public void setAccessProfileName(String accessProfileName) {
		this.accessProfileName = accessProfileName;
	}
	public String getAccessProfileMemo() {
		return accessProfileMemo;
	}
	public void setAccessProfileMemo(String accessProfileMemo) {
		this.accessProfileMemo = accessProfileMemo;
	}
	public int getProfileType() {
		return profileType;
	}
	public void setProfileType(int profileType) {
		this.profileType = profileType;
	}
    public boolean isEnabled() {
        return enabled;
    }
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    public static UserAccessProfile convertToUserAccessProfile(UserAccessProfileForm userAccessProfileForm) {
        UserAccessProfile userAccessProfile = new UserAccessProfile();
        userAccessProfile.setAccessProfileMemo(userAccessProfileForm.getAccessProfileMemo());
        userAccessProfile.setAccessProfileName(userAccessProfileForm.getAccessProfileName());
        userAccessProfile.setProfileType(userAccessProfileForm.getProfileType());
        if(userAccessProfileForm.getProfileType() == 1) {
            userAccessProfile.setAccessProfileName("ADMINISTRATOR");
        } else if(userAccessProfileForm.getProfileType() == 2){
            userAccessProfile.setAccessProfileName("CONSUMER");
        } else if(userAccessProfileForm.getProfileType() == 3) {
            userAccessProfile.setAccessProfileName("MERCHANT");
        }
        userAccessProfile.setEnabled(userAccessProfileForm.isEnabled());
        return userAccessProfile;
    }
}
