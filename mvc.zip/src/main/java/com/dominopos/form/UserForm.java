package com.dominopos.form;
import com.dominopos.utils.CommonUtil;
import com.dominopos.utils.ConstansUtil;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;
import java.io.Serializable;
public class UserForm implements Serializable {
	private static final long serialVersionUID = 1L;
	private long userId;
	@Size(min=5,max=100,message= ConstansUtil.LOGINNAME_FIELD_SIZE_REQUIRED)
	private String userName;
	@Size(min=5,max=100,message=ConstansUtil.DISPLAY_NAME_FIELD_SIZE_REQUIRED)
	private String userLogin;
	@Size(min=6,max=100,message=ConstansUtil.PASSWORD_FIELD_SIZE_REQUIRED)
	private String password;
	@Size(min=6,max=20,message=ConstansUtil.CONFIRM_PASSWORD_FIELD_SIZE_REQUIRED)
	private String confirmPassword;
	@NotEmpty(message=ConstansUtil.EMAIL_FIELD_REQUIRED)
	@Email(message=ConstansUtil.EMAIL_FIELD_INVALID)
	private String emailAddress;
	@NotEmpty(message=ConstansUtil.HANDPHONE_FIELD_REQUIRED)
	@Digits(message=ConstansUtil.HANDPHONE_FIELD_REQUIRED, fraction=0, integer= 12)
	private String handPhone;
    private long profileId;
    private String corpId;
    public UserForm() {
    }
    public UserForm(String userName, String password, String emailAddress, String handPhone, long profileId) {
        this.userName = userName;
        this.password = password;
        this.emailAddress = emailAddress;
        this.handPhone = handPhone;
        this.profileId = profileId;
    }
    public String getCorpId() {
        return corpId;
    }
    public void setCorpId(String corpId) {
        this.corpId = corpId;
    }
    public long getProfileId() {
        return profileId;
    }
    public void setProfileId(long profileId) {
        this.profileId = profileId;
    }
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserLogin() {
		return userLogin;
	}
	public void setUserLogin(String displayName) {
		this.userLogin = displayName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = CommonUtil.sha256(password);
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getHandPhone() {
		return handPhone;
	}
	public void setHandPhone(String phoneNumber) {
		this.handPhone = phoneNumber;
	}
}


