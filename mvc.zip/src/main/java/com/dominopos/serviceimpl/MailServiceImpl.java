package com.dominopos.serviceimpl;
import com.dominopos.form.UserForm;
import com.dominopos.model.User;
import com.dominopos.service.MailService;
import com.dominopos.utils.CommonUtil;
import com.dominopos.utils.ConstansUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import java.util.Date;
public class MailServiceImpl implements MailService {
	@Autowired
	private JavaMailSender mailSender;
	@Autowired
	private SimpleMailMessage customeMailMessage;
	public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}
	public void setSimpleMailMessage(SimpleMailMessage customeMailMessage) {
		this.customeMailMessage = customeMailMessage;
	}
	@Override
	public boolean sendSimpleMail(final UserForm userForm,final String mailSubject,
			final String mesgTemplate) {
		boolean result = false;
		try{
			customeMailMessage.setText(String.format(customeMailMessage.getText(),userForm.getUserName(), CommonUtil.createMessageContent(userForm, ConstansUtil.MAIL_ACTIVE_LINK_PATTERN)));
			customeMailMessage.setSubject(ConstansUtil.MAIL_REGISTER_SUBJECT);
			customeMailMessage.setTo(userForm.getEmailAddress());
			customeMailMessage.setSentDate(new Date());
			mailSender.send(customeMailMessage);
			result = true;
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return result;
	}
	@Override
	public boolean resetSimpleMail(final User user, final String mailSubject, final String mesgTemplate) {
		boolean result = false;
		
		try{
			customeMailMessage.setText(mesgTemplate);
			customeMailMessage.setSubject(mailSubject);
			customeMailMessage.setTo(user.getEmailAddress());
			customeMailMessage.setSentDate(new Date());
			mailSender.send(customeMailMessage);
			result = true;
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return result;
	}
	@Override
	public boolean sendNewPass(final UserForm user, final String mailSubject, final String mesgTemplate) {
		boolean result = false;
		try{
			customeMailMessage.setText(mesgTemplate);
			customeMailMessage.setSubject(mailSubject);
			customeMailMessage.setTo(user.getEmailAddress());
			customeMailMessage.setSentDate(new Date());
			mailSender.send(customeMailMessage);
			result = true;
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return result;
	}
}
