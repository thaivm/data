package com.dominopos.serviceimpl;
import com.dominopos.dao.MenuDAO;
import com.dominopos.dao.PermissionDAO;
import com.dominopos.dao.UserAccessProfileDAO;
import com.dominopos.model.Menu;
import com.dominopos.model.Permission;
import com.dominopos.model.UserAccessProfile;
import com.dominopos.service.SecurityService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
public class SecurityServiceImpl implements SecurityService {
	@Autowired
    private MenuDAO menuDao;
	@Autowired
    private PermissionDAO permissionDao;
	@Autowired
    private UserAccessProfileDAO accessProfileDao;
	public void setMenuDao(MenuDAO menuDao) {
		this.menuDao = menuDao;
	}
	public void setPermissionDao(PermissionDAO permissionDao) {
		this.permissionDao = permissionDao;
	}
    public void setAccessProfileDao(UserAccessProfileDAO accessProfileDao) {
        this.accessProfileDao = accessProfileDao;
    }
    @Override
	public List<Menu> getAllMenus(){
		return menuDao.findAll();
	}
	@Override
	public List<Permission> getUserPermissions(long id){
		UserAccessProfile accessProfile = accessProfileDao.findById(id);
		return accessProfile.getPermissions();
	}
	@Override
	public List<Menu> getAllMenusByMenuType(int type) {
		return menuDao.getAllMenusByMenuType(type);
	}
}
