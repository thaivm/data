package com.dominopos.serviceimpl;

import com.dominopos.dao.UserAccessProfileDAO;
import com.dominopos.dao.UserDAO;
import com.dominopos.form.UserForm;
import com.dominopos.model.Merchant;
import com.dominopos.model.User;
import com.dominopos.model.UserAccessProfile;
import com.dominopos.service.UserService;
import com.dominopos.utils.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDao;
	
	private User user;

    @Autowired
	private UserAccessProfileDAO accessProfileDao;

    public UserDAO getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDAO userDao) {
		this.userDao = userDao;
	}

	public User getUser(Long id) {
		return userDao.findById(id);
	}

    @Override
    public List<User> getUserByCorpId(Merchant merchant) {
        return null;
    }

    public List<User> getUsers() {
		return userDao.findAll();
	}
	public void updateUser(User vVUser){
		userDao.update(vVUser);
	}

    @Override
    public void deleteUser(User vVUser) {
        try{
			userDao.deleteUser(vVUser);
		}catch(Exception ex){
			ex.printStackTrace();
		}
    }

    @Override
    public void deleteUser(long id) {
        user = getUser(id);
		deleteUser(user);
    }

    public UserDAO getUserAccountDao() {
		return userDao;
	}

	public void setUserAccountDao(UserDAO userAccountDao) {
		this.userDao = userAccountDao;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public User getUserByUsername(String userName) {
		return userDao.getUserByUsername(userName);
	}

    @Override
    public List<User> getUsersExceptAdmin() {
        return userDao.getUsersExceptAdmin();
    }

    @Override
    public Map<String, String> getAllRoleNames() {
        List<UserAccessProfile> profiles = accessProfileDao.findAll();
        Map<String,String> accessProfileNames = new HashMap<String,String>();
		for(UserAccessProfile profile : profiles){
			accessProfileNames.put(String.valueOf(profile.getAccessProfileId()), profile.getAccessProfileMemo());
		}
		return accessProfileNames;
    }

    @Override
    public void deleteRoleById(Long role) {
        accessProfileDao.delete(role);
    }

    @Override
    public List<User> getAllUsers() {
        return userDao.findAll();
    }

    @Override
    public int getUserAccessProfileByName(String name) {
        return accessProfileDao.getUserAccessProfileByName(name);
    }

    @Override
    public void addUser(UserForm userForm) {
        try{
            User userAcc = CommonUtil.getUserAccount(userForm, true);
            userDao.create(userAcc);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    @Override
    public boolean updateForm(UserForm userForm) {
        boolean result = false;
        User userOnForm= CommonUtil.getUserAccount(userForm,false);
        String currentPass = userOnForm.getPassword();
        User existedUser = userDao.findById(userOnForm.getUserId());
        try{
            if(existedUser!=null){
                if(CommonUtil.sha256(CommonUtil.sha256((existedUser.getPassword()))).equals(currentPass)){
                    userOnForm.setPassword(existedUser.getPassword());
                }
                User newUser = CommonUtil.mergeUser(userOnForm,existedUser);
                newUser.setLastModified(new Date());
                userDao.update(newUser);
                result = true;
            }else{
                return false;
            }
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        return result;
    }

    @Override
	public List<UserAccessProfile> getAllRoles() {
		return accessProfileDao.findAll();
	}

    @Override
	public UserAccessProfile createNewUserAccessProfile(UserAccessProfile role) {
		return accessProfileDao.createNewUserAccessProfile(role);
	}

    @Override
	public void updateUserAccessProfile(UserAccessProfile role) {
		accessProfileDao.updateUserAccessProfile(role);
	}

    @Override
	public UserAccessProfile getUserAccessProfileById(long id) {
		return accessProfileDao.getUserAccessProfileById(id);
	}
}
