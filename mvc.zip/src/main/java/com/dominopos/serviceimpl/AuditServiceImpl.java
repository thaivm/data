package com.dominopos.serviceimpl;
import com.dominopos.dao.AuditDAO;
import com.dominopos.model.AuditLog;
import com.dominopos.service.AuditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class AuditServiceImpl implements AuditService {
	@Autowired
	public AuditDAO auditDao;
	
	public AuditDAO getAuditDao() {
		return auditDao;
	}
	public void setAuditDao(AuditDAO auditDao) {
		this.auditDao = auditDao;
	}
	@Override
	public void importAuditLog(AuditLog auditLog) {
		auditDao.insertAuditlog(auditLog);
	}
	@Override
	public List<AuditLog> getAllAuditLogs() {
		return auditDao.getAllAuditLog();
	}
}
