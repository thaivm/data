package com.dominopos.serviceimpl;
import com.dominopos.dao.MerchantDAO;
import com.dominopos.model.Merchant;
import com.dominopos.service.MerchantService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class MerchantServiceImpl implements MerchantService{
    @Autowired
    private MerchantDAO merchantDAO;
    @Override
    public List<Merchant> getListMerchant() {
        return merchantDAO.getListMerchant();
    }
    @Override
    public void addMerchant(Merchant merchant) {
        merchantDAO.addMerchant(merchant);
    }
    @Override
    public void updateMerchant(Merchant merchant) {
        merchantDAO.updateMerchant(merchant);
    }
    @Override
    public Merchant searchForMid(String mid){
        return merchantDAO.searchForMid(mid);
    }
    @Override
    public Map<String, String> getAllMerchantsName() {
        return merchantDAO.getAllMerchantNames();
    }
    public MerchantDAO getMerchantDAO() {
        return merchantDAO;
    }
    public void setMerchantDAO(MerchantDAO merchantDAO) {
        this.merchantDAO = merchantDAO;
    }
    @Override
	public Map<String, String> getAllMerchantsNameHaveNoUser() {
		List<Merchant> merchants = merchantDAO.getAllMerchantsHaveNoUser();
		Map<String,String> merchantNames = new HashMap<String,String>();
		for(Merchant merchant : merchants){
			merchantNames.put(merchant.getMid(), merchant.getMerchantCompany() + " - " + merchant.getMid());
		}
		return merchantNames;
	}
}
