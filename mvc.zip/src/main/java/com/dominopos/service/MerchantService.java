package com.dominopos.service;
import com.dominopos.model.Merchant;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
@Service
public interface MerchantService {
    public List<Merchant> getListMerchant();
    public void addMerchant(Merchant merchant);
    public void updateMerchant(Merchant merchant);
    public Merchant searchForMid(String mid);
    public Map<String, String> getAllMerchantsName();
    public Map<String,String> getAllMerchantsNameHaveNoUser();
}
