package com.dominopos.service;
import com.dominopos.form.UserForm;
import com.dominopos.model.User;
public interface MailService {
	public boolean sendSimpleMail(UserForm userForm, String mailSubject,
                                  String mesgTemplate);
	boolean resetSimpleMail(User user, String mailSubject, String mesgTemplate);
	boolean sendNewPass(UserForm user, String mailSubject, String mesgTemplate);
}