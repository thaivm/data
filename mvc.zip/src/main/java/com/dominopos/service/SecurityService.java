package com.dominopos.service;
import com.dominopos.model.Menu;
import com.dominopos.model.Permission;

import java.util.List;
public interface SecurityService {
	public List<Menu> getAllMenus();
	public List<Menu> getAllMenusByMenuType(int type);
	public List<Permission> getUserPermissions(long id);
}
