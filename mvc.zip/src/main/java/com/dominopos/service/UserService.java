package com.dominopos.service;
import com.dominopos.form.UserForm;
import com.dominopos.model.Merchant;
import com.dominopos.model.User;
import com.dominopos.model.UserAccessProfile;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
@Service
public interface UserService {
	public List<User> getUsers() ;
	public void updateUser(User vVUser);
	public void deleteUser(User vVUser);
	public void deleteUser(long id);
	public User getUser(Long id);
	public List<User> getUserByCorpId(Merchant merchant);
	public User getUserByUsername(String userName);
	public List<UserAccessProfile> getAllRoles();
	public List<User> getUsersExceptAdmin();
	public void addUser(UserForm userForm);
	public boolean updateForm(UserForm userform);
	public Map<String,String> getAllRoleNames();
	public UserAccessProfile createNewUserAccessProfile(UserAccessProfile role);
	public void updateUserAccessProfile(UserAccessProfile role);
	public UserAccessProfile getUserAccessProfileById(long id);
	public void deleteRoleById(Long id);
	public List<User> getAllUsers();
	public int getUserAccessProfileByName(String name);
}
