package com.dominopos.service;

import com.dominopos.model.AuditLog;

import java.util.List;

public interface AuditService {

	public void importAuditLog(AuditLog auditLog);
	
	public List<AuditLog> getAllAuditLogs();

}
