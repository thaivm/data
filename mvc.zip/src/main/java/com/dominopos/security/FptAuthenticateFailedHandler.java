package com.dominopos.security;
import com.dominopos.model.User;
import com.dominopos.service.UserService;
import com.dominopos.utils.ConstansUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
public class FptAuthenticateFailedHandler implements AuthenticationFailureHandler{
	@Autowired
	private UserService userService;
    public UserService getUserService() {
        return userService;
    }
    public void setUserService(UserService userService) {
        this.userService = userService;
    }
    @Override
	public void onAuthenticationFailure(HttpServletRequest request,
			HttpServletResponse response, AuthenticationException authentication)
			throws IOException, ServletException {
		try{
			String loginName = authentication.getAuthentication().getName();
			User user = userService.getUserByUsername(loginName);
			if(user!=null){
				if(user.getLoginFailedCount() >= ConstansUtil.MAXIMUM_LOGIN_FAILED_TIME){
					user.setLoginFailedCount(user.getLoginFailedCount()+1);
					user.setPasswordValidity(new Date());
					userService.updateUser(user);
					//Block User
					response.sendRedirect(request.getContextPath() + ConstansUtil.URL_COMMON_LOGIN_FAILED_BLOCKED);
				}
				else{
					user.setLoginFailedCount(user.getLoginFailedCount()+1);
					user.setPasswordValidity(new Date());
					userService.updateUser(user);
					response.sendRedirect(request.getContextPath() + ConstansUtil.URL_COMMON_LOGIN_FAILED);
				}
			} else {
				response.sendRedirect(request.getContextPath() + ConstansUtil.URL_COMMON_LOGIN_FAILED);
			}
		}catch(Exception ex){
            ex.printStackTrace();
		}
	}
}
