package com.dominopos.security;
import com.dominopos.dao.UserDAO;
import com.dominopos.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
public class SecurityServiceImpl implements UserDetailsService{
	@Autowired
	private UserDAO userDao;
	public UserDAO getUserDao() {
		return userDao;
	}
	public void setUserDao(UserDAO userDao) {
		this.userDao = userDao;
	}
	@Override
	public UserDetails loadUserByUsername(String loginName)
			throws UsernameNotFoundException, DataAccessException {
		User user = null;
		if (loginName != null && !loginName.equals("")) {
			user = userDao.getUserByUsername(loginName);
			if (user == null) {
				return null;
			}
			new UserGrantedAuthority(user.getAccessProfile().getAccessProfileName());
			return user;
		} else {
			return null;
		}
	}
}
