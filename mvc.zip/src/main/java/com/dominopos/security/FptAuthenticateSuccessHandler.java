package com.dominopos.security;

import com.dominopos.model.User;
import com.dominopos.service.AuditService;
import com.dominopos.service.UserService;
import com.dominopos.utils.CommonUtil;
import com.dominopos.utils.ConstansUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;
import java.util.Map;
public class FptAuthenticateSuccessHandler implements AuthenticationSuccessHandler{
	private Map<String, String> roleUrlMap;
	@Autowired
	private UserService userService;
    @Autowired
    private AuditService auditService;
    public UserService getUserService() {
        return userService;
    }
    public void setUserService(UserService userService) {
        this.userService = userService;
    }
    @Override
    public void onAuthenticationSuccess(HttpServletRequest request,
                                        HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {
        if (authentication.getPrincipal() instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            User user = userService.getUserByUsername(userDetails.getUsername());
            HttpSession session = request.getSession();
            session.setAttribute("USER_NAME",  user.getUserName());
            session.setAttribute("USER_ID",  user.getUserId());
            session.setAttribute("USER_CLASS",  user);
            String role = user.getAccessProfile().getAccessProfileName();
            if(role.equals("ADMINISTRATOR")) {
                CommonUtil.logAudit("User: " + user.getUsername() + " login success", auditService);
            } else {
                CommonUtil.logAudit("User: " + user.getUsername() + " Access denis", auditService);
            }
            Date currentTime = new Date();
            Date lastLoginFailed = user.getPasswordValidity();
            int failedTime = user.getLoginFailedCount();
            if(failedTime > ConstansUtil.MAXIMUM_LOGIN_FAILED_TIME ){
                int countTime = currentTime.getMinutes() - lastLoginFailed.getMinutes();
                if(countTime >= ConstansUtil.INTERVAL_MINUTES_FAILED_TIME){
                    user.setLastLogin(new Date());
                    user.setLoginFailedCount(0);
                    userService.updateUser(user);
                    response.sendRedirect(request.getContextPath() + roleUrlMap.get(role));
                } else{
                    user.setLoginFailedCount(user.getLoginFailedCount()+1);
                    user.setPasswordValidity(new Date());
                    userService.updateUser(user);
                    response.sendRedirect(request.getContextPath() + ConstansUtil.URL_COMMON_LOGIN_FAILED_BLOCKED);
                }
            } else{
                user.setLastLogin(new Date());
                user.setLoginFailedCount(0);
                userService.updateUser(user);
                response.sendRedirect(request.getContextPath() + roleUrlMap.get(role));
            }
        }
    }
    public void setRoleUrlMap(Map<String, String> roleUrlMap) {
        this.roleUrlMap = roleUrlMap;
    }
}
