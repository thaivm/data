package com.dominopos.servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
public class HttpServicesServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		PrintWriter writer = resp.getWriter();
		StringBuilder sb = new StringBuilder();
		resp.setContentType("text/xml");
		try{
		    try {
		        BufferedReader reader = req.getReader();
		        String line;
		        do {
		            line = reader.readLine();
		            sb.append(line).append("\n");
		        } while (line != null);
		        // do NOT close the reader here, or you won't be able to get the post data twice
		    } catch(IOException ex) {
                ex.printStackTrace();
		    }
		}catch(Exception ex){
            ex.printStackTrace();
        }
		writer.print("server received data...");
		writer.write("server received data...");
		writer.flush();
		writer.close();
	}
}
