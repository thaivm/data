package com.dominopos.validation;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public class FormValidation implements Validator {
    @Override
    public boolean supports(Class<?> aClass) {
        return false;
    }
    @Override
    public void validate(Object target, Errors errors) {
    }
}
