package com.dominopos.controller;
import com.dominopos.serviceimpl.MerchantServiceImpl;
import com.dominopos.utils.ConstansUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;
@Controller
public class UISetupController {
    @Autowired
    private MerchantServiceImpl merchantService;
    @RequestMapping(value = ConstansUtil.URL_UI_SETUP_INDEX, method = RequestMethod.GET)
	public ModelAndView index(Map<String, Object> map, HttpServletRequest request) {
        map.put(ConstansUtil.MAP_LIST_MERCHANT,merchantService.getListMerchant());
		ModelAndView model = new ModelAndView();
        model.setViewName(ConstansUtil.URL_UI_SETUP_INDEX);
		return model;
	}
}
