package com.dominopos.controller;

import com.dominopos.form.MerchantForm;
import com.dominopos.model.Merchant;
import com.dominopos.model.User;
import com.dominopos.service.AuditService;
import com.dominopos.serviceimpl.MerchantServiceImpl;
import com.dominopos.utils.CommonUtil;
import com.dominopos.utils.ConstansUtil;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;
@Controller
public class MerchantManagementController{
    @Autowired
    private MerchantServiceImpl merchantService;
    @Autowired
    private AuditService auditService;

    /**
	 *
	 * @param map
	 * @return String
	 */
	@RequestMapping(value = ConstansUtil.URL_MERCHANT_MANAGEMENT_LIST, method = RequestMethod.GET)
	public ModelAndView listMerchant(Map<String, Object> map, HttpServletRequest request) {
		ModelAndView model = new ModelAndView(ConstansUtil.URL_MERCHANT_MANAGEMENT_LIST);
        List<Merchant> merchants = merchantService.getListMerchant();
        for(Merchant merchant:merchants){
            String countryCode = merchant.getCountry();
            String cityCode = merchant.getCity();
            String currencyCode = merchant.getCurrency();
            if(countryCode != null && cityCode != null && currencyCode != null) {
                merchant.setCountry(getJson("countries.json").get(countryCode).toString());
                JSONObject states = (JSONObject) getJson("states.json").get(countryCode);
                merchant.setCity(states.get(cityCode).toString());
                merchant.setCurrency(getJson("currencies.json").get(currencyCode).toString());
            }
        }
        map.put(ConstansUtil.MAP_LIST_MERCHANT, merchants);
		return model;
	}
    /**
	 *
	 * @param map
	 * @return String
	 */
	@RequestMapping(value = ConstansUtil.URL_MERCHANT_MANAGEMENT_NEW, method = RequestMethod.GET)
	public ModelAndView addMerchant(Map<String, Object> map, HttpServletRequest request) {
		ModelAndView model = new ModelAndView(ConstansUtil.URL_MERCHANT_MANAGEMENT_NEW);
        map.put(ConstansUtil.MAP_MERCHANT,new Merchant());
		return model;
	}
    /**
	 *
	 * @param map
	 * @return String
	 */
	@RequestMapping(value = ConstansUtil.URL_MERCHANT_MANAGEMENT_UPDATE + "/{path}", method = RequestMethod.GET)
	public ModelAndView openUpdateMerchant(@PathVariable("path") String id, Map<String, Object> map, HttpServletRequest request) {
		ModelAndView model = new ModelAndView(ConstansUtil.URL_MERCHANT_MANAGEMENT_UPDATE);
        Merchant merchant = merchantService.searchForMid(id);
        map.put(ConstansUtil.MAP_MERCHANT, merchant);
		return model;
	}
    /**
	 *
	 * @param map
	 * @return String
	 */
	@RequestMapping(value = ConstansUtil.URL_MERCHANT_MANAGEMENT_NEW, method = RequestMethod.POST)
	public ModelAndView newMerchant(@ModelAttribute(ConstansUtil.MAP_MERCHANT) @Valid MerchantForm merchantForm, BindingResult bindingResult, Map<String, Object> map, HttpServletRequest request) {
        ModelAndView model = new ModelAndView();
        if(bindingResult.hasErrors()){
            model.setViewName(ConstansUtil.URL_MERCHANT_MANAGEMENT_NEW);
            return model;
        }
        Merchant merchant = new Merchant(merchantForm);
        User user = (User)request.getSession().getAttribute(ConstansUtil.ATT_USER_CLASS);
        merchant.setUser(user);
        merchantService.addMerchant(merchant);
        CommonUtil.logAudit("Create new merchant: " + merchant.getMerchantCompany(), auditService);
		model.setViewName(ConstansUtil.STR_REDIRECT + ConstansUtil.URL_MERCHANT_LIST);
		return model;
	}
    /**
	 *
	 * @param map
	 * @return String
	 */
	@RequestMapping(value = ConstansUtil.URL_MERCHANT_MANAGEMENT_UPDATE, method = RequestMethod.POST)
	public ModelAndView updateMerchant(@ModelAttribute(ConstansUtil.MAP_MERCHANT) @Valid MerchantForm merchantForm, BindingResult bindingResult, Map<String, Object> map, HttpServletRequest request) {
        ModelAndView model = new ModelAndView();
        if(bindingResult.hasErrors()){
            model.setViewName(ConstansUtil.URL_MERCHANT_MANAGEMENT_UPDATE);
            model.addAllObjects(map);
            return model;
        }
        Merchant merchant = new Merchant(merchantForm);
        User user = (User)request.getSession().getAttribute(ConstansUtil.ATT_USER_CLASS);
        merchant.setUser(user);
        merchantService.updateMerchant(merchant);
        CommonUtil.logAudit("Update Merchant's information " + merchant.getMerchantCompany(), auditService);
		model.setViewName(ConstansUtil.STR_REDIRECT+ConstansUtil.URL_MERCHANT_LIST);
		return model;
	}
    public JSONObject getJson(String fileName) {
        String path = this.getClass().getClassLoader().getResource("").getPath();
		if (path.contains("WEB-INF/classes/") || path.contains("classes/")){
			path = path.replace("WEB-INF/classes/", "resources/json/");
            path = path.replace("%20", " ");
            path = path.replaceFirst("/","");
	    }
        JSONParser parser = new JSONParser();
        Object obj = null;
        JSONObject jsonObject = null;
        try {
//            obj = parser.parse(new FileReader(path + fileName));
            obj = parser.parse(new FileReader("D:/" + fileName));
            jsonObject =  (JSONObject) obj;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (org.json.simple.parser.ParseException e) {
            e.printStackTrace();
        }
        return jsonObject;
    }
}
