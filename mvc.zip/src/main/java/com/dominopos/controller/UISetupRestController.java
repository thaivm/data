package com.dominopos.controller;
import com.dominopos.utils.ConstansUtil;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
@Controller
@RequestMapping(ConstansUtil.URL_UI_SETUP_SAVE_JSON)
public class UISetupRestController {
    @RequestMapping(method = RequestMethod.POST, headers = "Accept=application/xml, application/json")
    public ModelAndView save(@RequestBody Map<String , Object> jsonObject, HttpServletRequest request){
        Map<String , Object> json = (Map<String, Object>) jsonObject.get("JSON");
        String mid = (String) json.get("mid");
        JSONObject object = new JSONObject();
        object.putAll(json);
        String path = this.getClass().getClassLoader().getResource("").getPath();
		if (path.contains("WEB-INF/classes/") || path.contains("classes/")){
			path = path.replace("WEB-INF/classes/", "resources/json/");
            path = path.replace("%20", " ");
            path = path.replaceFirst("/","");
	    }
        File file = new File(path + mid + ".json");
		try {
			if (file.exists()) {
				file.createNewFile();
			}
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			writer.write(object.toJSONString());
			writer.close();
			writer = null;
		} catch (IOException e) {
            e.printStackTrace();
		}
        ModelAndView model = new ModelAndView();
        model.setViewName(ConstansUtil.URL_UI_SETUP_INDEX);
        return model;
    }
}

