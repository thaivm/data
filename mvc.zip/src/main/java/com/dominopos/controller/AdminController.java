package com.dominopos.controller;
import com.dominopos.dao.UserDAO;
import com.dominopos.form.MailForm;
import com.dominopos.form.UserAccessProfileForm;
import com.dominopos.form.UserForm;
import com.dominopos.model.User;
import com.dominopos.model.UserAccessProfile;
import com.dominopos.service.AuditService;
import com.dominopos.service.MailService;
import com.dominopos.service.MerchantService;
import com.dominopos.service.UserService;
import com.dominopos.utils.CommonUtil;
import com.dominopos.utils.ConstansUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamSource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;
import java.util.Map;
@Controller
public class AdminController {
	@Autowired
	private UserService userService;
	@Autowired
	private MailService mailService;
	@Autowired
    private UserDAO userDAO;
	@Autowired
	private JavaMailSender mailSender;
    @Autowired
    private MerchantService merchantService;
    @Autowired
    private AuditService auditService;

    @RequestMapping(value = ConstansUtil.URL_ADMIN)
	public String displayRoot(Map<String, Object> map) {
		return ConstansUtil.URL_ADMIN_INDEX;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_MANAGE_MERCHANTS)
	public ModelAndView manageMerchants(Map<String, Object> map) {
		ModelAndView model = new ModelAndView(ConstansUtil.URL_ADMIN_MANAGE_MERCHANTS);
		map.put(ConstansUtil.MAP_LIST_USERS_RESULT, userService.getUsers());
		return model;
	}
    @RequestMapping(value = ConstansUtil.URL_COMMON_ACCESS_DENIED)
	public ModelAndView accessDenied(Map<String, Object> map) {
		ModelAndView model = new ModelAndView();
        model.setViewName(ConstansUtil.URL_COMMON_ACCESS_DENIED);
		return model;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_GET_PROFILE_TYPE, method = RequestMethod.POST)
	@ResponseBody
	public int getProfileType(@RequestParam(ConstansUtil.PARAM_PROFILE_NAME) String profileName,
			Map<String, Object> map, HttpServletRequest request) {
		int result = 0;
		result = userService.getUserAccessProfileByName(profileName);
		return result;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_DO_CREATE_USER, method = RequestMethod.POST)
	public ModelAndView doCreateUser(
			@ModelAttribute(ConstansUtil.MODEL_ATT_USER_FORM) @Valid UserForm userform,
			BindingResult result, HttpSession session) {
        ModelAndView mav = null;
		try {
			if (result.hasErrors()) {
				mav = new ModelAndView(ConstansUtil.URL_ADMIN_CREATE_USER);
				mav.addObject(ConstansUtil.MAP_ACCESS_PROFILE_NAMES,
						userService.getAllRoleNames());
				mav.addObject(ConstansUtil.MAP_ALL_MERCHANT_NAMES,
						merchantService.getAllMerchantsName());
				mav.addObject(ConstansUtil.MAP_ADD_ERROR, true);
				return mav;
			} else {
				Long profileId = userform.getProfileId();
				String copId = userform.getCorpId().replace(",", "");
				if (profileId == 2L) {
					if (copId == null || copId.equals("")) {
						mav = new ModelAndView(
								ConstansUtil.URL_ADMIN_CREATE_USER);
						mav.addObject(ConstansUtil.MAP_ACCESS_PROFILE_NAMES,
								userService.getAllRoleNames());
						mav.addObject(ConstansUtil.MAP_ALL_MERCHANT_NAMES,
								merchantService.getAllMerchantsName());
						mav.addObject(ConstansUtil.MAP_ADD_ERROR, true);
						return mav;
					} else {
						if (userService.getUserByUsername(userform
								.getUserName()) == null) {
							String password = userform.getUserName()
									+ CommonUtil.randomString(ConstansUtil.RANDOM_PASSWORD);
							userform.setPassword(password);
							userform.setConfirmPassword(password);
							userService.addUser(userform);
							String subject = "[DominoPos] Welcome "
									+ userform.getUserLogin();
							String message = "Dear "
									+ userform.getUserName()
									+ ", \n\n"
									+ " - Your account has been created successfully. Here is password: ["
									+ password + "]" + " \n\n"
									+ "Regards, \n DominoPos";
							mailService.sendNewPass(userform, subject, message);
                            CommonUtil.logAudit("Create new user: " + userform.getUserName(),auditService);
						} else {
							userService.updateForm(userform);
							mav.addObject(ConstansUtil.MAP_ADD_ERROR, true);
						}
					}
				} else {
					if (userService.getUserByUsername(userform.getUserName()) == null) {
						String password = userform.getUserName()
								+ CommonUtil.randomString(ConstansUtil.RANDOM_PASSWORD);
						userform.setPassword(password);
						userform.setConfirmPassword(password);
						userService.addUser(userform);
						String subject = "[DominoPos] Welcome "
								+ userform.getUserLogin();
						String message = "Dear "
								+ userform.getUserName()
								+ ", \n\n"
								+ " - Your account has been created successfully. Here is password: ["
								+ password + "]" + " \n\n" + "Regards, \n DominoPos";
						mailService.sendNewPass(userform, subject, message);
                        CommonUtil.logAudit("Create new user: " + userform.getUserName(),auditService);
					} else {
						userService.updateForm(userform);
						mav.addObject(ConstansUtil.MAP_ADD_ERROR, true);
					}
				}
			}

		} catch (Exception ex) {
            ex.printStackTrace();
		}
		mav = new ModelAndView(ConstansUtil.STR_REDIRECT
				+ ConstansUtil.URL_ADMIN_MANAGE_USERS);
		return mav;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_CREATE_USER, method = RequestMethod.GET)
	public String addUser(Map<String, Object> map) {
		try {
			Map<String, String> accessProfileNames = userService.getAllRoleNames();

			map.put(ConstansUtil.MAP_ACCESS_PROFILE_NAMES, accessProfileNames);
			map.put(ConstansUtil.MAP_ALL_MERCHANT_NAMES, merchantService.getAllMerchantsName());
			map.put(ConstansUtil.MAP_NO_USER_MERCHANT_NAMES,
					merchantService.getAllMerchantsNameHaveNoUser());
			map.put(ConstansUtil.MODEL_ATT_USER_FORM, new UserForm());
			map.put(ConstansUtil.MAP_ROLES, userService.getAllRoles());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return ConstansUtil.URL_ADMIN_CREATE_USER;
	}
	@RequestMapping(ConstansUtil.URL_ADMIN_VIEW_USER_DETAIL + "/{userId}")
	public String userDetail(@PathVariable("userId") long userId,
			Map<String, Object> map, HttpServletRequest request) {
		String merchantName = "";
		if (userService.getUser(userId).getMerchant() != null){
            merchantName = userService.getUser(userId).getMerchant()
					.getMerchantCompany();
        }
		map.put(ConstansUtil.MAP_CHOOSED_MERCHANTNAME, merchantName);
		map.put(ConstansUtil.MAP_ACCESS_PROFILE_ID, userService.getUser(userId)
				.getAccessProfile().getAccessProfileId());
		map.put(ConstansUtil.MAP_ACCESS_PROFILE_NAMES, userService.getAllRoleNames());
		map.put(ConstansUtil.MAP_ALL_MERCHANT_NAMES, merchantService.getAllMerchantsName());
		map.put(ConstansUtil.MAP_NO_USER_MERCHANT_NAMES,
				merchantService.getAllMerchantsNameHaveNoUser());
		map.put(ConstansUtil.MODEL_ATT_USER_FORM,
				CommonUtil.createUserForm(userService.getUser(userId)));
		map.put(ConstansUtil.MAP_REFERER_URL, request.getHeader(ConstansUtil.STR_REFER));
		return ConstansUtil.URL_ADMIN_VIEW_USER_DETAIL;
	}
	@RequestMapping(ConstansUtil.URL_ADMIN_DELETE_USER + "/{userId}")
	public String deleteUser(@PathVariable("userId") long userId) {
		try {
            User user = userService.getUser(userId);
			userDAO.delete(userId);
            CommonUtil.logAudit("Deleted user: " + user.getUserName(),auditService);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return ConstansUtil.URL_ADMIN_MANAGE_USERS;
	}
	@RequestMapping(ConstansUtil.URL_ADMIN_RESET_USER + "/{userId}")
	public String resetUser(@PathVariable("userId") long userId) {
		try {
			User user = userService.getUser(userId);
			String password = user.getUserName() + CommonUtil.randomString(ConstansUtil.RANDOM_PASSWORD);
			user.setPassword(CommonUtil.sha256(password));
			Date today = new Date();
			user.setLastModified(today);
			user.setPasswordChanged(today);
			userService.updateUser(user);
			String subject = "[DominoPos] Reset User Password";
			String message = "Dear "
					+ user.getUsername()
					+ ", \n\n"
					+ " - You have reset password successfully. Here is new password: ["
					+ password + "]" + " \n\n" + " Regards, \n DominoPos";
			mailService.resetSimpleMail(user, subject, message);
            CommonUtil.logAudit("Reset password for user: " + user.getUserName(), auditService);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return ConstansUtil.URL_ADMIN_MANAGE_USERS;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_DO_UPDATE_USER, method = RequestMethod.POST)
	public ModelAndView updateUser(
			@ModelAttribute(ConstansUtil.MODEL_ATT_USER_FORM) @Valid UserForm userform,
			BindingResult result, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();
		if (result.hasErrors()) {
			mav.setViewName(ConstansUtil.URL_ADMIN_VIEW_USER_DETAIL);
			mav.addObject(ConstansUtil.MAP_ACCESS_PROFILE_NAMES, userService.getAllRoleNames());
			mav.addObject(ConstansUtil.MAP_ALL_MERCHANT_NAMES,
					merchantService.getAllMerchantsName());
			mav.addObject(ConstansUtil.MAP_NO_USER_MERCHANT_NAMES,
					merchantService.getAllMerchantsNameHaveNoUser());
			mav.addObject(ConstansUtil.MAP_ADD_ERROR, true);
			return mav;
		} else {
			userService.updateForm(userform);
            CommonUtil.logAudit("Update User's information " + userform.getUserName(), auditService);
			mav.setViewName(ConstansUtil.STR_REDIRECT + ConstansUtil.URL_ADMIN_MANAGE_USERS);
			return mav;
		}
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_MAIL_FORM, method = RequestMethod.GET)
	public String displayMailForm(Map<String, Object> map) {
		map.put(ConstansUtil.MAP_MAIL_FORM, new MailForm());
		return ConstansUtil.URL_ADMIN_MAIL_FORM;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_SEND_MAIL, method = RequestMethod.POST)
	public ModelAndView sendMailWithAttachs(
			@ModelAttribute(ConstansUtil.MAP_MAIL_FORM) @Valid MailForm mailForm,
			BindingResult result) {
		ModelAndView mav = new ModelAndView();
		if (!result.hasErrors()) {
			// reads form input
			final String emailTo = mailForm.getToAddresses();
			final String subject = mailForm.getSubject();
			final String message = mailForm.getTextMsg();
			final CommonsMultipartFile attachFile = mailForm.getAttachFiles()
					.get(0);
			mailSender.send(new MimeMessagePreparator() {
				public void prepare(MimeMessage mimeMessage) throws Exception {
					MimeMessageHelper messageHelper = new MimeMessageHelper(
							mimeMessage, true, "UTF-8");
					messageHelper.setTo(emailTo);
					messageHelper.setSubject(subject);
					messageHelper.setText(message);
					// determines if there is an upload file, attach it to the
					// e-mail
					if (attachFile != null) {
						String attachName = attachFile.getOriginalFilename();
						if (!attachName.equals("")) {
							messageHelper.addAttachment(attachName,
									new InputStreamSource() {
										@Override
										public InputStream getInputStream()
												throws IOException {
											return attachFile.getInputStream();
										}
									});
						}
					}
				}
			});
			mav.setViewName(ConstansUtil.STR_REDIRECT
					+ ConstansUtil.URL_ADMIN_MANAGE_MERCHANTS);
		} else {
			mav.addObject(ConstansUtil.MAP_IS_VALID_EMAIL, false);
			mav.setViewName(ConstansUtil.URL_ADMIN_MAIL_FORM);
		}
		return mav;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_VIEW_TRANSACTION_DETAIL, method = RequestMethod.GET)
	public String viewTransactionDetail(Map<String, Object> map,
			HttpServletRequest request) {
		map.put("", request.getHeader(ConstansUtil.STR_REFER));
		return ConstansUtil.URL_ADMIN_VIEW_TRANSACTION_DETAIL;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_VIEW_MERCHANT_DETAIL, method = RequestMethod.GET)
	public String viewMerchantDetail(Map<String, Object> map) {
		return ConstansUtil.URL_ADMIN_VIEW_MERCHANT_DETAIL;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_CREATE_MERCHANT, method = RequestMethod.GET)
	public String createMerchant(Map<String, Object> map) {
		return ConstansUtil.URL_ADMIN_CREATE_MERCHANT;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_CREATE_RETAILER, method = RequestMethod.GET)
	public String createRetailer(Map<String, Object> map) {
		return ConstansUtil.URL_ADMIN_CREATE_RETAILER;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_MANAGE_GROUP_DETAIL, method = RequestMethod.GET)
	public String viewGroupDetails(Map<String, Object> map) {
		return ConstansUtil.URL_ADMIN_MANAGE_GROUP_DETAIL;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_MANAGE_USERS, method = RequestMethod.GET)
	public String manageUsers(Map<String, Object> map) {
		List<User> users = userService.getUsers();
		map.put(ConstansUtil.MAP_LIST_ALL_USERS, users);
		return ConstansUtil.URL_ADMIN_MANAGE_USERS;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_SEARCH_TRANX_RESULT, method = RequestMethod.GET)
	public ModelAndView searchTranxResult(Map<String, Object> map) {
		ModelAndView model = new ModelAndView(
				ConstansUtil.URL_ADMIN_SEARCH_TRANX_RESULT);
		return model;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_LATEST_REQUESTS, method = RequestMethod.GET)
	public String displayForm(Map<String, Object> map) {
		return ConstansUtil.URL_ADMIN_LATEST_REQUESTS;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_MANAGE_USER_ROLES, method = RequestMethod.GET)
	public String manageUserGroups(Map<String, Object> map) {
		List<UserAccessProfile> allAccessProfiles = userService.getAllRoles();
		map.put(ConstansUtil.MAP_ALL_ACCESS_PROFILES, allAccessProfiles);
		return ConstansUtil.URL_ADMIN_MANAGE_USER_ROLES;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_DELETE_USER_ROLES, method = RequestMethod.POST)
	@ResponseBody
	public String deleteUserGroups(
			@RequestParam(ConstansUtil.PARAM_ACCESS_PROFILE_ID) Long accessprofileId,
			Map<String, Object> map) {
		try {
            UserAccessProfile userAccessProfile = userService.getUserAccessProfileById(accessprofileId);
			userService.deleteRoleById(accessprofileId);
            CommonUtil.logAudit("Delete AccessProfile with " + userAccessProfile.getAccessProfileMemo(), auditService);
		} catch (Exception e) {
			e.printStackTrace();
            return ConstansUtil.ERROR_CONSTRAINT_FOREIGN_KEY;
		}
		return ConstansUtil.URL_ADMIN_MANAGE_USER_ROLES;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_CREATE_NEW_ROLE, method = RequestMethod.GET)
	public String createNewRole(Map<String, Object> map) {
		return ConstansUtil.URL_ADMIN_CREATE_NEW_ROLE;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_CREATE_ACCESS_PROFILE, method = RequestMethod.GET)
	public String createAccessProfile(UserAccessProfile accessProfile,
			Map<String, Object> map) {
		// get all access profile type
		List<UserAccessProfile> userAccessProfiles = userService.getAllRoles();
		map.put(ConstansUtil.MAP_ACCESS_PROFILES, userAccessProfiles);
		map.put(ConstansUtil.MAP_PROFILE_FORM, new UserAccessProfile());
		return ConstansUtil.URL_ADMIN_CREATE_ACCESS_PROFILE;
	}
    @RequestMapping(value = ConstansUtil.URL_ADMIN_ADD_ROLE, method = RequestMethod.POST)
	public ModelAndView addAccessProfile(@ModelAttribute(ConstansUtil.MAP_PROFILE_FORM) @Valid UserAccessProfileForm userAccessProfileForm,
                                   BindingResult bindingResult, Map<String, Object> map, HttpServletRequest request) {
        ModelAndView model = new ModelAndView();
        if(bindingResult.hasErrors()){
            model.setViewName(ConstansUtil.URL_ADMIN_CREATE_ACCESS_PROFILE);
            return model;
        }
        UserAccessProfile userAccessProfile = UserAccessProfileForm.convertToUserAccessProfile(userAccessProfileForm);
        userService.createNewUserAccessProfile(userAccessProfile);
        CommonUtil.logAudit("Profile " + userAccessProfile.getAccessProfileMemo()
				+ "with profile type: " + userAccessProfile.getAccessProfileName() + " have been created",
				auditService);
        model.setViewName(ConstansUtil.STR_REDIRECT + ConstansUtil.URL_ADMIN_MANAGE_USER_ROLES);
		return model;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_SAVE_ACCESS_PROFILE, method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView saveAccessProfile(@ModelAttribute(ConstansUtil.MAP_ACCESS_PROFILE_DETAIL) @Valid UserAccessProfileForm userAccessProfileForm, BindingResult bindingResult, Map<String, Object> map) {
		if(bindingResult.hasErrors()){
            String url = ConstansUtil.URL_ADMIN_MANAGE_USER_ROLES;
            ModelAndView model = new ModelAndView(url);
            model.addAllObjects(map);
            return model;
        }
        UserAccessProfile accessProfile = UserAccessProfileForm.convertToUserAccessProfile(userAccessProfileForm);
        accessProfile.setAccessProfileId(userAccessProfileForm.getAccessProfileId());
        userService.updateUserAccessProfile(accessProfile);
        CommonUtil.logAudit("Update accessprofile with profile name: "
				+ accessProfile.getAccessProfileMemo() + " profile type: "
				+ accessProfile.getAccessProfileName(), auditService);
        ModelAndView model = new ModelAndView();
        model.setViewName(ConstansUtil.STR_REDIRECT+ConstansUtil.URL_ADMIN_MANAGE_USER_ROLES);
        return model;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_UPDATE_ROLE_DETAIL , method = RequestMethod.POST)
	public ModelAndView updateAccessProfile(@ModelAttribute(ConstansUtil.MAP_ACCESS_PROFILE_DETAIL) @Valid UserAccessProfileForm userAccessProfileForm,
                                   BindingResult bindingResult, Map<String, Object> map, HttpServletRequest request) {
		ModelAndView model = new ModelAndView();
        if(bindingResult.hasErrors()){
            model.setViewName(ConstansUtil.URL_ADMIN_UPDATE_ROLE_DETAIL);
            return model;
        }
        UserAccessProfile userAccessProfile = UserAccessProfileForm.convertToUserAccessProfile(userAccessProfileForm);
        userAccessProfile.setAccessProfileId(userAccessProfileForm.getAccessProfileId());
        userService.updateUserAccessProfile(userAccessProfile);
        CommonUtil.logAudit("Update accessprofile with profile name: "
				+ userAccessProfile.getAccessProfileMemo() + " profile type: "
				+ userAccessProfile.getAccessProfileName(), auditService);
        model.setViewName(ConstansUtil.STR_REDIRECT+ConstansUtil.URL_ADMIN_MANAGE_USER_ROLES);
		return model;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_VIEW_ROLE_DETAIL
			+ "/{roleId}", method = RequestMethod.GET)
	public ModelAndView viewRoleDetail(@PathVariable("roleId") long roleId,
			Map<String, Object> map) {
		// get all access profile type
		Map<String, String> accessProfileNames = userService.getAllRoleNames();
		map.put(ConstansUtil.MAP_ACCESS_PROFILE_NAMES, accessProfileNames);
		UserAccessProfile role = userService.getUserAccessProfileById(roleId);
		map.put(ConstansUtil.MAP_ACCESS_PROFILE_DETAIL, role);
		map.put(ConstansUtil.MAP_ROLE_ID, roleId);
        ModelAndView model = new ModelAndView();
        model.setViewName(ConstansUtil.URL_ADMIN_VIEW_ROLE_DETAIL);
		return model;
	}
	@RequestMapping(value = ConstansUtil.URL_ADMIN_GET_ROLE_DETAIL, method = RequestMethod.POST)
	@ResponseBody
	public UserAccessProfile getRoleDetail(@RequestParam("roleId") long roleId,
			Map<String, Object> map, HttpServletRequest request) {
		UserAccessProfile role = null;
        role = userService.getUserAccessProfileById(roleId);
		return role;
	}

    @RequestMapping(value = ConstansUtil.URL_ADMIN_LOGOUT)
	public String logout(Map<String, Object> map) {
		CommonUtil.logAudit("User logout ", auditService);
		return "redirect:/j_spring_security_logout";
	}
}
