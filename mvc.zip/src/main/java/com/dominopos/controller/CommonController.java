package com.dominopos.controller;

import com.dominopos.model.AuditLog;
import com.dominopos.service.AuditService;
import com.dominopos.utils.ConstansUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.Map;

@Controller
public class CommonController {
    @Autowired
    private AuditService auditService;
    /**
	 *
	 * @param Map<String,Object>
	 * @return String
	 */
	@RequestMapping(value = ConstansUtil.URL_COMMON)
	public String commonlogin(Map<String, Object> map) {
		return ConstansUtil.URL_COMMON_LOGIN;
	}
	@RequestMapping(value = ConstansUtil.URL_COMMON_OTHER)
	public String commonloginOther(Map<String, Object> map) {
		return ConstansUtil.URL_COMMON_LOGIN;
	}
	@RequestMapping(value = ConstansUtil.URL_COMMON_LOGIN)
	public String login(Map<String, Object> map) {
		return ConstansUtil.URL_COMMON_LOGIN;
	}
	/**
	 *
	 * @param map
	 * @return String
	 */
	@RequestMapping(value="/",method = RequestMethod.GET)
	public String home(Map<String, Object> map) {
		return ConstansUtil.URL_COMMON_LOGIN;
	}
	/**
	 *
	 * @param map
	 * @return String
	 */
	@RequestMapping(value=ConstansUtil.URL_COMMON_INDEX,method = RequestMethod.GET)
	public String index(Map<String, Object> map) {
		return ConstansUtil.URL_COMMON_LOGIN;
	}
    /**
	 *
	 * @param map
	 * @return String
	 */
	@RequestMapping(value=ConstansUtil.URL_COMMON_HOME,method = RequestMethod.GET)
	public String home1(Map<String, Object> map) {
		return ConstansUtil.URL_COMMON_HOME;
	}
    /**
	 *
	 * @param map
	 * @return String
	 */
	@RequestMapping(value=ConstansUtil.URL_REPORT_HOME,method = RequestMethod.GET)
	public String report(Map<String, Object> map) {
		return ConstansUtil.URL_REPORT_HOME;
	}
	/**
	 *
	 * @param map
	 * @return String
	 */
    @RequestMapping(value = ConstansUtil.URL_AUDIT_HOME, method = RequestMethod.GET)
	public ModelAndView viewAudit(Map<String, Object> map) {
		ModelAndView model = new ModelAndView(ConstansUtil.URL_AUDIT_HOME);
		List<AuditLog> allAuditLog = auditService.getAllAuditLogs();
		map.put("ALL_AUDIT", allAuditLog);
		return model;
	}
    /**
	 *
	 * @param map
	 * @return String
	 */
	@RequestMapping(value=ConstansUtil.URL_TRANSACTION_HOME,method = RequestMethod.GET)
	public String transaction(Map<String, Object> map) {
		return ConstansUtil.URL_TRANSACTION_HOME;
	}
}