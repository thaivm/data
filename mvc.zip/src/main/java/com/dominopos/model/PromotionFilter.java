package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import com.dominopos.utils.ConstansUtil;

/**
 * The persistent class for the promotion_filters database table.
 * 
 */
@Entity(name = ConstansUtil.TABLE_PROMOTION_FILTERS)
public class PromotionFilter implements Serializable {

	
	private static final long serialVersionUID = 1L;
	@Id
	private int id;
	@Column(length = 45)
	private String key;
	@Column(length = 45)
	private String value;

	// bi-directional many-to-one association to Promotion
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = ConstansUtil.JOINCOLUMN_PROMOTION_ID)
	private Promotion promotion;

	public PromotionFilter() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getKey() {
		return this.key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Promotion getPromotion() {
		return this.promotion;
	}

	public void setPromotion(Promotion promotion) {
		this.promotion = promotion;
	}

}