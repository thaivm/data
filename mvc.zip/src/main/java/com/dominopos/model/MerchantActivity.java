/**
 * 
 */
package com.dominopos.model;

import javax.persistence.*;

import com.dominopos.utils.ConstansUtil;
/**
 *
 */
@Entity
@Table(name=ConstansUtil.TABLE_MERCHANT_ACTIVITY)
public class MerchantActivity {
	
	

	private MerchantActivityPK id;
	
	private Merchant merchant;
	private Activity activity;
	/**
	 * 
	 */
	public MerchantActivity() {
		// TODO Auto-generated constructor stub
	}
	
	@EmbeddedId
	public MerchantActivityPK getId() {
		return id;
	}
	public void setId(MerchantActivityPK id) {
		this.id = id;
	}

	//bi-directional many-to-one association to Module
	@ManyToOne
	@JoinColumn(name="MID", insertable = false, updatable = false)
	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant mid) {
		this.merchant = mid;
	}

	//bi-directional many-to-one association to Module
	@ManyToOne
	@JoinColumn(name="activityID", insertable = false, updatable = false)
	public Activity getActivity() {
		return activity;
	}

	public void setActivity(Activity activity) {
		this.activity = activity;
	}

	
	
}
