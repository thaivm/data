package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import com.dominopos.utils.ConstansUtil;

import java.sql.Time;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the promotion database table.
 * 
 */
@Entity(name=ConstansUtil.TABLE_PROMOTION)
public class Promotion implements Serializable {
	
	
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	@Column(length=11)
	private int promotionID;
	@Column(length=255)
	private String promotionShortDescription;
	private String promotionLongDescription;
	
	@Column(length=50)
	private String images;
	@Temporal(TemporalType.TIMESTAMP)
	private Date startPromotion;
	@Temporal(TemporalType.TIMESTAMP)
	private Date endPromotion;
	private Time startTime;
	private Time endTime;
	//2013/09/24
	
		
	//2013/09/24
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_PROMOTION_TYPE_ID)
	private PromotionType promotionType;
	@ManyToOne
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_MID)
	private Merchant merchant;
	@ManyToOne()
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_PRODUCT_ID)
	private Product product;
	
	@OneToMany(mappedBy=ConstansUtil.MAPPED_PROMOTION)
	private List<PromotionFilter> promotionFilters;

	public Promotion() {
	}


	
	public int getPromotionID() {
		return this.promotionID;
	}

	public void setPromotionID(int promotionID) {
		this.promotionID = promotionID;
	}


	
	public Date getEndPromotion() {
		return this.endPromotion;
	}

	public void setEndPromotion(Date endPromotion) {
		this.endPromotion = endPromotion;
	}


	public String getImages() {
		return this.images;
	}

	public void setImages(String images) {
		this.images = images;
	}


	public String getPromotionLongDescription() {
		return this.promotionLongDescription;
	}

	public void setPromotionLongDescription(String promotionLongDescription) {
		this.promotionLongDescription = promotionLongDescription;
	}


	
	public Date getStartPromotion() {
		return this.startPromotion;
	}

	public void setStartPromotion(Date startPromotion) {
		this.startPromotion = startPromotion;
	}

	public Time getStartTime() {
		return startTime;
	}


	public void setStartTime(Time startTime) {
		this.startTime = startTime;
	}


	public Time getEndTime() {
		return endTime;
	}


	public void setEndTime(Time endTime) {
		this.endTime = endTime;
	}
	
	
	public PromotionType getPromotionType() {
		return promotionType;
	}


	public void setPromotionType(PromotionType promotionType) {
		this.promotionType = promotionType;
	}


	//bi-directional many-to-one association to PromotionFilter
	
	public List<PromotionFilter> getPromotionFilters() {
		return this.promotionFilters;
	}

	public void setPromotionFilters(List<PromotionFilter> promotionFilters) {
		this.promotionFilters = promotionFilters;
	}

	public PromotionFilter addPromotionFilter(PromotionFilter promotionFilter) {
		getPromotionFilters().add(promotionFilter);
		promotionFilter.setPromotion(this);

		return promotionFilter;
	}

	public PromotionFilter removePromotionFilter(PromotionFilter promotionFilter) {
		getPromotionFilters().remove(promotionFilter);
		promotionFilter.setPromotion(null);

		return promotionFilter;
	}


	public String getPromotionShortDescription() {
		return promotionShortDescription;
	}


	public void setPromotionShortDescription(String promotionShortDescription) {
		this.promotionShortDescription = promotionShortDescription;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant mid) {
		this.merchant = mid;
	}


	public Product getProduct() {
		return product;
	}


	public void setProduct(Product product) {
		this.product = product;
	}

	
	
}