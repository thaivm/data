package com.dominopos.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.dominopos.utils.ConstansUtil;

@Entity
@Table(name=ConstansUtil.TABLE_PERMISSION)
public class Permission {

	
	private long permissionId;
	private Menu menu; //menuID
	private long userAccessProfile;

	// 0 : view only
	// 1 : view and modify
	// 3 : turn off menu
	private int permisionCode;

	public Permission(Menu menu, int permisionCode) {
		this.menu = menu;
		this.permisionCode = permisionCode;
	}

	public Permission() {
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(length = 2)
	public long getPermissionId() {
		return permissionId;
	}

	public void setPermissionId(long permissionId) {
		this.permissionId = permissionId;
	}
	
	@OneToOne
	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}

	public int getPermisionCode() {
		return permisionCode;
	}

	public void setPermisionCode(int permisionCode) {
		this.permisionCode = permisionCode;
	}
	
	@JoinColumn(name="userAccessProfileId")
	public long getUserAccessProfile() {
		return userAccessProfile;
	}
	
	public void setUserAccessProfile(long userAccessProfile) {
		this.userAccessProfile = userAccessProfile;
	}
	
}
