/**
 * 
 */
package com.dominopos.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.dominopos.utils.ConstansUtil;

/**
 *
 */
@Entity
@Table(name=ConstansUtil.TABLE_CRM_BIGGEST_AMOUNT)
public class crmBiggestAmount {
	
	@Id
	@GeneratedValue
	private Integer id;
	private Double amount;
	private Date date;
	
	@ManyToOne
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_CRM_ID)
	private Crm crm;
	/**
	 * 
	 */
	public crmBiggestAmount() {
		// TODO Auto-generated constructor stub
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	
	public Crm getCrm() {
		return crm;
	}
	public void setCrm(Crm crm) {
		this.crm = crm;
	}

	
	
}
