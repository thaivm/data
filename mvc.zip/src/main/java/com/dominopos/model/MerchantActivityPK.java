/**
 * 
 */
package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 */
@Embeddable
public class MerchantActivityPK implements Serializable{

	private String mid;
	private String activityId;
	/**
	 * 
	 */
	public MerchantActivityPK() {
		// TODO Auto-generated constructor stub
	}
	
	@Column(insertable=false, updatable=false)
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	
	@Column(insertable=false, updatable=false)
	public String getActivityId() {
		return activityId;
	}
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}

	
}
