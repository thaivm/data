package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.FetchProfile;
import org.hibernate.annotations.FetchProfile.FetchOverride;

import com.dominopos.utils.ConstansUtil;


/**
 * The persistent class for the product_prices database table.
 * 
 */
@Entity(name=ConstansUtil.TABLE_PRODUCT_PRICES)
public class ProductPrice implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	private int pPriceID;
	@Column(length=11)
	private int quantity;
	private double price;
	
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_PRODUCT_ID)
	private Product product;

	public ProductPrice() {
	}


	
	public int getPPriceID() {
		return this.pPriceID;
	}

	public void setPPriceID(int pPriceID) {
		this.pPriceID = pPriceID;
	}


	public double getPrice() {
		return this.price;
	}

	public void setPrice(double price) {
		this.price = price;
	}


	public int getQuantity() {
		return this.quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	//bi-directional many-to-one association to Product
	
	public Product getProduct() {
		return this.product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

}