package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.validator.constraints.Length;

import com.dominopos.utils.ConstansUtil;

import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the consumer database table.
 * 
 */
@Entity(name=ConstansUtil.TABLE_CONSUMER)
public class Consumer implements Serializable {
	
	
	
	private static final long serialVersionUID = 1L;
	@Id
	@Column(length=16)
	private int cid;
	@Column(length=10)
	private String password;
	@Column(length=12)
	private String firstName;
	@Column(length=12)
	private String lastName;
	@Column(length=32)
	private String email;
	@Column(length=25)
	private String address1;
	@Column(length=25)
	private String address2;
	@Column(length=25)
	private String address3;
	@Column(length=20)
	private String postalCode;
	@Column(length=30)
	private String city;
	@Column(length=20)
	private String country;
	@Column(length=10)
	private String phone;
	private Timestamp dateOfAcquiring;
	@Column(length=1)
	private byte isActive;
	@Column(length=50)
	private String photo;
	@Temporal(TemporalType.TIMESTAMP)
	private Date birthday;
	@Column(length=1)
	private String sex;
	@Column(length=50)
	private String relationshipStatus;
	@Column(length=50)
	private String occupation;
	@Column(length=45)
	private String companyName;
	@Column(length=45)
	private String educationLevel;
	@Column(length=45)
	private String spokenLanguages;
	@Column(length=11)
	private Integer nbrVisitsincebegining;
	private BigDecimal spentsincebegining;
	private BigDecimal averageSpendingMonth;
	private Float averageVisitsMonth;
	private String typeOfSpending;
	private BigDecimal minSpending;
	private BigDecimal maxSpending;
	private BigDecimal realSpending;
	@Column(length=17)
	private String mac;
	@Column(length=45)
	private String color;
	@Column(length=45)
	private String shoesSize;
	@Column(length=45)
	private String shirtSize;
	@Column(length=45)
	private String pantsSize;
	@Column(length=100)
	private String food;
	@Column(length=100)
	private String fashion;
	@Column(length=100)
	private String hobby;
	
	//2013/09/23
	@Column(name="nbr")
	private Timestamp nbr;
	@Column(name="lastVisitDate")
	private Timestamp lastVisitDate;
	@Column(name="lastPurchaseDate")
	private Timestamp lastPurchaseDate;
	@Column(name="lastSpenAmount")
	private Double lastSpenAmount;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_MID)
	private Merchant merchant;
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_RID)
	private Retailer retailer;
	
	@OneToMany(mappedBy=ConstansUtil.MAPPED_CONSUMER)
	private List<Crm> rfms;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_CONSUMER)
	private List<ConsumerChild> consumerChilds;
	//2013/09/24
	@OneToMany(mappedBy=ConstansUtil.MAPPED_CONSUMER,fetch=FetchType.LAZY)
	private List<Ticket> tickets;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_CONSUMER,fetch=FetchType.LAZY)
	private List<CouponActive> couponActives;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_CONSUMER,fetch=FetchType.LAZY)
	private List<Transaction> transactions;

	public Consumer() {
	}


	
	public int getCid() {
		return this.cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}


	public String getAddress1() {
		return this.address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}


	public String getAddress2() {
		return this.address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}


	public String getAddress3() {
		return this.address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}


	
	public Date getBirthday() {
		return this.birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}


	public String getColor() {
		return this.color;
	}

	public void setColor(String color) {
		this.color = color;
	}


	public Timestamp getDateOfAcquiring() {
		return this.dateOfAcquiring;
	}

	public void setDateOfAcquiring(Timestamp dateOfAcquiring) {
		this.dateOfAcquiring = dateOfAcquiring;
	}


	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	public String getFashion() {
		return this.fashion;
	}

	public void setFashion(String fashion) {
		this.fashion = fashion;
	}


	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getFood() {
		return this.food;
	}

	public void setFood(String food) {
		this.food = food;
	}


	public String getHobby() {
		return this.hobby;
	}

	public void setHobby(String hobby) {
		this.hobby = hobby;
	}


	public byte getIsActive() {
		return this.isActive;
	}

	public void setIsActive(byte isActive) {
		this.isActive = isActive;
	}


	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getMac() {
		return this.mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}


	public BigDecimal getMaxSpending() {
		return this.maxSpending;
	}

	public void setMaxSpending(BigDecimal maxSpending) {
		this.maxSpending = maxSpending;
	}


	public BigDecimal getMinSpending() {
		return this.minSpending;
	}

	public void setMinSpending(BigDecimal minSpending) {
		this.minSpending = minSpending;
	}


	public String getPantsSize() {
		return this.pantsSize;
	}

	public void setPantsSize(String pantsSize) {
		this.pantsSize = pantsSize;
	}


	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getPostalCode() {
		return this.postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}


	public BigDecimal getRealSpending() {
		return this.realSpending;
	}

	public void setRealSpending(BigDecimal realSpending) {
		this.realSpending = realSpending;
	}


	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}


	public String getShirtSize() {
		return this.shirtSize;
	}

	public void setShirtSize(String shirtSize) {
		this.shirtSize = shirtSize;
	}


	public String getShoesSize() {
		return this.shoesSize;
	}

	public void setShoesSize(String shoesSize) {
		this.shoesSize = shoesSize;
	}


	public String getTypeOfSpending() {
		return this.typeOfSpending;
	}

	public void setTypeOfSpending(String typeOfSpending) {
		this.typeOfSpending = typeOfSpending;
	}

	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getPhoto() {
		return photo;
	}


	public void setPhoto(String photo) {
		this.photo = photo;
	}


	public String getRelationshipStatus() {
		return relationshipStatus;
	}


	public void setRelationshipStatus(String relationshipStatus) {
		this.relationshipStatus = relationshipStatus;
	}


	public String getOccupation() {
		return occupation;
	}


	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}


	public String getCompanyName() {
		return companyName;
	}


	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	public String getEducationLevel() {
		return educationLevel;
	}


	public void setEducationLevel(String educationLevel) {
		this.educationLevel = educationLevel;
	}


	public String getSpokenLanguages() {
		return spokenLanguages;
	}


	public void setSpokenLanguages(String spokenLanguages) {
		this.spokenLanguages = spokenLanguages;
	}


	public Integer getNbrVisitsincebegining() {
		return nbrVisitsincebegining;
	}


	public void setNbrVisitsincebegining(Integer nbrVisitsincebegining) {
		this.nbrVisitsincebegining = nbrVisitsincebegining;
	}


	public BigDecimal getSpentsincebegining() {
		return spentsincebegining;
	}


	public void setSpentsincebegining(BigDecimal spentsincebegining) {
		this.spentsincebegining = spentsincebegining;
	}


	public BigDecimal getAverageSpendingMonth() {
		return averageSpendingMonth;
	}


	public void setAverageSpendingMonth(BigDecimal averageSpendingMonth) {
		this.averageSpendingMonth = averageSpendingMonth;
	}


	public Float getAverageVisitsMonth() {
		return averageVisitsMonth;
	}

	
	public Timestamp getNbr() {
		return nbr;
	}


	public void setNbr(Timestamp nbr) {
		this.nbr = nbr;
	}

	
	public Timestamp getLastVisitDate() {
		return lastVisitDate;
	}


	public void setLastVisitDate(Timestamp lastVisitDate) {
		this.lastVisitDate = lastVisitDate;
	}

	
	public Timestamp getLastPurchaseDate() {
		return lastPurchaseDate;
	}


	public void setLastPurchaseDate(Timestamp lastPurchaseDate) {
		this.lastPurchaseDate = lastPurchaseDate;
	}

	
	public Double getLastSpenAmount() {
		return lastSpenAmount;
	}


	public void setLastSpenAmount(Double lastSpenAmount) {
		this.lastSpenAmount = lastSpenAmount;
	}


	public void setAverageVisitsMonth(Float averageVisitsMonth) {
		this.averageVisitsMonth = averageVisitsMonth;
	}


	//bi-directional many-to-one association to Merchant
	
	public Merchant getMerchant() {
		return this.merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}


	//bi-directional many-to-one association to Retailer
	
	public Retailer getRetailer() {
		return this.retailer;
	}

	public void setRetailer(Retailer retailer) {
		this.retailer = retailer;
	}

	//bi-directional many-to-one association to Rfm
	
	public List<Crm> getRfms() {
		return this.rfms;
	}

	public void setRfms(List<Crm> rfms) {
		this.rfms = rfms;
	}

	public Crm addRfm(Crm rfm) {
		getRfms().add(rfm);
		rfm.setConsumer(this);

		return rfm;
	}

	public Crm removeRfm(Crm rfm) {
		getRfms().remove(rfm);
		rfm.setConsumer(null);

		return rfm;
	}
	
	
	public List<ConsumerChild> getConsumerChilds() {
		return consumerChilds;
	}


	public void setConsumerChilds(List<ConsumerChild> consumerChilds) {
		this.consumerChilds = consumerChilds;
	}


	public List<Ticket> getTickets() {
		return tickets;
	}


	public void setTickets(List<Ticket> tickets) {
		this.tickets = tickets;
	}


	public List<CouponActive> getCouponActives() {
		return couponActives;
	}


	public void setCouponActives(List<CouponActive> couponActives) {
		this.couponActives = couponActives;
	}



	public List<Transaction> getTransactions() {
		return transactions;
	}



	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}
	
	
}