package com.dominopos.model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.dominopos.utils.ConstansUtil;

@Entity
@Table(name=ConstansUtil.TABLE_MENU)
public class Menu {
	
	@Id
	@GeneratedValue
	@Column(length=20)
	private long menuId;
	@Column(length=30)
	private String menuTitle;
	@Column(length=30)
	private String menuUrl;
	@Column(length=11)
	private int menuType;
	
	//0 : access disabled
	
	
	public Menu() {}
	
	public Menu(long menuId, String menuTitle, String menuUrl, int menuType) {
		this.menuId = menuId;
		this.menuTitle = menuTitle;
		this.menuUrl = menuUrl;
		this.menuType = menuType;
	}

	public Menu(String menuName) {
		this.menuTitle = menuName;
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(length = 2)
	public long getMenuId() {
		return menuId;
	}
	public void setMenuId(long menuId) {
		this.menuId = menuId;
	}
	
	@Column(length = 30)
	public String getMenuTitle() {
		return menuTitle;
	}
	public void setMenuTitle(String menuName) {
		this.menuTitle = menuName;
	}
	
	@Column(length = 30)
	public String getMenuUrl() {
		return menuUrl;
	}

	public void setMenuUrl(String menuUrl) {
		this.menuUrl = menuUrl;
	}

	@Column(length = 1)
	public int getMenuType() {
		return menuType;
	}

	public void setMenuType(int menuType) {
		this.menuType = menuType;
	}
	
	

}
