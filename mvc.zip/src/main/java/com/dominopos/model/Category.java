package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import com.dominopos.utils.ConstansUtil;

import java.util.List;


/**
 * The persistent class for the category database table.
 * 
 */
@Entity(name=Category.TABLE_CATEGORY)
public class Category implements Serializable {
	
	public static final String TABLE_CATEGORY = "category";
	private static final long serialVersionUID = 1L;
	@Id
	@Column(length=11)
	private String categoryID;
	@Column(length=45)
	private String name;
	@Column(length=45)
	private String level;
	@Column(length=11)
	private String parentID;
	
	//2013/09/24
	@ManyToOne
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_MID)
	private Merchant merchant;
	
	@OneToMany(mappedBy=ConstansUtil.MAPPED_CATEGORY)
	private List<CategoryProperty> categoryProperties;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_CATEGORY)
	private List<Product> products;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_CATEGORY)
	private List<ShopEvent> shopEvents;

	public Category() {
	}


	
	public String getCategoryID() {
		return this.categoryID;
	}

	public void setCategoryID(String categoryID) {
		this.categoryID = categoryID;
	}


	public String getLevel() {
		return this.level;
	}

	public void setLevel(String level) {
		this.level = level;
	}


	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public String getParentID() {
		return this.parentID;
	}

	public void setParentID(String parentID) {
		this.parentID = parentID;
	}


	//bi-directional many-to-one association to CategoryProperty
	
	public List<CategoryProperty> getCategoryProperties() {
		return this.categoryProperties;
	}

	public void setCategoryProperties(List<CategoryProperty> categoryProperties) {
		this.categoryProperties = categoryProperties;
	}

	public CategoryProperty addCategoryProperty(CategoryProperty categoryProperty) {
		getCategoryProperties().add(categoryProperty);
		categoryProperty.setCategory(this);

		return categoryProperty;
	}

	public CategoryProperty removeCategoryProperty(CategoryProperty categoryProperty) {
		getCategoryProperties().remove(categoryProperty);
		categoryProperty.setCategory(null);

		return categoryProperty;
	}


	

	//bi-directional many-to-one association to Product
	
	public List<Product> getProducts() {
		return this.products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public Product addProduct(Product product) {
		getProducts().add(product);
		product.setCategory(this);

		return product;
	}

	public Product removeProduct(Product product) {
		getProducts().remove(product);
		product.setCategory(null);

		return product;
	}

	
	public List<ShopEvent> getShopEvents() {
		return shopEvents;
	}


	public void setShopEvents(List<ShopEvent> shopEvents) {
		this.shopEvents = shopEvents;
	}


	public Merchant getMerchant() {
		return merchant;
	}


	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	
}