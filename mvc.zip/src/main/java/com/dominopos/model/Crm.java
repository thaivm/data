package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import com.dominopos.utils.ConstansUtil;

import java.util.Date;
import java.util.List;

/**
 * The persistent class for the rfm database table.
 * 
 */
@Entity
@Table(name = ConstansUtil.TABLE_CRM)
public class Crm implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@Column(length=10)
	private int id;
	private float avgSpent;
	@Column(length=11)
	private int frequency;
	@Temporal(TemporalType.TIMESTAMP)
	private Date recency;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = ConstansUtil.JOINCOLUMN_CID)
	private Consumer consumer;
	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST })
	@JoinColumn(name = ConstansUtil.JOINCOLUMN_MID)
	private Merchant mid;

	@OneToMany(mappedBy=ConstansUtil.MAPPED_CRM, fetch=FetchType.LAZY)
	private List<crmBiggestAmount> crmBiggestAmounts;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_CRM, fetch=FetchType.LAZY)
	private List<crmMostPurchased> crmMostPurchased;
	
	public Crm() {
	}

	
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public float getAvgSpent() {
		return this.avgSpent;
	}

	public void setAvgSpent(float avgSpent) {
		this.avgSpent = avgSpent;
	}

	public int getFrequency() {
		return this.frequency;
	}

	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}

	
	public Date getRecency() {
		return this.recency;
	}

	public void setRecency(Date recency) {
		this.recency = recency;
	}

	// bi-directional many-to-one association to Consumer
	
	public Consumer getConsumer() {
		return this.consumer;
	}

	public void setConsumer(Consumer consumer) {
		this.consumer = consumer;
	}

	// bi-directional many-to-one association to Retailer
	
	public Merchant getMid() {
		return mid;
	}

	public void setMid(Merchant mid) {
		this.mid = mid;
	}

	
	public List<crmBiggestAmount> getCrmBiggestAmounts() {
		return crmBiggestAmounts;
	}

	public void setCrmBiggestAmounts(List<crmBiggestAmount> crmBiggestAmounts) {
		this.crmBiggestAmounts = crmBiggestAmounts;
	}

	public List<crmMostPurchased> getCrmMostPurchased() {
		return crmMostPurchased;
	}

	public void setCrmMostPurchased(List<crmMostPurchased> crmMostPurchased) {
		this.crmMostPurchased = crmMostPurchased;
	}

	
}