package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;
import javax.swing.text.StyledEditorKit.BoldAction;

import com.dominopos.utils.ConstansUtil;


/**
 * The persistent class for the newproduct_filter database table.
 * 
 */
@Entity
@Table(name=ConstansUtil.TABLE_NEWPRODUCT_FILTER)
@NamedQuery(name="NewproductFilter.findAll", query="SELECT n FROM NewproductFilter n")
public class NewproductFilter implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@Column(length=11)
	private int id;
	@Column(length=45)
	private String key;
	@Column(length=45)
	private String value;
	@Column(length=1)
	private Boolean isActive;
	
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_MID)
	private Merchant merchant;

	public NewproductFilter() {
	}


	
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public Boolean getIsActive() {
		return this.isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}


	public String getKey() {
		return this.key;
	}

	public void setKey(String key) {
		this.key = key;
	}


	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}


	//bi-directional many-to-one association to Merchant
	
	public Merchant getMerchant() {
		return this.merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

}