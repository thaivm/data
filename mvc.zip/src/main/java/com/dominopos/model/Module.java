package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.FetchProfile;
import org.springframework.transaction.annotation.Transactional;

import com.dominopos.utils.ConstansUtil;

import java.util.List;


/**
 * The persistent class for the module database table.
 * 
 */
@Entity(name=ConstansUtil.TABLE_MODULE)
public class Module implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	@Id
	private int moduleID;
	@Column(length=12)
	private String moduleName;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_MID)
	private Merchant merchant; 
	
	@OneToMany(mappedBy=ConstansUtil.MAPPED_MODULE)
	private List<RetailerModule> retailerModules;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_MODULE)
	private List<Transaction> transactions;

	public Module() {
	}


	
	public int getModuleID() {
		return this.moduleID;
	}

	public void setModuleID(int moduleID) {
		this.moduleID = moduleID;
	}


	public String getModuleName() {
		return this.moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}


	//bi-directional many-to-one association to RetailerModule
	
	public List<RetailerModule> getRetailerModules() {
		return this.retailerModules;
	}

	public void setRetailerModules(List<RetailerModule> retailerModules) {
		this.retailerModules = retailerModules;
	}

	public RetailerModule addRetailerModule(RetailerModule retailerModule) {
		getRetailerModules().add(retailerModule);
		retailerModule.setModule(this);

		return retailerModule;
	}

	public RetailerModule removeRetailerModule(RetailerModule retailerModule) {
		getRetailerModules().remove(retailerModule);
		retailerModule.setModule(null);

		return retailerModule;
	}


	//bi-directional many-to-one association to Transaction
	
	public List<Transaction> getTransactions() {
		return this.transactions;
	}

	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	public Transaction addTransaction(Transaction transaction) {
		getTransactions().add(transaction);
		transaction.setModule(this);

		return transaction;
	}

	public Transaction removeTransaction(Transaction transaction) {
		getTransactions().remove(transaction);
		transaction.setModule(null);

		return transaction;
	}

	
	public Merchant getMerchant() {
		return merchant;
	}


	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	
}