package com.dominopos.model;

import com.dominopos.utils.ConstansUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * The persistent class for the transaction database table.
 * 
 */
@Entity(name=ConstansUtil.TABLE_TRANSACTION)
public class Transaction implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	@Column(length=11)
	private int transID;
	@Column(length=11)
	private String mid;
	@Column(length=14)
	private String itemID;
	private Date timeStamp;
	@Column(length=255)
	private String cartID;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_ACTION_ID)
	private Action action;
	@ManyToOne
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_MODULE_ID)
	private Module module;
	@ManyToOne
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_CID)
	private Consumer consumer;
	public Transaction() {
	}
	public int getTransID() {
		return this.transID;
	}
	public void setTransID(int transID) {
		this.transID = transID;
	}
	public String getMid() {
		return this.mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getItemID() {
		return this.itemID;
	}
	public void setItemID(String itemID) {
		this.itemID = itemID;
	}
	public String getCartID() {
		return cartID;
	}
	public void setCartID(String cartID) {
		this.cartID = cartID;
	}
	@Temporal(TemporalType.TIMESTAMP)
	public Date getTimeStamp() {
		return this.timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
	//bi-directional many-to-one association to Action
	public Action getAction() {
		return this.action;
	}
	public void setAction(Action action) {
		this.action = action;
	}
	public Module getModule() {
		return module;
	}
	public void setModule(Module module) {
		this.module = module;
	}
	public Consumer getConsumer() {
		return consumer;
	}
	public void setConsumer(Consumer consumer) {
		this.consumer = consumer;
	}
}