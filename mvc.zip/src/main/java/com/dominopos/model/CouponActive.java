/**
 * 
 */
package com.dominopos.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.dominopos.utils.ConstansUtil;

/**
 *
 */
@Entity
@Table(name=ConstansUtil.TABLE_COUPON_ACTIVES)
public class CouponActive {
	
	
	@Id
	@GeneratedValue
	@Column(length=11)
	private Integer couponActiveId;
	private Date dateOfEmission;
	@Column(length=1)
	private Boolean used;
	
	@ManyToOne
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_COUPON_ID)
	private Coupon coupon;
	@ManyToOne
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_CID)
	private Consumer consumer;
	@ManyToOne
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_TICKET_ID)
	private Ticket ticket;
	
	
	public Integer getCouponActiveId() {
		return couponActiveId;
	}
	public void setCouponActiveId(Integer couponActiveId) {
		this.couponActiveId = couponActiveId;
	}
	public Date getDateOfEmission() {
		return dateOfEmission;
	}
	public void setDateOfEmission(Date dateOfEmission) {
		this.dateOfEmission = dateOfEmission;
	}
	public Boolean getUsed() {
		return used;
	}
	public void setUsed(Boolean used) {
		this.used = used;
	}
	public Coupon getCoupon() {
		return coupon;
	}
	public void setCoupon(Coupon coupon) {
		this.coupon = coupon;
	}
	public Consumer getConsumer() {
		return consumer;
	}
	public void setConsumer(Consumer consumer) {
		this.consumer = consumer;
	}
	public Ticket getTicket() {
		return ticket;
	}
	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
	
	
}
