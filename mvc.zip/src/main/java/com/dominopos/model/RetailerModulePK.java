package com.dominopos.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the retailer_module database table.
 * 
 */
@Embeddable
public class RetailerModulePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;
	private String rid;
	private int moduleID;

	public RetailerModulePK() {
	}

	@Column(insertable=false, updatable=false)
	public String getRid() {
		return this.rid;
	}
	public void setRid(String rid) {
		this.rid = rid;
	}

	@Column(insertable=false, updatable=false)
	public int getModuleID() {
		return this.moduleID;
	}
	public void setModuleID(int moduleID) {
		this.moduleID = moduleID;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RetailerModulePK)) {
			return false;
		}
		RetailerModulePK castOther = (RetailerModulePK)other;
		return 
			this.rid.equals(castOther.rid)
			&& (this.moduleID == castOther.moduleID);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.rid.hashCode();
		hash = hash * prime + this.moduleID;
		
		return hash;
	}
}