package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import com.dominopos.utils.ConstansUtil;

import java.util.List;


/**
 * The persistent class for the shop_event database table.
 * 
 */
@Entity
@Table(name=ConstansUtil.TABLE_SHOP_EVENT)
@NamedQuery(name="ShopEvent.findAll", query="SELECT s FROM ShopEvent s")
public class ShopEvent implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	@Id
	@Column(length=10)
	private int id;
	@Column(length=45)
	private String description;
	@Column(length=45)
	private String name;
	
	@ManyToOne(fetch=FetchType.LAZY, cascade = {CascadeType.PERSIST})
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_RID)
	private Retailer retailer;
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_CATEGORY_ID)
	private Category category;
	
	@OneToMany(mappedBy=ConstansUtil.MAPPED_SHOP_EVENT)
	private List<ShopEventBonus> shopEventBonuses;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_SHOP_EVENT)
	private List<ShopEventCondition> shopEventConditions;

	public ShopEvent() {
	}


	
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}


	//bi-directional many-to-one association to Retailer
	
	public Retailer getRetailer() {
		return this.retailer;
	}

	public void setRetailer(Retailer retailer) {
		this.retailer = retailer;
	}

	
	public Category getCategory() {
		return category;
	}


	public void setCategory(Category category) {
		this.category = category;
	}


	//bi-directional many-to-one association to ShopEventBonus
	
	public List<ShopEventBonus> getShopEventBonuses() {
		return this.shopEventBonuses;
	}

	public void setShopEventBonuses(List<ShopEventBonus> shopEventBonuses) {
		this.shopEventBonuses = shopEventBonuses;
	}

	public ShopEventBonus addShopEventBonus(ShopEventBonus shopEventBonus) {
		getShopEventBonuses().add(shopEventBonus);
		shopEventBonus.setShopEvent(this);

		return shopEventBonus;
	}

	public ShopEventBonus removeShopEventBonus(ShopEventBonus shopEventBonus) {
		getShopEventBonuses().remove(shopEventBonus);
		shopEventBonus.setShopEvent(null);

		return shopEventBonus;
	}


	//bi-directional many-to-one association to ShopEventCondition
	
	public List<ShopEventCondition> getShopEventConditions() {
		return this.shopEventConditions;
	}

	public void setShopEventConditions(List<ShopEventCondition> shopEventConditions) {
		this.shopEventConditions = shopEventConditions;
	}

	public ShopEventCondition addShopEventCondition(ShopEventCondition shopEventCondition) {
		getShopEventConditions().add(shopEventCondition);
		shopEventCondition.setShopEvent(this);

		return shopEventCondition;
	}

	public ShopEventCondition removeShopEventCondition(ShopEventCondition shopEventCondition) {
		getShopEventConditions().remove(shopEventCondition);
		shopEventCondition.setShopEvent(null);

		return shopEventCondition;
	}

}