package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.FetchProfile;
import org.hibernate.annotations.FetchProfile.FetchOverride;

import com.dominopos.utils.ConstansUtil;

import java.util.Date;
import java.util.List;

/**
 * The persistent class for the product database table.
 * 
 */
@Entity(name = ConstansUtil.TABLE_PRODUCT)
@FetchProfile(name = "product_prices", fetchOverrides = 
	{ @FetchOverride(
			entity = Product.class, 
			association = "productPrices", 
			mode = FetchMode.JOIN) })
public class Product implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "productID",length=11)
	private String productID;
	@Column(length=45)
	private String productCode;
	@Column(length=45)
	private String productName;
	@Column(length=20)
	private String productUPC;
	@Column(length=45)
	private String taxCode;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at")
	private Date createAt;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at")
	private Date updatedAt;
	@Column(length=45)
	private String shortDescription;
	//Convert to text type under datbase.
	private String longDescription;
	//Convert to text type under datbase.
	private String image;
	//Convert to text type under datbase.
	private String video;
	@Column(name = "isActive",length=1)
	private boolean isActive;
	//2013.09.23
	@Column(length=45)
	private String location;
	//end 2013.09.23
	@Column(name = "isNew")
	private boolean isNew;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "new_unitl")
	private Date newunitl;

	@ManyToOne
	/* (fetch=FetchType.LAZY) */
	@JoinColumn(name = ConstansUtil.JOINCOLUMN_CATEGORY_ID)
	private Category category;
	@ManyToOne
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_MID)
	private Merchant merchant;

	@OneToMany(mappedBy = ConstansUtil.MAPPED_PRODUCT)
	private List<Coupon> coupons;
	@OneToMany(mappedBy = ConstansUtil.MAPPED_PRODUCT, cascade = { CascadeType.ALL })
	private List<ProductPrice> productPrices;
	@OneToMany(mappedBy = ConstansUtil.MAPPED_PRODUCT)
	private List<ProductProperty> productProperties;

	@OneToMany(mappedBy=ConstansUtil.MAPPED_PRODUCT, fetch=FetchType.LAZY)
	private List<crmMostPurchased> crmMostPurchaseds;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_PRODUCT)
	private List<Promotion> promotions;
	
	public Product() {
	}

	
	public String getProductID() {
		return this.productID;
	}

	public void setProductID(String productID) {
		this.productID = productID;
	}

	public String getImage() {
		return this.image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getLongDescription() {
		return this.longDescription;
	}

	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}

	public String getProductCode() {
		return this.productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductName() {
		return this.productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getShortDescription() {
		return this.shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	
	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getVideo() {
		return this.video;
	}

	public void setVideo(String video) {
		this.video = video;
	}

	public String getProductUPC() {
		return productUPC;
	}

	public void setProductUPC(String productUPC) {
		this.productUPC = productUPC;
	}

	public String getTaxCode() {
		return taxCode;
	}

	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}

	
	public Date getCreateAt() {
		return createAt;
	}

	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}

	
	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	
	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	
	public Date getNewunitl() {
		return newunitl;
	}

	public void setNewunitl(Date newunitl) {
		this.newunitl = newunitl;
	}

	// bi-directional many-to-one association to Coupon
	
	public List<Coupon> getCoupons() {
		return this.coupons;
	}

	public void setCoupons(List<Coupon> coupons) {
		this.coupons = coupons;
	}

	public Coupon addCoupon(Coupon coupon) {
		getCoupons().add(coupon);
		coupon.setProduct(this);

		return coupon;
	}

	public Coupon removeCoupon(Coupon coupon) {
		getCoupons().remove(coupon);
		coupon.setProduct(null);

		return coupon;
	}

	// bi-directional many-to-one association to Category
	
	public Category getCategory() {
		return this.category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	// bi-directional many-to-one association to ProductPrice
	
	public List<ProductPrice> getProductPrices() {
		
		return this.productPrices;
	}

	public void setProductPrices(List<ProductPrice> productPrices) {
		this.productPrices = productPrices;
	}

	public ProductPrice addProductPrice(ProductPrice productPrice) {
		getProductPrices().add(productPrice);
		productPrice.setProduct(this);

		return productPrice;
	}

	public ProductPrice removeProductPrice(ProductPrice productPrice) {
		getProductPrices().remove(productPrice);
		productPrice.setProduct(null);

		return productPrice;
	}

	// bi-directional many-to-one association to ProductProperty
	
	public List<ProductProperty> getProductProperties() {
		return this.productProperties;
	}

	public void setProductProperties(List<ProductProperty> productProperties) {
		this.productProperties = productProperties;
	}

	public ProductProperty addProductProperty(ProductProperty productProperty) {
		getProductProperties().add(productProperty);
		productProperty.setProduct(this);

		return productProperty;
	}

	public ProductProperty removeProductProperty(ProductProperty productProperty) {
		getProductProperties().remove(productProperty);
		productProperty.setProduct(null);

		return productProperty;
	}

	public List<crmMostPurchased> getCrmMostPurchaseds() {
		return crmMostPurchaseds;
	}

	public void setCrmMostPurchaseds(List<crmMostPurchased> crmMostPurchaseds) {
		this.crmMostPurchaseds = crmMostPurchaseds;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public List<Promotion> getPromotions() {
		return promotions;
	}

	public void setPromotions(List<Promotion> promotions) {
		this.promotions = promotions;
	}
	
}