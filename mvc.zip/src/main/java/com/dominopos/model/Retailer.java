package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.validator.constraints.Length;

import com.dominopos.utils.ConstansUtil;

import java.util.List;


/**
 * The persistent class for the retailer database table.
 * 
 */
@Entity(name=ConstansUtil.TABLE_RETAILER)
public class Retailer implements Serializable {
	

	
	
	private static final long serialVersionUID = 1L;
	@Id
	@Column(length=11)
	private String rid;
	@Column(length=25)
	private String address1;
	@Column(length=25)
	private String address2;
	@Column(length=25)
	private String address3;
	@Column(length=11)
	private int boxid;
	@Column(length=15)
	private String dns;
	@Column(length=10)
	private String postalCode;
	@Column(length=1)
	private int status;
	
	@OneToMany(mappedBy=ConstansUtil.MAPPED_RETAILER)
	private List<Consumer> consumers;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_RETAILER)
	private List<RetailerModule> retailerModules;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_RETAILER)
	private List<ShopEvent> shopEvents;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_MID)
	private Merchant merchant;

	public Retailer() {
	}


	
	public String getRid() {
		return this.rid;
	}

	public void setRid(String rid) {
		this.rid = rid;
	}


	public String getAddress1() {
		return this.address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}


	public String getAddress2() {
		return this.address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}


	public String getAddress3() {
		return this.address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public int getBoxid() {
		return boxid;
	}


	public void setBoxid(int boxid) {
		this.boxid = boxid;
	}
	


	public String getDns() {
		return this.dns;
	}

	public void setDns(String dns) {
		this.dns = dns;
	}


	public String getPostalCode() {
		return this.postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}


	public int getStatus() {
		return this.status;
	}

	public void setStatus(int status) {
		this.status = status;
	}


	//bi-directional many-to-one association to Consumer
	
	public List<Consumer> getConsumers() {
		return this.consumers;
	}

	public void setConsumers(List<Consumer> consumers) {
		this.consumers = consumers;
	}

	public Consumer addConsumer(Consumer consumer) {
		getConsumers().add(consumer);
		consumer.setRetailer(this);

		return consumer;
	}

	public Consumer removeConsumer(Consumer consumer) {
		getConsumers().remove(consumer);
		consumer.setRetailer(null);

		return consumer;
	}

	//bi-directional many-to-one association to Merchant

	public Merchant getMerchant() {
		return this.merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}


	//bi-directional many-to-one association to RetailerModule
	
	public List<RetailerModule> getRetailerModules() {
		return this.retailerModules;
	}

	public void setRetailerModules(List<RetailerModule> retailerModules) {
		this.retailerModules = retailerModules;
	}

	public RetailerModule addRetailerModule(RetailerModule retailerModule) {
		getRetailerModules().add(retailerModule);
		retailerModule.setRetailer(this);

		return retailerModule;
	}

	public RetailerModule removeRetailerModule(RetailerModule retailerModule) {
		getRetailerModules().remove(retailerModule);
		retailerModule.setRetailer(null);

		return retailerModule;
	}


	//bi-directional many-to-one association to ShopEvent
	@OneToMany(mappedBy="retailer")
	public List<ShopEvent> getShopEvents() {
		return this.shopEvents;
	}

	public void setShopEvents(List<ShopEvent> shopEvents) {
		this.shopEvents = shopEvents;
	}

	public ShopEvent addShopEvent(ShopEvent shopEvent) {
		getShopEvents().add(shopEvent);
		shopEvent.setRetailer(this);

		return shopEvent;
	}

	public ShopEvent removeShopEvent(ShopEvent shopEvent) {
		getShopEvents().remove(shopEvent);
		shopEvent.setRetailer(null);

		return shopEvent;
	}



}