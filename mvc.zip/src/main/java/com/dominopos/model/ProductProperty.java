package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import com.dominopos.utils.ConstansUtil;


/**
 * The persistent class for the product_properties database table.
 * 
 */
@Entity
@Table(name=ConstansUtil.TABLE_PRODUCT_PROPERTIES)
@NamedQuery(name="ProductProperty.findAll", query="SELECT p FROM ProductProperty p")
public class ProductProperty implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@Column(length=11)
	private int id;
	private int size;
	@Column(length=45)
	private String color;
	private int weight;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_PRODUCT_ID)
	private Product product;

	public ProductProperty() {
	}


	
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public String getColor() {
		return this.color;
	}

	public void setColor(String color) {
		this.color = color;
	}


	public int getSize() {
		return this.size;
	}

	public void setSize(int size) {
		this.size = size;
	}


	public int getWeight() {
		return this.weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}


	//bi-directional many-to-one association to Product
	
	public Product getProduct() {
		return this.product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

}