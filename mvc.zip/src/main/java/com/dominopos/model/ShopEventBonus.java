package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import com.dominopos.utils.ConstansUtil;


/**
 * The persistent class for the shop_event_bonus database table.
 * 
 */
@Entity
@Table(name=ConstansUtil.TABLE_SHOP_EVENT_BONUS)
@NamedQuery(name="ShopEventBonus.findAll", query="SELECT s FROM ShopEventBonus s")
public class ShopEventBonus implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	@Column(length=11)
	private int id;
	@Column(length=45)
	private String key;
	@Column(length=45)
	private String value;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_SHOP_EVENT_ID)
	private ShopEvent shopEvent;

	public ShopEventBonus() {
	}


	
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public String getKey() {
		return this.key;
	}

	public void setKey(String key) {
		this.key = key;
	}


	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}


	//bi-directional many-to-one association to ShopEvent
	
	public ShopEvent getShopEvent() {
		return this.shopEvent;
	}

	public void setShopEvent(ShopEvent shopEvent) {
		this.shopEvent = shopEvent;
	}

}