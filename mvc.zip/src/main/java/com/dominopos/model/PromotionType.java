/**
 * 
 */
package com.dominopos.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.dominopos.utils.ConstansUtil;

/**
 *
 */
@Entity(name=ConstansUtil.TABLE_PROMOTION_TYPES)
public class PromotionType {

	

	
	
	@Id
	@GeneratedValue
	@Column(length=11)
	private int promTypeId;
	@Column(length=45)
	private String code;
	@Column(length=45)
	private String name;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_MID)
	private Merchant merchant;
	
	@OneToMany(mappedBy=ConstansUtil.MAPPED_PROMOTION_TYPE)
	private List<Promotion> promotions;
	/**
	 * 
	 */
	public PromotionType() {
		// TODO Auto-generated constructor stub
	}
	
	public int getPromTypeId() {
		return promTypeId;
	}
	public void setPromTypeId(int promTypeId) {
		this.promTypeId = promTypeId;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public Merchant getMerchant() {
		return merchant;
	}
	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}
	
	
	public List<Promotion> getPromotions() {
		return promotions;
	}
	public void setPromotions(List<Promotion> promotions) {
		this.promotions = promotions;
	}
	
	
	
}
