package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import com.dominopos.utils.ConstansUtil;


/**
 * The persistent class for the retailer_module database table.
 * 
 */
@Entity
@Table(name=ConstansUtil.TABLE_RETAILER_MODULE)
@NamedQuery(name="RetailerModule.findAll", query="SELECT r FROM RetailerModule r")
public class RetailerModule implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	@EmbeddedId
	private RetailerModulePK id;
	@Column(length=11)
	private String positionInShop;
	@Column(length=10)
	private int totalInStock;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_MODULE_ID, insertable = false, updatable = false)
	private Module module;
	@ManyToOne(fetch=FetchType.LAZY, cascade = {CascadeType.PERSIST})
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_RID)
	private Retailer retailer;

	public RetailerModule() {
	}


	
	public RetailerModulePK getId() {
		return this.id;
	}

	public void setId(RetailerModulePK id) {
		this.id = id;
	}


	public String getPositionInShop() {
		return this.positionInShop;
	}

	public void setPositionInShop(String positionInShop) {
		this.positionInShop = positionInShop;
	}


	public int getTotalInStock() {
		return this.totalInStock;
	}

	public void setTotalInStock(int totalInStock) {
		this.totalInStock = totalInStock;
	}


	//bi-directional many-to-one association to Module
	
	public Module getModule() {
		return this.module;
	}

	public void setModule(Module module) {
		this.module = module;
	}


	//bi-directional many-to-one association to Retailer
	
	public Retailer getRetailer() {
		return this.retailer;
	}

	public void setRetailer(Retailer retailer) {
		this.retailer = retailer;
	}

}