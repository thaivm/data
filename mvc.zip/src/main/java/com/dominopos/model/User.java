package com.dominopos.model;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

@Entity
@Table(name="user")
public class User implements Serializable, UserDetails{
	
	private static final long serialVersionUID = 1L;
	
	private long userId;
	
	private String userLogin;
	
	private String userName;
	
	private String password;
	
	private Date createDate;
	private Date lastLogin;
	private Date lastModified;
	private Date passwordChanged;
	private Date passwordValidity;
	
	private String emailAddress;
	
	private String handPhone;
	
	private int loginFailedCount;

    private UserAccessProfile accessProfile;

	private Merchant merchant;

	private int userLevel;
	
	private ArrayList<GrantedAuthority> authorities = null;

	
	
	public User() {}

    public User(String userName, String password, UserAccessProfile accessProfile) {
        this.userName = userName;
        this.password = password;
        this.accessProfile = accessProfile;
    }

    @Column(length = 100)
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(length = 19)
	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}
	
	@Column(length = 100)
	public String getPassword() {
		return password;
	}

	public void setPassword(String password){
		this.password = password;
	}

	@Temporal(TemporalType.DATE)
	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date registerDate) {
		this.createDate = registerDate;
	}
	
	@Column(length = 1)
	public int getLoginFailedCount() {
		return loginFailedCount;
	}

	public void setLoginFailedCount(int failedTime) {
		this.loginFailedCount = failedTime;
	}

    @ManyToOne(cascade={CascadeType.PERSIST,CascadeType.MERGE})
	public UserAccessProfile getAccessProfile() {
		return accessProfile;
	}

	public void setAccessProfile(UserAccessProfile accessProfile) {
		this.accessProfile = accessProfile;
	}

    @OneToOne(cascade={CascadeType.PERSIST,CascadeType.MERGE})
	@JoinColumn(nullable = true)
	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

    @Column(length=1)
	public int getUserLevel() {
		return userLevel;
	}

	public void setUserLevel(int userLevel) {
		this.userLevel = userLevel;
	}

	@Column(length = 50)
	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	
	@Column(length = 50)
	public String getUserLogin() {
		return userLogin;
	}

	public void setUserLogin(String userLogin) {
		this.userLogin = userLogin;
	}

	public Date getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}

	public Date getLastModified() {
		return lastModified;
	}

	public void setLastModified(Date lastModified) {
		this.lastModified = lastModified;
	}

	public Date getPasswordChanged() {
		return passwordChanged;
	}

	public void setPasswordChanged(Date passwordChanged) {
		this.passwordChanged = passwordChanged;
	}
	
	public Date getPasswordValidity() {
		return passwordValidity;
	}

	public void setPasswordValidity(Date passwordValidity) {
		this.passwordValidity = passwordValidity;
	}
	
	@Column(length = 20)
	public String getHandPhone() {
		return handPhone;
	}

	public void setHandPhone(String handPhone) {
		this.handPhone = handPhone;
	}

	@Override
	@Transient
	public Collection<GrantedAuthority> getAuthorities() {
		Collection<GrantedAuthority> auth = new ArrayList<GrantedAuthority>();
		for (int i = 0; i < authorities.size(); i++) {
			auth.add(authorities.get(i));
		}
		return auth;
	}

	@Override
	@Transient
	public String getUsername() {
		return userName;
	}

	@Override
	@Transient
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	@Transient
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	@Transient
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	@Transient
	public boolean isEnabled() {
		return true;
	}

	public void setAuthorities(ArrayList<GrantedAuthority> authorities) {
		this.authorities = authorities;
	}
}
