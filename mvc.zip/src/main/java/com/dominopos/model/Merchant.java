package com.dominopos.model;

import com.dominopos.form.MerchantForm;
import com.dominopos.utils.ConstansUtil;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.FetchProfile;
import org.hibernate.annotations.FetchProfiles;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * The persistent class for the merchant database table.
 * 
 */
@Entity
@Table(name=ConstansUtil.TABLE_MERCHANT)
@FetchProfile(fetchOverrides = { 
		@FetchProfile.FetchOverride(entity=Merchant.class,
				association="products",
				mode=FetchMode.JOIN) }, 
			name = ConstansUtil.FETCHPROFILE_MERCHANT_WITH_PRODUCTS)
@FetchProfiles({
	
})
public class Merchant implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@Column(length=12)
	private String mid;
	@Column(length=40)
	private String merchantCompany;
	@Column(length=45)
	private String contactName;
	@Column(length=25)
	private String address1;
	@Column(length=25)
	private String address2;
	@Column(length=25)
	private String address3;
	@Column(length=10)
	private String postalCode;
	@Column(length=30)
	private String city;
	@Column(length=30)
	private String country;
	@Column(length=15)
	private String phoneNumber;
	@Column(length=15)
	private String faxNumber;
	@Column(length=30)
	private String email;
	@Column(length=40)
	private String merchantDescription;
	private Date dateOfStart;
//    @Type(type = "numeric_boolean")
	@Column(length=1)
	private boolean active;
	@Column(length=155)
	private String logo;
	@Column(length=3)
	private String currency;
	@Column(length=20)
	private String taxCode1;
	@Column(length=20)
	private String taxCode2;
	@Column(length=20)
	private String taxCode3;
	@Column(length=25)
	private String slogan;
	@Column(length=45)
	private String bID;
	@Column(length=45)
	private String boxAddress;
	@Column(length=50)
	private String web;
	//2013/09/23
	@Column(length=1)
	private boolean vat;
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_USER_ID)
	private User user;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_MERCHANT)
	private List<Consumer> consumers;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_MERCHANT)
	private List<NewproductFilter> newproductFilters;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_MERCHANT)
	private List<Retailer> retailers;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_MERCHANT)
	private List<Module> modules;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_MERCHANT)
	private List<Coupon> coupons;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_MERCHANT)
	private List<MerchantActivity> merchantActivities;
	//2013/09/24
	@OneToMany(mappedBy=ConstansUtil.MAPPED_MERCHANT, fetch=FetchType.LAZY)
	private List<Ticket> tickets;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_MERCHANT,fetch=FetchType.LAZY)
	private List<Product> products;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_MERCHANT, fetch=FetchType.LAZY)
	private List<Category> categories;
	//2013/09/27
	@OneToMany(mappedBy=ConstansUtil.MAPPED_MERCHANT, fetch=FetchType.LAZY)
	private List<Promotion> promotions;
    public Merchant() {
        this.mid = "";
        this.merchantCompany = "";
        this.contactName = "";
        this.address1 = "";
        this.address2 = "";
        this.address3 = "";
        this.postalCode = "";
        this.city = "";
        this.country = "";
        this.phoneNumber = "";
        this.faxNumber = "";
        this.email = "";
        this.merchantDescription = "";
        this.logo = "";
        this.currency = "";
        this.taxCode1 = "";
        this.taxCode2 = "";
        this.taxCode3 = "";
        this.slogan = "";
        this.bID = "";
        this.boxAddress = "";
        this.web = "";
    }
    public Merchant(MerchantForm merchantForm) {
        this.mid = merchantForm.getMid();
        this.merchantCompany = merchantForm.getMerchantCompany();
        this.contactName = merchantForm.getContactName();
        this.address1 = merchantForm.getAddress1();
        this.address2 = merchantForm.getAddress2();
        this.address3 = merchantForm.getAddress3();
        this.postalCode = merchantForm.getPostalCode();
        this.city = merchantForm.getCity();
        this.country = merchantForm.getCountry();
        this.phoneNumber = merchantForm.getPhoneNumber();
        this.faxNumber = merchantForm.getFaxNumber();
        this.email = merchantForm.getEmail();
        this.merchantDescription = merchantForm.getMerchantDescription();
        this.dateOfStart = null;
        this.active = merchantForm.isActive();
        this.logo = "";
        this.currency = merchantForm.getCurrency();
        this.taxCode1 = "";
        this.taxCode2 = "";
        this.taxCode3 = "";
        this.slogan = "";
        this.bID = "";
        this.boxAddress = "";
        this.web = "";
    }
    public Merchant(String mid, String merchantCompany, String contactName, String address1, String address2, String address3, String postalCode, String city, String country, String phoneNumber, String faxNumber, String email, String merchantDescription, Date dateOfStart, boolean active, String logo, String currency, String taxCode1, String taxCode2, String taxCode3, String slogan, String bID, String boxAddress, String web, boolean vat, User user, List<Consumer> consumers, List<NewproductFilter> newproductFilters, List<Retailer> retailers, List<Module> modules, List<Coupon> coupons, List<MerchantActivity> merchantActivities, List<Ticket> tickets, List<Product> products, List<Category> categories, List<Promotion> promotions) {
        this.mid = mid;
        this.merchantCompany = merchantCompany;
        this.contactName = contactName;
        this.address1 = address1;
        this.address2 = address2;
        this.address3 = address3;
        this.postalCode = postalCode;
        this.city = city;
        this.country = country;
        this.phoneNumber = phoneNumber;
        this.faxNumber = faxNumber;
        this.email = email;
        this.merchantDescription = merchantDescription;
        this.dateOfStart = dateOfStart;
        this.active = active;
        this.logo = logo;
        this.currency = currency;
        this.taxCode1 = taxCode1;
        this.taxCode2 = taxCode2;
        this.taxCode3 = taxCode3;
        this.slogan = slogan;
        this.bID = bID;
        this.boxAddress = boxAddress;
        this.web = web;
        this.vat = vat;
        this.user = user;
        this.consumers = consumers;
        this.newproductFilters = newproductFilters;
        this.retailers = retailers;
        this.modules = modules;
        this.coupons = coupons;
        this.merchantActivities = merchantActivities;
        this.tickets = tickets;
        this.products = products;
        this.categories = categories;
        this.promotions = promotions;
    }
    public String getMid() {
		return this.mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getAddress1() {
		return this.address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return this.address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return this.address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getCurrency() {
		return this.currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getLogo() {
		return this.logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public String getMerchantDescription() {
		return this.merchantDescription;
	}
	public void setMerchantDescription(String merchantDescription) {
		this.merchantDescription = merchantDescription;
	}
	public String getPostalCode() {
		return this.postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getSlogan() {
		return this.slogan;
	}
	public void setSlogan(String slogan) {
		this.slogan = slogan;
	}
	public String getWeb() {
		return this.web;
	}
	public void setWeb(String web) {
		this.web = web;
	}
	public String getMerchantCompany() {
		return merchantCompany;
	}
	public void setMerchantCompany(String merchantCompany) {
		this.merchantCompany = merchantCompany;
	}
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getFaxNumber() {
		return faxNumber;
	}
	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getDateOfStart() {
		return dateOfStart;
	}
	public void setDateOfStart(Date dateOfStart) {
		this.dateOfStart = dateOfStart;
	}
	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
	public String getTaxCode1() {
		return taxCode1;
	}
	public void setTaxCode1(String taxCode1) {
		this.taxCode1 = taxCode1;
	}
	public String getTaxCode2() {
		return taxCode2;
	}
	public void setTaxCode2(String taxCode2) {
		this.taxCode2 = taxCode2;
	}
	public String getTaxCode3() {
		return taxCode3;
	}
	public void setTaxCode3(String taxCode3) {
		this.taxCode3 = taxCode3;
	}
	public String getbID() {
		return bID;
	}
	public void setbID(String bID) {
		this.bID = bID;
	}
	public String getBoxAddress() {
		return boxAddress;
	}
	public void setBoxAddress(String boxAddress) {
		this.boxAddress = boxAddress;
	}
	@Column(name="VAT",nullable=true)
	public boolean isVat() {
		return vat;
	}
	public void setVat(boolean vat) {
		this.vat = vat;
	}
	//bi-directional many-to-one association to Consumer
	public List<Consumer> getConsumers() {
		return this.consumers;
	}
	public void setConsumers(List<Consumer> consumers) {
		this.consumers = consumers;
	}
	public Consumer addConsumer(Consumer consumer) {
		getConsumers().add(consumer);
		consumer.setMerchant(this);

		return consumer;
	}
	public Consumer removeConsumer(Consumer consumer) {
		getConsumers().remove(consumer);
		consumer.setMerchant(null);
		return consumer;
	}
	//bi-directional many-to-one association to User
	public User getUser() {
		return this.user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public List<NewproductFilter> getNewproductFilters() {
		return this.newproductFilters;
	}
	public void setNewproductFilters(List<NewproductFilter> newproductFilters) {
		this.newproductFilters = newproductFilters;
	}
	public NewproductFilter addNewproductFilter(NewproductFilter newproductFilter) {
		getNewproductFilters().add(newproductFilter);
		newproductFilter.setMerchant(this);

		return newproductFilter;
	}
	public NewproductFilter removeNewproductFilter(NewproductFilter newproductFilter) {
		getNewproductFilters().remove(newproductFilter);
		newproductFilter.setMerchant(null);
		return newproductFilter;
	}
	//bi-directional many-to-one association to Retailer
	public List<Retailer> getRetailers() {
		return this.retailers;
	}
	public void setRetailers(List<Retailer> retailers) {
		this.retailers = retailers;
	}
	public Retailer addRetailer(Retailer retailer) {
		getRetailers().add(retailer);
		retailer.setMerchant(this);

		return retailer;
	}
	public Retailer removeRetailer(Retailer retailer) {
		getRetailers().remove(retailer);
		retailer.setMerchant(null);

		return retailer;
	}
	public List<Module> getModules() {
		return modules;
	}
	public void setModules(List<Module> modules) {
		this.modules = modules;
	}
	public List<MerchantActivity> getMerchantActivities() {
		return merchantActivities;
	}
	public void setMerchantActivities(List<MerchantActivity> merchantActivities) {
		this.merchantActivities = merchantActivities;
	}
	public List<Coupon> getCoupons() {
		return coupons;
	}
	public void setCoupons(List<Coupon> coupons) {
		this.coupons = coupons;
	}
	public List<Ticket> getTickets() {
		return tickets;
	}
	public void setTickets(List<Ticket> tickets) {
		this.tickets = tickets;
	}
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	public List<Category> getCategories() {
		return categories;
	}
	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}
}