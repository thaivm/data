package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import com.dominopos.utils.ConstansUtil;


/**
 * The persistent class for the category_properties database table.
 * 
 */
@Entity
@Table(name=ConstansUtil.TABLE_CATEGORY_PROPERTIES)
public class CategoryProperty implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	@Column(length=11)
	private int cpropertyID;
	@Column(length=45)
	private String propertyName;
	//How to choose text type under database.
	private String propertyValue;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_CATEGORY_ID)
	private Category category;

	public CategoryProperty() {
	}


	
	public int getCpropertyID() {
		return this.cpropertyID;
	}

	public void setCpropertyID(int cpropertyID) {
		this.cpropertyID = cpropertyID;
	}


	public String getPropertyName() {
		return this.propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}


	@Lob
	public String getPropertyValue() {
		return this.propertyValue;
	}

	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}


	//bi-directional many-to-one association to Category

	public Category getCategory() {
		return this.category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

}