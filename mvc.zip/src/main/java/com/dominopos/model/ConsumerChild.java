/**
 * 
 */
package com.dominopos.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.dominopos.utils.ConstansUtil;

/**
 *
 */
@Entity
@Table(name=ConstansUtil.TABLE_CONSUMER_CHILDS)
public class ConsumerChild implements Serializable {
	
	
	@Id
	@Column(length=11)
	private int cChildID;
	@Column(length=45)
	private String name;
	@Column(length=11)
	private int order;
	private Date birthDay;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_CID)
	private Consumer consumer;
	
	/**
	 * 
	 */
	public ConsumerChild() {
		// TODO Auto-generated constructor stub
	}

	
	public int getcChildID() {
		return cChildID;
	}

	public void setcChildID(int cChildID) {
		this.cChildID = cChildID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public Date getBirthDay() {
		return birthDay;
	}

	public void setBirthDay(Date birthDay) {
		this.birthDay = birthDay;
	}

	
	public Consumer getConsumer() {
		return consumer;
	}

	public void setConsumer(Consumer consumer) {
		this.consumer = consumer;
	}

	
	
}
