package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import com.dominopos.utils.ConstansUtil;

import java.sql.Time;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the coupons database table.
 * 
 */
@Entity(name=ConstansUtil.TABLE_COUPONS)
public class Coupon implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	@Id
	private int id;
	@Column(length=255)
	private String couponShortDescription;
	//Convert to text type under database.
	private String couponLongDescription;
	@Column(length=50)
	private String images;
	@Column(length=11)
	private Integer businessRule;
	@Column(length=11)
	private Integer totalTicketAmount;
	
	private Double discount;
	private Date startCoupon;
	private Date endCoupon;
	private Time startTime;
	private Time endTime;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_MID)
	private Merchant merchant;
	@ManyToOne
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_PRODUCT_ID)
	private Product product;
	
	@OneToMany(mappedBy=ConstansUtil.MAPPED_COUPON)
	private List<CouponsFilter> couponsFilters;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_COUPON,fetch=FetchType.LAZY)
	private List<CouponActive> couponActives;

	public Coupon() {
	}


	
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getImages() {
		return this.images;
	}

	public void setImages(String images) {
		this.images = images;
	}

	//bi-directional many-to-one association to Consumer
	
	public Merchant getMerchant() {
		return this.merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	//bi-directional many-to-one association to CouponsFilter
	
	public List<CouponsFilter> getCouponsFilters() {
		return this.couponsFilters;
	}

	public void setCouponsFilters(List<CouponsFilter> couponsFilters) {
		this.couponsFilters = couponsFilters;
	}

	public CouponsFilter addCouponsFilter(CouponsFilter couponsFilter) {
		getCouponsFilters().add(couponsFilter);
		couponsFilter.setCoupon(this);

		return couponsFilter;
	}

	public CouponsFilter removeCouponsFilter(CouponsFilter couponsFilter) {
		getCouponsFilters().remove(couponsFilter);
		couponsFilter.setCoupon(null);

		return couponsFilter;
	}


	public String getCouponShortDescription() {
		return couponShortDescription;
	}


	public void setCouponShortDescription(String couponShortDescription) {
		this.couponShortDescription = couponShortDescription;
	}


	public String getCouponLongDescription() {
		return couponLongDescription;
	}


	public void setCouponLongDescription(String couponLongDescription) {
		this.couponLongDescription = couponLongDescription;
	}


	public Double getDiscount() {
		return discount;
	}


	public void setDiscount(Double discount) {
		this.discount = discount;
	}


	public Integer getBusinessRule() {
		return businessRule;
	}


	public void setBusinessRule(Integer businessRule) {
		this.businessRule = businessRule;
	}


	public Integer getTotalTicketAmount() {
		return totalTicketAmount;
	}


	public void setTotalTicketAmount(Integer totalTicketAmount) {
		this.totalTicketAmount = totalTicketAmount;
	}


	public Date getStartCoupon() {
		return startCoupon;
	}


	public void setStartCoupon(Date startCoupon) {
		this.startCoupon = startCoupon;
	}


	public Date getEndCoupon() {
		return endCoupon;
	}


	public void setEndCoupon(Date endCoupon) {
		this.endCoupon = endCoupon;
	}


	public Time getStartTime() {
		return startTime;
	}


	public void setStartTime(Time startTime) {
		this.startTime = startTime;
	}


	public Time getEndTime() {
		return endTime;
	}


	public void setEndTime(Time endTime) {
		this.endTime = endTime;
	}


	public Product getProduct() {
		return product;
	}


	public void setProduct(Product product) {
		this.product = product;
	}

	
}