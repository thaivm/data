package com.dominopos.model;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.FetchProfile;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;
@Entity
@Table(name="useraccessprofile")
@FetchProfile(name="useraccessprofile-with-permission",fetchOverrides={
		@FetchProfile.FetchOverride(entity=UserAccessProfile.class,association="permissions",mode=FetchMode.JOIN),
})
public class UserAccessProfile implements Serializable{
	private long accessProfileId;
	private String accessProfileName;
	// ADMIN or MERCHANT
	private String accessProfileMemo;
	// title role
	private List<Permission> permissions;
	// list menu
	private boolean enabled;
	// turn on off menu
	private int profileType;
	//1: admin; 2:merchant; 3: another role
	public UserAccessProfile() {}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(length = 2)
	public long getAccessProfileId() {
		return accessProfileId;
	}
	public void setAccessProfileId(long accessProfileId) {
		this.accessProfileId = accessProfileId;
	}
	@Column(length = 30)
	public String getAccessProfileName() {
		return accessProfileName;
	}
	public void setAccessProfileName(String accessProfileName) {
		this.accessProfileName = accessProfileName;
	}
	@Column(length = 30)
	public String getAccessProfileMemo() {
		return accessProfileMemo;
	}
	public void setAccessProfileMemo(String accessProfileMemo) {
		this.accessProfileMemo = accessProfileMemo;
	}
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	public List<Permission> getPermissions() {
		return permissions;
	}
	public void setPermissions(List<Permission> permissions) {
		this.permissions = permissions;
	}
	@Column(length = 1)
	public int getProfileType() {
		return profileType;
	}
	public void setProfileType(int profileType) {
		this.profileType = profileType;
	}
}
