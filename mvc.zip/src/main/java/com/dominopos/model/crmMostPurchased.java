/**
 * 
 */
package com.dominopos.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Length;

import com.dominopos.utils.ConstansUtil;

/**
 *
 */
@Entity
@Table(name=ConstansUtil.TABLE_CRM_MOSTPURCHASED)
public class crmMostPurchased {
	
	@Id
	@GeneratedValue
	@Column(length=11)
	private int id;
	@Column(length=11)
	private int quantity;
	private Date dateStamp;
	
	@ManyToOne
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_CRM_ID)
	private Crm crm;
	@ManyToOne
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_PRODUCT_ID)
	private Product product;
	
	/**
	 * 
	 * 
	 */
	public crmMostPurchased() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Date getDateStamp() {
		return dateStamp;
	}

	public void setDateStamp(Date dateStamp) {
		this.dateStamp = dateStamp;
	}

	public Crm getCrm() {
		return crm;
	}

	public void setCrm(Crm crm) {
		this.crm = crm;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

}
