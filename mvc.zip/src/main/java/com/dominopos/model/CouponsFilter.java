package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import com.dominopos.utils.ConstansUtil;


/**
 * The persistent class for the coupons_filters database table.
 * 
 */
@Entity
@Table(name=ConstansUtil.TABLE_COUPONS_FILTERS)
public class CouponsFilter implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@Column(length=11)
	private int id;
	@Column(length=45)
	private String key;
	@Column(length=45)
	private String value;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_COUPON_ID)
	private Coupon coupon;

	public CouponsFilter() {
	}


	
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public String getKey() {
		return this.key;
	}

	public void setKey(String key) {
		this.key = key;
	}


	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}


	//bi-directional many-to-one association to Coupon
	
	public Coupon getCoupon() {
		return this.coupon;
	}

	public void setCoupon(Coupon coupon) {
		this.coupon = coupon;
	}

}