package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import com.dominopos.utils.ConstansUtil;

import java.util.List;


/**
 * The persistent class for the activity database table.
 * 
 */
@Entity(name=ConstansUtil.TABLE_ACTIVITY)
public class Activity implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	@Id
	@Column(length=11)
	private String activityID;
	@Column(length=55)
	private String activityName;
	@Column(length=40)
	private String description;

	@OneToMany(mappedBy=ConstansUtil.MAPPED_ACTIVITY)
	private List<MerchantActivity> merchantActivities;
	
	public Activity() {
	}

	public String getActivityID() {
		return this.activityID;
	}

	public void setActivityID(String activityID) {
		this.activityID = activityID;
	}


	public String getActivityName() {
		return this.activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}


	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


	
	public List<MerchantActivity> getMerchantActivities() {
		return merchantActivities;
	}


	public void setMerchantActivities(List<MerchantActivity> merchantActivities) {
		this.merchantActivities = merchantActivities;
	}


	
}