package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import com.dominopos.utils.ConstansUtil;

import java.util.Date;
import java.util.List;

/**
 * The persistent class for the receipt database table.
 * 
 */
@Entity(name = ConstansUtil.TABLE_TICKET)
public class Ticket implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	private String ticketID;
	@Column(name = "totalPrice")
	private Double totalPrice;
	@Column(name = "paymentMode")
	private String paymentMode;

	// 2013/09/23
	@Column(name = "timeStamp")
	private Date timeStamp;
	@Column(name = "cartID")
	private String cartID;
	@Column(name = "nbProduct")
	private int nbProduct;
	@Column(name = "nbCoupon")
	private int nbCoupon;
	@Column(name = "vat1")
	private Double vat1;
	@Column(name = "vat2")
	private Double vat2;
	@Column(name = "vat3")
	private Double vat3;
	@Column(name = "totalPriceVat")
	private Double totalPriceVat;
	// end 2013/09/23

	// bi-directional many-to-one association to Consumer
	@JoinColumn(name = ConstansUtil.JOINCOLUMN_CID)
	private Consumer consumer;
	@JoinColumn(name = ConstansUtil.JOINCOLUMN_MID)
	private Merchant merchant;

	@OneToMany(mappedBy = "ticket", fetch=FetchType.LAZY)
	private List<TicketDetail> ticketDetails;
	@OneToMany(mappedBy="ticket",fetch=FetchType.LAZY)
	private List<CouponActive> couponActives;

	public Ticket() {
	}

	public String getTicketID() {
		return ticketID;
	}

	public void setTicketID(String ticketID) {
		this.ticketID = ticketID;
	}

	public Double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getCartID() {
		return cartID;
	}

	public void setCartID(String cartID) {
		this.cartID = cartID;
	}

	public int getNbProduct() {
		return nbProduct;
	}

	public void setNbProduct(int nbProduct) {
		this.nbProduct = nbProduct;
	}

	public int getNbCoupon() {
		return nbCoupon;
	}

	public void setNbCoupon(int nbCoupon) {
		this.nbCoupon = nbCoupon;
	}

	public Double getVat1() {
		return vat1;
	}

	public void setVat1(Double vat1) {
		this.vat1 = vat1;
	}

	public Double getVat2() {
		return vat2;
	}

	public void setVat2(Double vat2) {
		this.vat2 = vat2;
	}

	public Double getVat3() {
		return vat3;
	}

	public void setVat3(Double vat3) {
		this.vat3 = vat3;
	}

	public Double getTotalPriceVat() {
		return totalPriceVat;
	}

	public void setTotalPriceVat(Double totalPriceVat) {
		this.totalPriceVat = totalPriceVat;
	}

	public Consumer getConsumer() {
		return consumer;
	}

	public void setConsumer(Consumer consumer) {
		this.consumer = consumer;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant nerchant) {
		this.merchant = nerchant;
	}

	public List<TicketDetail> getTicketDetails() {
		return ticketDetails;
	}

	public void setTicketDetails(List<TicketDetail> ticketDetails) {
		this.ticketDetails = ticketDetails;
	}

	public List<CouponActive> getCouponActives() {
		return couponActives;
	}

	public void setCouponActives(List<CouponActive> couponActives) {
		this.couponActives = couponActives;
	}

	
	
}