/**
 * 
 */
package com.dominopos.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.dominopos.utils.ConstansUtil;

/**
 *
 */
@Entity
@Table(name=ConstansUtil.TABLE_EVENTS)
public class Event {
	
	@Id
	@GeneratedValue
	@Column(length=11)
	private int eventID;
	@Column(length=11)
	private int eventType;
	private Date startEvent;
	private Date endEvent;
	private Date startTime;
	private Date endTime;
	
	@ManyToOne
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_PRODUCT_ID)
	private Product product;

	public int getEventID() {
		return eventID;
	}

	public void setEventID(int eventID) {
		this.eventID = eventID;
	}

	public int getEventType() {
		return eventType;
	}

	public void setEventType(int eventType) {
		this.eventType = eventType;
	}

	public Date getStartEvent() {
		return startEvent;
	}

	public void setStartEvent(Date startEvent) {
		this.startEvent = startEvent;
	}

	public Date getEndEvent() {
		return endEvent;
	}

	public void setEndEvent(Date endEvent) {
		this.endEvent = endEvent;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
	
	
}
