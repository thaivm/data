package com.dominopos.model;

import java.io.Serializable;

import javax.persistence.*;

import com.dominopos.utils.ConstansUtil;

import java.util.List;


/**
 * The persistent class for the action database table.
 * 
 */
@Entity
@Table(name=ConstansUtil.TABLE_ACTION)
@NamedQuery(name="Action.findAll", query="SELECT a FROM Action a")
public class Action implements Serializable {
	
	

	
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(length=11)
	private int actionID;
	@Column(length=45)
	private String name;
	@OneToMany(mappedBy=ConstansUtil.MAPPED_ACTION)
	private List<Transaction> transactions;

	public Action() {
	}


	
	public int getActionID() {
		return this.actionID;
	}

	public void setActionID(int actionID) {
		this.actionID = actionID;
	}


	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}


	//bi-directional many-to-one association to Transaction
	
	public List<Transaction> getTransactions() {
		return this.transactions;
	}

	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	public Transaction addTransaction(Transaction transaction) {
		getTransactions().add(transaction);
		transaction.setAction(this);

		return transaction;
	}

	public Transaction removeTransaction(Transaction transaction) {
		getTransactions().remove(transaction);
		transaction.setAction(null);

		return transaction;
	}

}