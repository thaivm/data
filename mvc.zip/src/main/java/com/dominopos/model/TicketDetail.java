/**
 * 
 */
package com.dominopos.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import com.dominopos.utils.ConstansUtil;

/**
 *
 */
@Entity(name=ConstansUtil.TABLE_TICKET_DETAIL)
public class TicketDetail {
	
	@Id
	@GeneratedValue
	@Column(length=11)
	private int itemId;
	@Column(name="itemcod",length=255)
	private String itemCod;
	@Column(name="itemtype",length=255)
	private String itemType;
	@Column(name="itemdesc",length=255)
	private String itemDesc;
	@Column(name="unitprice")
	private Double unitPrice;
	@Column(name="quantity")
	private Integer quantity;
	@Column(name="totalPrice")
	private Double totalPrice;
	@Column(name="vatcode",length=255)
	private String vatCode;
	
	@JoinColumn(name=ConstansUtil.JOINCOLUMN_TICKET_ID)
	private Ticket ticket;

	
	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	
	public String getItemCod() {
		return itemCod;
	}

	public void setItemCod(String itemCod) {
		this.itemCod = itemCod;
	}

	
	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	
	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	
	public Double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	
	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	
	public Double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}

	
	public String getVatCode() {
		return vatCode;
	}

	public void setVatCode(String vatCode) {
		this.vatCode = vatCode;
	}

	
	public Ticket getTicket() {
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
	
	
}
